#include "auto_config.h"
#include <stdio.h>
#include <string.h>
#include <errno.h>

extern FILE *yyin;

/* output source file path */
FILE *fp;
#define SOURCE_FILE_PATH        ROOTDIR "/postproc/postproc.c"


// XXX: also in 'postproc_yacc.y'
#define RESULT_NUM      "result->numberoftoken"

void open_source_file()
{
	fp = fopen(SOURCE_FILE_PATH, "w");
	if (fp == NULL) {
		error("cannot open file: %s (%s)", SOURCE_FILE_PATH, strerror(errno));
		exit(1);
	}
}

void close_source_file()
{
	fclose(fp);
}

void print_function_move_result_info()
{
	fprintf(fp, "void move_result_info(FINAL_INFO *result, int to, int from) {\n");
	fprintf(fp, "	if (to == from) return;\n");
	fprintf(fp, "\n");
	fprintf(fp, "	/* if move forward */\n");
	fprintf(fp, "	if (from > to) {\n");
	fprintf(fp, "		while (from < result->numberoftoken)\n");
	fprintf(fp, "			memcpy(&(result->result_info[to++]), ");
	fprintf(fp, "&(result->result_info[from++]), sizeof(RESULT_INFO));\n");
	fprintf(fp, "\n");
	fprintf(fp, "		result->numberoftoken -= from - to;\n");
	fprintf(fp, "	}\n");
	fprintf(fp, "	/* if move backward */\n");
	fprintf(fp, "	else {\n");
	fprintf(fp, "		int lastfrom = result->numberoftoken - 1;\n");
	fprintf(fp, "		int lastto = result->numberoftoken + to - from - 1;\n");
	fprintf(fp, "\n");
	fprintf(fp, "		while (lastfrom >= from)\n");
	fprintf(fp, "			memcpy(&(result->result_info[lastto--]), ");
	fprintf(fp, "&(result->result_info[lastfrom--]), sizeof(RESULT_INFO));\n");
	fprintf(fp, "\n");
	fprintf(fp, "		result->numberoftoken += to - from;\n");
	fprintf(fp, "	}\n");
	fprintf(fp, "}\n");
}

void print_function_head()
{
	// start
	fprintf(fp, "#include \"moran.h\"\n");
	fprintf(fp, "#include \"moran_tagdef.h\"\n");
	fprintf(fp, "#include <stdlib.h>\n");
	fprintf(fp, "#include <string.h>\n");
	fprintf(fp, "\n");

	print_function_move_result_info();
	fprintf(fp, "\n");

	fprintf(fp, "int post_processor(FINAL_INFO *result) {\n");
	fprintf(fp, "\tint i, j, skip;\n");
	fprintf(fp, "\tFINAL_INFO tmpresult;\n");
	fprintf(fp, "\tfor (i=1; i<" RESULT_NUM "; i+=skip) {\n");
	fprintf(fp, "\t\tskip = 1;\n");
}

void print_function_tail()
{
	fprintf(fp, "\t}\n");
	fprintf(fp, "\treturn 1;\n");
	fprintf(fp, "}\n");
}

int main(int argc, char *argv[]) {
	if (argc < 2) {
		fprintf(stderr, "usage: %s file\n", argv[0]);
		exit(1);
	}

	if ((yyin = fopen(argv[1], "r")) == NULL) {
		exit(1);
	}

	open_source_file();
	print_function_head();
	yyparse();
	print_function_tail();
	close_source_file();

	return 0;
}
