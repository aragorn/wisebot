#include "postproc_yacc.h"

#include <stdio.h>
#include <stdlib.h>

extern FILE *yyin;
YYSTYPE yylval;

int main(int ac, char **av)
{
	int rv;

	if (ac < 2) {
		fprintf(stderr, "usage: %s file\n", av[0]);
		exit(1);
	}

	if (ac > 1 && (yyin = fopen(av[1], "r")) == NULL) {
		exit(1);
	}

	while ((rv = yylex()) != 0) {
		switch (rv) {
			case NAME:
				printf("NAME: %s\n", yylval.strval);
				free(yylval.strval);
				break;
			case STRING:
				printf("STRING: %s\n", yylval.strval);
				free(yylval.strval);
				break;
			case INTVAL:
				printf("INTVAL: %d\n", yylval.intval);
				break;
			case ASTERISK:
				printf("ASTERISK: *\n");
				break;
			default:
				printf("TOKEN: %d\n", rv);
		}
	}

	return 0;
}

