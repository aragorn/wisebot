#include <stdio.h>

extern FILE *yyin;

int main (int argc, char *argv[])
{
	char s[256];

	if (argc < 2) {
		fprintf(stderr, "usage: %s file\n", argv[0]);
		exit(1);
	}

	if ((yyin = fopen(argv[1], "r")) == NULL) {
		exit(1);
	}

	yyparse();
	return 0;
}
