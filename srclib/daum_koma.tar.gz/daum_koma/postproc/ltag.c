#include "moran_tagdef.h"

int search_ltag(const char *tag)
{
	int i;
	for (i=0; i<LEFT_TAG_CNT; i++) {
		if (strcmp(tag, L_Tag_Set[i]) == 0) return i;
	}
	return -1;
}
