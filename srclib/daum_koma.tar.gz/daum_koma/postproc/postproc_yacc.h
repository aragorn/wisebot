/* A Bison parser, made by GNU Bison 1.875c.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NAME = 258,
     ASTERISK = 259,
     EOL = 260,
     STRING = 261,
     INTVAL = 262,
     IF = 263,
     CMPLEN = 264,
     OR = 265,
     AND = 266,
     LT = 267,
     GT = 268,
     EQ = 269,
     ARROW = 270
   };
#endif
#define NAME 258
#define ASTERISK 259
#define EOL 260
#define STRING 261
#define INTVAL 262
#define IF 263
#define CMPLEN 264
#define OR 265
#define AND 266
#define LT 267
#define GT 268
#define EQ 269
#define ARROW 270




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 36 "postproc_yacc.y"
typedef union YYSTYPE {
	int intval;
	char *strval;
} YYSTYPE;
/* Line 1275 of yacc.c.  */
#line 72 "postproc_yacc.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



