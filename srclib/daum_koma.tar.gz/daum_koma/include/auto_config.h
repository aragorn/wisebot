#ifndef _AC_DEFINE_H
#define _AC_DEFINE_H 1

#define ROOTDIR     "/data2/nominam/HANL"

#endif
