#ifndef _DHA_WIN32_H
#define _DHA_WIN32_H 1

#define snprintf			_snprintf

#endif
