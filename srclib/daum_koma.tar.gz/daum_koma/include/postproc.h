#ifndef _POSTPROC_H
#define _POSTPROC_H 1

#include "moran.h"

int post_processor(FINAL_INFO *result);

#endif

