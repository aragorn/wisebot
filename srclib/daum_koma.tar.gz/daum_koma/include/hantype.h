#ifndef	__HANTYPE_H__
#define	__HANTYPE_H__


typedef	unsigned short hancode;
typedef	unsigned char internal_code;	// hangul internal code - something like NByte

#endif	// __HANTYPE_H__

