#ifndef _STRTOK_R_H
#define _STRTOK_R_H 1

char *strtok_r(char *str, char *delim, char **ptrptr);

#endif
