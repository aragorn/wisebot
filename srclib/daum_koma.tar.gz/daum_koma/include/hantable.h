#ifndef	__HANTABLE_H__
#define	__HANTABLE_H__

#define	HANGUL_MARK	128
#define	KEY_SIZE	41
#define	KSC_SIZE	11172

extern int JASOW2C[KEY_SIZE][2];
extern int JASOC2W[KEY_SIZE][2];

#endif
