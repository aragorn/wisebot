/* $Id: manage_dict.c,v 1.28 2006/04/24 04:34:57 jchern Exp $ */
#include 	<stdio.h>
#include	<stdlib.h>
#include 	<string.h>
#ifndef WIN32
#include	<unistd.h>
#endif

#include	"errorlog.h"
#include  	"moran.h"
#include	"manage_dict.h"
#include	"moran_tagdef.h"
#include	"moran_grammar.h"

#include	"triedic.h"
#include	"systemdic.h"
#include	"freqdic.h"
#include	"userdic.h"

// XXX: temporary
/* �ý���  */static dic_t *sdic;

/*	����� 	*/static dic_t *udic;

/*	�ҿ�� 	*/static dic_t *xdic;

/*	���ո���*/static dic_t *fdic;

/*	��м�	*/static dic_t *pdic;

/*	����	*/static dic_t *adic;

///*	����	*/static dic_t *ndic;

// XXX: this function is just a dummy for test...
int HANL_open_dicts(dict_manager_t *dict, const char configfile[])
{
	adic = dicmanager_create_dic_handler(dict->alias, triedic_init, triedic_open, triedic_close, triedic_search,	NULL);
	if (adic == NULL) {	warn(" %s open fail",dict->alias);	}
	dicmanager_add_dic((dic_manager_t*)dict, adic);

	pdic = dicmanager_create_dic_handler(dict->predict,	triedic_init, triedic_open, triedic_close, triedic_search, NULL);
	if (pdic == NULL) {	warn(" %s open fail",dict->predict);}
	dicmanager_add_dic((dic_manager_t*)dict, pdic);
			
	if(Check_USER_DIC()) 
	{
		udic = dicmanager_create_dic_handler(dict->udict, udict_init, open_udict, close_udict, search_udict, NULL);
		if (udic == NULL) {	warn(" %s open fail",dict->udict);}
		dicmanager_add_dic((dic_manager_t*)dict, udic);
	}

	if (Check_STOP_DIC()) 
	{
		xdic = dicmanager_create_dic_handler(dict->xdict, udict_init, open_udict, close_udict, search_udict, NULL);
		if (xdic == NULL) {	warn(" %s open fail",dict->xdict);}
		dicmanager_add_dic((dic_manager_t*)dict, xdic);
	}

	sdic = dicmanager_create_dic_handler(dict->sdict, systemdic_init, systemdic_open, systemdic_close, search_sdict, NULL);
	if (sdic == NULL) {	warn(" %s open fail",dict->sdict);}
	dicmanager_add_dic((dic_manager_t*)dict, sdic);

	// XXX: null check of below code is not necessary
	if (dict->fdict != NULL) 
	{
		fdic = dicmanager_create_dic_handler(dict->fdict, fdict_init, open_fdict, close_fdict, match_fdict, NULL);
		if (fdic == NULL) {	warn(" %s open fail",dict->fdict);}
		dicmanager_add_dic((dic_manager_t*)dict, fdic);
	}

	return dicmanager_open_dics((dic_manager_t*)dict);
}

// XXX: temporary
int HANL_close_dicts(dict_manager_t *m)
{
	dicmanager_close_dics((dic_manager_t*)m);
	return 1;
}

/* ---------------------------------------------------------------------------- */
/* ���� ���縦 �ϱ� ���� ��� 0���� �����ϰ� ���ۿ� BOE(Begin of Eojeol)��
   ���� EOE(End of Eojeol)�� �������� ����� ������ �����Ѵ� */
/* ---------------------------------------------------------------------------- */
// XXX: in wrong place...
void HANL_init_dict_info(unsigned char	*zookey,
						 int     		white_space,
						 int  			DICT_TABLE[][MAX_DICT_REF])
{
	int	i;
	int	j;
	int	size;

	size = strlen(zookey);

	for(i = 0; i < size+2; i++) {
		for(j = i; j < size + 2; j++)	DICT_TABLE[i][j] = 0;
	}

	/* �����ǻ����� ���� 1�� �����ϸ鼭 ������ �ѹ� ���������� ���� */
	DICT_TABLE[size+1][size+1] = EOE;

	switch(white_space)
	{
		case BOE :
			DICT_TABLE[0][0] = BOE;	break;
		case NUM_TAG :
			 DICT_TABLE[0][0] = NUM_TAG;	break;
		case UNKNOWN :
			 DICT_TABLE[0][0] = UNKNOWN;	break;
		case NO_WHITE :
			 DICT_TABLE[0][0] = NO_WHITE;	break;
	}
}

// XXX: temporary
int HANL_search_sdict(unsigned char *zooword, int res[])
{
	return search_sdict(sdic, zooword, res, MAX_DICT_REF);
}

// XXX: obsolete
int HANL_load_dict_info(unsigned char   *zookey,int  from, int DICT_TABLE[][MAX_DICT_REF])
{
	int *iSearch_res;
	iSearch_res = &(DICT_TABLE[from][from]);

//	ref_cnt = HANL_search_ndict( &zookey[from-1],iSearch_res, &ndic);
//	ref_cnt = HANL_search_udict( &zookey[from-1],iSearch_res, &udic);
	return HANL_search_sdict( &zookey[from-1], iSearch_res);
}

// XXX: temporary
int HANL_match_fdict(unsigned char *zooword,int *front,int *middle,int *rear,int *freq)
{
	int rv, tmp[4];
    rv = match_fdict(fdic,zooword,tmp,sizeof(int)*4);
	*front = tmp[0];
	*middle = tmp[1];
	*rear = tmp[2];
	*freq = tmp[3];
	return rv;
}

// XXX: temporary
int HANL_call_search_trie(char *keyword, char *result, int mod)
{
	if(mod == PREDIC) 
	{
		return triedic_search(pdic, keyword, result, 4096);//0
	}
	else if(mod == ALIASDIC) 
	{
		return triedic_search(adic, keyword, result, 4096);//1
	}
	return 1;
}

dic_t *dicmanager_create_dic_handler(const char path[],
									 dic_init_func init,
									 dic_open_func open,
									 dic_close_func close,
									 dic_search_func search,
									 dic_insert_func insert)
{
	dic_t *dic;
	dic = (dic_t*)malloc(sizeof(dic_t));
	if (dic == NULL) { return NULL; }

	if (path) {
		strncpy(dic->path, path, MAX_PATHSTRING_SIZE);
		dic->path[MAX_PATHSTRING_SIZE-1] = '\0';
	}

	dic->init = init;
	dic->open = open;
	dic->close = close;
	dic->search = search;
	dic->insert = insert;
	return dic;
}

void dicmanager_destroy_dic_handler(dic_t *dic)
{
	free(dic);
}

int dicmanager_add_dic(dic_manager_t *manager, dic_t *dic)
{
	if (manager->dicnum > MAX_DIC_REGISTRY_SIZE) 
	{
		error("cannot add dictionary");
		return -1;
	}

	manager->dic_registry[manager->dicnum++] = dic;
	return 1;
}

int dicmanager_open_dics(dic_manager_t *manager)
{
	dic_t *dic;
	int i;
	for (i=0; i<manager->dicnum; i++)
	{
		dic = manager->dic_registry[i];

		// initialize dictionary
		if (dic->init) dic->init(dic);

		debug("open %s...", dic->path);
		// open dictionary with handler
		if (dic->open(dic) == -1) 
		{
			error("cannot open dic: %s", dic->path);
			return -1;
		}
	}
	return 1;
}

void dicmanager_close_dics(dic_manager_t *manager)
{
	dic_t *dic;
	int i;
	for (i=0; i<manager->dicnum; i++) 
	{
		dic = manager->dic_registry[i];

		// close dictionary with handler
		if (dic) dic->close(dic);
	}
}
