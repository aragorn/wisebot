/**
 *
 * FILE : dema.c
 *
 * Daum English Morphological Analyzer (DEMA)
 *
 */

#include "affile.h"
#include "dicsearch.h"
#include "dema.h"

///////////////////////////////////////////////////////////
// �������� ����
//
DB* db;
DB* infl;
XNode* suffixNode;
XNode* prefixNode;

//////////////////////////////////////////////////////////

#define isVowel(c)  ('a'==(c)||'e'==(c)||'i'==(c)||'o'==(c)||'u'==(c))

int startDaumEMA (const char* prefixFile, const char* suffixFile,
		const char* dbFile, const char* inflDBFile)
{
	prefixNode = loadPrefixFile (prefixFile, 0);
	if (prefixNode == NULL)
	{
		fprintf (stderr, "ERROR AT OPENING THE PREFIX FILE\n");
		return FALSE;
	}

	suffixNode = loadSuffixFile (suffixFile, 0);
	if (suffixNode == NULL)
	{
		fprintf (stderr, "ERROR AT OPENING THE SUFFIX FILE\n");
		return FALSE;
	}

	db = openDBFile (dbFile);
	infl = openDBFile (inflDBFile);

	if (db == NULL)
	{
		fprintf (stderr, "ERROR AT OPENING THE LIST DB FILE\n");
		return FALSE;
	}

	if (infl == NULL)
	{
		fprintf (stderr, "ERROR AT OPENING THE INFL DB FILE\n");
		return FALSE;
	}

	printf ("=====START DAUM EMA=====\n");

	return TRUE;
}


int pushEngWordResult (FINAL_INFO* buf, int cnt, char* r, char* p, char* s)
{
	int i = 0;
	int flag = 0;
	
	while (i < cnt)
	{
		if (strcmp(r, buf->result_info[i+1].word) == 0)
			flag = 1;
		i++;
	}
	
	if (flag == 0)
	{
		strcpy (buf->result_info[cnt+1].word, r);
		cnt++;
		buf->numberoftoken = cnt + 1;
	}

	return cnt;
}

void endDaumEMA()
{
	deleteXNode (prefixNode);
	deleteXNode (suffixNode);
	closeDBFile (db);
	closeDBFile (infl);
	printf ("=====CLOSE DAUM EMA=====\n");
}

XNode* searchNextNode (char nChar, XNode* node)
{
	XNode* nNode = node;

	while (nNode != NULL)
	{
		if (nNode->curChar == nChar)
			return nNode;
		else
			nNode = nNode->nextNode;
	}

	return nNode;
}

int searchPrefix (char* word, int len, int* nPos)
{
	int i = 0;		// �ܾ��� �� �տ������� �˻�
	char nState = NULL_CHAR;
	XNode* nNode = prefixNode->downNode;

	while (nNode != NULL)
	{
		nNode = searchNextNode (word[i], nNode);

		if (nNode != NULL)
		{
			nState = nNode->curState;
			nNode = nNode->downNode;
			i++;
		}
		else
		{
			if (nState == ACCEPTED_STATE)
			{
				*nPos = i;
				return TRUE;
			}
			else
				return FALSE;
		}
		if (i > (len-1))
			break;
	}
	if (nState == ACCEPTED_STATE)
	{
		*nPos = i;
		return TRUE;
	}
	else
		return FALSE;
}

int searchSuffix (char* word, int len, int* nPos)
{
	int nLen = len - 1;		// �ܾ��� �� �ڿ������� �˻�
	char nState = NULL_CHAR;
	XNode* nNode = suffixNode->downNode;

	while (nNode != NULL)
	{
		nNode = searchNextNode (word[nLen], nNode);

		if (nNode != NULL)	// �˻��� ���ڰ� �ִٸ�
		{
			nState = nNode->curState;
			nNode = nNode->downNode;
			nLen--;
		}
		else		// �˻��� ���ڰ� ���ٸ�
		{
			if (nState == ACCEPTED_STATE)
			{
				*nPos = nLen + 1;
				return TRUE;
			}
			else
				return FALSE;
		}
		if (nLen < 0)
			break;
	}
	if (nState == ACCEPTED_STATE)
	{
		*nPos = nLen + 1;
		return TRUE;
	}
	else
		return FALSE;
}

void checkStateOfSyllable (char nChar, int* nState, int* syllable)
{
	//////////////////////////////////////////////
	// Simple automata that computes the number 
	// of syllable.
	//////////////////////////////////////////////
	switch (*nState)
	{
	case 0:		// Onset Position
		if ((isVowel (nChar) == TRUE) || (nChar == 'y'))
		{
			*nState = 1;
			*syllable += 1;
		}
		else
			*nState = 0;
		break;
	case 1:		 // Syllable Root
		if (isVowel (nChar) == TRUE)
		{
			*nState = 1;
			*syllable += 1;
		}
		else if ((nChar == 'y') || (nChar == 'w'))
		{
			*nState = 1;
			*syllable += 1;
		}
		else
			*nState = 0;
		break;
	default:
		break;
	}
}

int getSuffixType (char* str)
{
	int nLen = strlen (str);
	int nPos = nLen - 1;
	int nState = 0;

	while (nPos > 0)
	{
		switch (nState)
		{
		case 0:
			switch (str[nPos])
			{
			case 's':
				nState = 1;
				break;
			case 'd':
				nState = 2; 
				break;
			case 'g':
				nState = 3;
				break;
			case 't':
				nState = 4;
				break;
			case 'r':
				nState = 5;
				break;
			default:
				return NO_SUFFIX_TYPE;
				break;
			}
			break;
		case 1:
			switch (str[nPos])
			{
			case 'e':
				return ES_PL_TYPE;
			case '\'':
				return S_POSS_TYPE;
			default:
				return S_PL_TYPE;
			}
		case 2:
			if (str[nPos] == 'e')
				return ED_PAST_TYPE;
			else
				return NO_SUFFIX_TYPE;
		case 3:
			if (str[nPos] == 'n')
				nState = 6;
			else
				return NO_SUFFIX_TYPE;
			break;
		case 4:
			if (str[nPos] == 's')
				nState = 7;
			else
				return NO_SUFFIX_TYPE;
			break;
		case 5:
			if (str[nPos] == 'e')
				return ER_COMP_TYPE;
			else
				return NO_SUFFIX_TYPE;
		case 6:
			if (str[nPos] == 'i')
				return ING_GERUND_TYPE;
			else
				return NO_SUFFIX_TYPE;
		case 7:
			if (str[nPos] == 'e')
				return EST_SUP_TYPE;
			else
				return NO_SUFFIX_TYPE;
		}
		nPos--;
	}

	return NO_SUFFIX_TYPE;
}


int analyzeESPl (char* dest, FINAL_INFO* buf, int* count, int syllable)
{
	/////////////////////////////////////////////////////
	//
	// 1. -ch, -sh, -x, ���� �ڿ� ���� ���
	// 2. -e�� ������ �ܾ��� ���
	// 3. y�� i�� �ٲ�� -ies�� �� ���
	// 4. f�� v�� �ٲ�� -ves�� �� ���
	//
	////////////////////////////////////////////////////

	char* result;
	int nLen = strlen (dest);

	if (syllable < 2)
		return FALSE;

	switch (dest[nLen-3])
	{
	case 'x':
	case 's':
	case 'z':
	case 'o':
		dest[nLen-1] = NULL_CHAR;
		result = getSearchedItem (db, dest);
		if (result != NULL)
		{
			*count = pushEngWordResult (buf, *count, result, "", "es");
			return TRUE;
		}
		else
		{
			dest[nLen-2] = NULL_CHAR; 
			
			result = getSearchedItem (db, dest);
			if (result != NULL)
			{
				*count = pushEngWordResult (buf, *count, result, "", "es");
				return TRUE;
			}
		}
		return FALSE;
	case 'h':
		if ((dest[nLen-4] == 's') || (dest[nLen-4] == 'c'))
			dest[nLen-2] = NULL_CHAR;
		break;
	case 'i':
		dest[nLen-3] = 'y';
		dest[nLen-2] = NULL_CHAR;
		result = getSearchedItem (db, dest);
		if (result != NULL)
		{
			*count = pushEngWordResult (buf, *count, result, "", "es");
			return TRUE;
		}
		else
		{
			dest[nLen-3] = 'i';
			dest[nLen-2] = 'e';
			dest[nLen-1] = NULL_CHAR;
		}
		break;
	case 'v':
		dest[nLen-1] = NULL_CHAR;
		result = getSearchedItem (db, dest);
		if (result != NULL)
		{
			*count = pushEngWordResult (buf, *count, result, "", "es");
			return TRUE;
		}
		else
		{
			dest[nLen-3] = 'f';
			dest[nLen-2] = NULL_CHAR;
			result = getSearchedItem (db, dest);
			if (result != NULL)
			{
				*count = pushEngWordResult (buf, *count, result, "", "es");
				return TRUE;
			}
			else
			{
				dest[nLen-2] = 'e';
				dest[nLen-1] = NULL_CHAR;
				result = getSearchedItem (db, dest);
				if (result != NULL)
				{
					*count = pushEngWordResult (buf, *count, result, "", "es");
					return TRUE;
				}
				else
					dest[nLen-3] = 'v';
			}
		}
	default:
		dest[nLen-1] = NULL_CHAR;
		break;
	}

	if (strlen(dest) > 0)
	{
		result = getSearchedItem (db, dest);
		if (result != NULL)
		{
			*count = pushEngWordResult (buf, *count, result, "", "es");		
			return TRUE;
		}
	}

	return FALSE;
}

int analyzeSPl (char* dest, FINAL_INFO* buf, int *count)
{
	char* result;
	int nLen = strlen (dest);
	
	switch (dest[nLen-2])
	{
	case 'x':
	case 's':
	case 'z':
		return FALSE;
	case 'h':
		if ((dest[nLen-4] == 's') || (dest[nLen-4] == 'c'))
			return FALSE;
		break;
	case 'i':
		return FALSE;
	default:
		break;
	}
	
	dest [nLen-1] = NULL_CHAR;

	result = getSearchedItem (db, dest);
	if (result != NULL)
	{
		*count = pushEngWordResult (buf, *count, result, "", "s");
		return TRUE;
	}

	return FALSE;
}

int analyzeSPoss (char* src, FINAL_INFO* buf, int *count)
{
	char* result;
	int nLen = strlen (src);

	src[nLen-2] = NULL_CHAR;
	*count = pushEngWordResult (buf, *count, src, "", "\'s");
	return TRUE;
}

int analyzeEDPast (char* dest, FINAL_INFO* buf, int *count, int syllable)
{
	/////////////////////////////////////////////////////////////////
	//
	// 1. ������ ��ģ �� ed�� ���� ���
	// 2. y�� i�� �ٲ� �� ���� ���
	// 3. -e�� ������ ��� -d�� �м�
	// 4. 3�� ��츦 ���ؼ� ���� e�� ÷���� �� �˻�
	// 5. vowel + c�� ��� k�� �߰�
	//
	////////////////////////////////////////////////////////////////

	char* result;
	int nLen = strlen (dest);
		
	if (dest[nLen-3] == 'i')
	{
		dest[nLen-2] = NULL_CHAR;
		dest[nLen-3] = 'y';
		
		result = getSearchedItem (db, dest);
		if (result != NULL)
		{
			*count = pushEngWordResult (buf, *count, result, "", "ed");
			return TRUE;
		}
		else
		{
			dest[nLen-3] = 'i';
			dest[nLen-2] = 'e';
			dest[nLen-1] = NULL_CHAR;

			result = getSearchedItem (db, dest);
			if (result != NULL)
			{
				*count = pushEngWordResult (buf, *count, result, "", "ed");
				return TRUE;
			}
			else
				return FALSE;
		}
	}
	else
	{
		if (syllable < 2)
			return FALSE;
		if ((dest[nLen-3] == 'k') && (dest[nLen-4] == 'c') && 
				(isVowel(dest[nLen-5]) == TRUE) && (syllable > 2))
		{
			dest[nLen-2] = NULL_CHAR;
			result = getSearchedItem (db, dest);
			if (result != NULL)
			{
				*count = pushEngWordResult (buf, *count, result, "", "ed");
				return TRUE;
			}
			else
				dest[nLen-3] = NULL_CHAR;
		}
		else
		{
			if ((dest[nLen-3] == dest[nLen-4]) &&
				(isVowel (dest[nLen-3]) == FALSE))	// ������ ��ġ��..
			{
				dest[nLen-2] = NULL_CHAR;
				result = getSearchedItem (db, dest);
				if (result != NULL)
				{
					*count = pushEngWordResult (buf, *count, result, "", "ed");
					return TRUE;
				}
				else
					dest[nLen-3] = NULL_CHAR;
			}
			else		// ������ ��ġ�� ������
			{
				// �� �κп��� created --> create �� d �� �����Ѵ�...
				// �׷��� suited --> suit �� �Ǿ�� ��...
				// ING ó�� �κ��� �����Ͻÿ�...
				if ((dest[nLen-2] == 'p') || (dest[nLen-2] == 't') || (dest[nLen-2] == 'k'))
					dest[nLen-1] = NULL_CHAR;
				else
					dest[nLen-2] = NULL_CHAR;

				result = getSearchedItem (db, dest);
				if ((result != NULL) && (syllable > 1))
				{
					*count = pushEngWordResult (buf, *count, result, "", "ed");
					return TRUE;
				}
				else
				{
					dest[nLen-2] = NULL_CHAR;
					result = getSearchedItem (db, dest);
					//if ((result != NULL) && (syllable > 1))
					if (result != NULL)
					{
						*count = pushEngWordResult (buf, *count, result, "", "ed");
						return TRUE;
					}
				}

				return FALSE;
			}
		}
	}

	result = getSearchedItem (db, dest);

	if (result != NULL)
	{
		*count = pushEngWordResult (buf, *count, result, "", "ed");
		return TRUE;
	}

	return FALSE;
}

int analyzeERComp (char* dest, FINAL_INFO* buf, int *count, int syllable)
{
	////////////////////////////////////////////////////////////////
	//
	// 1. er�� ��ȣ��... (��� ǰ�� ������ �ʼ���..)
	// 2. ���� �ߺ�
	// 3. ier �� y ����
	//
	////////////////////////////////////////////////////////////////

	char* result;
	int nLen = strlen (dest);

	if (syllable < 2)
		return FALSE;

	if ((dest[nLen-3] == dest[nLen-4]) &&
		(isVowel (dest[nLen-4]) == FALSE))
	{
		dest[nLen-3] = NULL_CHAR;
		
		result = getSearchedItem (db, dest);
		if (result != NULL)
		{
			*count = pushEngWordResult (buf, *count, result, "", "er");
			return TRUE;
		}
	}
	else
	{
		dest[nLen-1] = NULL_CHAR;
		result = getSearchedItem (db, dest);
		if ((result != NULL) && (syllable > 1))
		{
			*count = pushEngWordResult (buf, *count, result, "", "er");
			return TRUE;
		}
		else
		{
			if (dest[nLen-3] == 'i')
			{
				dest[nLen-3] = 'y';
				dest[nLen-2] = NULL_CHAR;
			}
			else		
				dest[nLen-2] = NULL_CHAR;

			result = getSearchedItem (db, dest);
			if ((result != NULL) && (syllable > 1))
			{
				*count = pushEngWordResult (buf, *count, result, "", "er");
				return TRUE;
			}
		}
	}

	return FALSE;
}

int analyzeESTSup (char* dest, FINAL_INFO* buf, int *count, int syllable)
{
	char* result;
	int nLen = strlen (dest);

	if (syllable < 2)
		return FALSE;

	if ((dest[nLen-4] == dest[nLen-5]) &&
		(isVowel (dest[nLen-5]) == FALSE))
	{
		dest[nLen-4] = NULL_CHAR;
		
		result = getSearchedItem (db, dest);
		if (result != NULL)
		{
			*count = pushEngWordResult (buf, *count, result, "", "est");
			return TRUE;
		}
	}
	else
	{
		dest[nLen-2] = NULL_CHAR;
		result = getSearchedItem (db, dest);
		if ((result != NULL) && (syllable > 1))
		{
			*count = pushEngWordResult (buf, *count, result, "", "est");
			return TRUE;
		}
		else
		{
			if (dest[nLen-4] == 'i')
			{
				dest[nLen-4] = 'y';
				dest[nLen-3] = NULL_CHAR;				
			}
			else
				dest[nLen-3] = NULL_CHAR;

			result = getSearchedItem (db, dest);
			if ((result != NULL) && (syllable > 1))
			{
				*count = pushEngWordResult (buf, *count, result, "", "est");
				return TRUE;
			}
		}
	}

	return FALSE;
}

int analyzeINGGerund (char* dest, FINAL_INFO* buf, int *count, int syllable)
{
	/////////////////////////////////////////////////////////////////
	//
	// 1. ���� �ߺ�
	// 2. -e ����
	// 3. vowel + c�� ��� k�� �߰�
	//    ex) panic -> panicking
	// 4. ing �տ� y�� �ְ� �������� ��� ye�� ���� 
	//    ex) lie <-- lying, die <-- dying
	//
	////////////////////////////////////////////////////////////////

	char* result;
	int nLen = strlen (dest);

	if (syllable < 2)
	{
		if (dest[nLen-4] == 'y')  	//��Ȯ���� ���̰� 5
		{
			dest[nLen-4] = NULL_CHAR;
			dest[nLen-4] = 'i';
			dest[nLen-3] = 'e';
			result = getSearchedItem (db, dest);
			if (result != NULL)
			{
				*count = pushEngWordResult (buf, *count, result, "", "ing");
				return TRUE;
			}
		}
		return FALSE;
	}

	if ((dest[nLen-4] == dest[nLen-5]) &&
		(isVowel (dest[nLen-5]) == FALSE))	// ���� �ߺ�	
	{
		dest[nLen-3] = NULL_CHAR;
		result = getSearchedItem (db, dest);

		if (result != NULL)
		{
			*count = pushEngWordResult (buf, *count, result, "", "ing");
			return TRUE;
		}
		else
		{
			dest[nLen-4] = NULL_CHAR;
			result = getSearchedItem (db, dest);

			if (result != NULL)
			{
				*count = pushEngWordResult (buf, *count, result, "", "ing");
				return TRUE;
			}
		}

		return FALSE;
	}

	if ((dest[nLen-4] == 'k') && (dest[nLen-5] == 'c') && 
			(isVowel(dest[nLen-6]) == TRUE) && (syllable > 2))	// k ����
	{
		dest[nLen-3] = NULL_CHAR;
		result = getSearchedItem (db, dest);

		if (result != NULL)
		{
			*count = pushEngWordResult (buf, *count, result, "", "ing");
			return TRUE;
		}
		else
		{
			dest[nLen-4] = NULL_CHAR;
			result = getSearchedItem (db, dest);

			if (result != NULL)
			{
				*count = pushEngWordResult (buf, *count, result, "", "ing");
				return TRUE;
			}
			else
				return FALSE;
		}
	}

	// ��� �� ��Ģ�� �Ϲ������� �ʴ�.... Ȯ��������...  ǰ�� ������ �־�� ��
	// ex) creat >> create, �ݷ�) suiting --> suit �� �м��Ǿ�� ��
	if ((dest[nLen-4] == 'p') || (dest[nLen-4] == 'k') || (dest[nLen-4] == 't'))
	{
		dest[nLen-3] = 'e';
		dest[nLen-2] = NULL_CHAR;
	}
	
	result = getSearchedItem (db, dest);
	if (result != NULL)
	{
		*count = pushEngWordResult (buf, *count, result, "", "ing");
		return TRUE;
	}
	else
	{
		dest[nLen-3] =  NULL_CHAR;

		result = getSearchedItem (db, dest);
		if (result != NULL)
		{
			*count = pushEngWordResult (buf, *count, result, "", "ing");
			return TRUE;
		}
	}

	return FALSE;
}


int HANL_AnalyzeEnglish (FINAL_INFO* resultBuf, char* word, int tokeType)
{
	int count = 0;
	int nLen = 0;
	int nPos = 0;
	int i = 0;
	int j = 0;
	int doubleConsChecked = FALSE;
	int syllable = 0;
	int nState = 0;
	int type = 0;

	char* dest;
	char suffix[TOKEN_MAX_SIZE];
	char prefix[TOKEN_MAX_SIZE];
	char* result;
	char* end;
	char* tmp;

	suffix[0] = NULL_CHAR;
	prefix[0] = NULL_CHAR;

	////////////////////////////////////////////////////////////////
	//
	// # �Ϲ����� ���� �Է��� �ѱ� ���¼� �м��⿡�� �ҹ��ڷ� �Ѿ�
	// ���Ƿ� ���⼭�� ���� ó���� ���� �ʴ´�.
	//
	////////////////////////////////////////////////////////////////
	nLen = strlen(word);
	for (i = 0; i < nLen; i++)
		checkStateOfSyllable (word[i], &nState, &syllable);
	dest = word;

	if (dest[nLen-1] == '\'')
		dest[nLen-1] = NULL_CHAR;
	
	for (end = dest; *end != '\0'; end++)
		if (*end == '-') strncpy (end, end + 1, strlen(end));
	
	// 1�ܰ� : �Է´ܾ ������ �����ϴ��� �˻��ϱ�
	result = getSearchedItem (infl, dest);
	if (result != NULL)
	{
		count = pushEngWordResult (resultBuf, count, result, "", "");
#ifndef AFFIXMORE
		return count;
#endif
/*		
		if ((type == ING_GERUND_TYPE) || (type == ED_PAST_TYPE))
		{
			// ��� �м��ض�!!!
		}
#ifndef AFFIXMORE
		else
			return count;
#endif		
*/
	}
	
	// 2�ܰ� : �Է´ܾ ��Ģ��ȭ�� �ϴ��� �˻��ϱ�
	result = getSearchedItem (db, dest);
	if (result != NULL)
	{
		// ���� ������� �� �м��� ���� ������ ������ ����..
		count = pushEngWordResult (resultBuf, count, result, "", "");
#ifndef AFFIXMORE
		return count;
#endif		
	}

	type = getSuffixType (dest);
	
	///////////////////////////////////////////////////////////////////////
	//
	// @ ������ ���� ��Ģ ����
	// - es, s, 's, ed, er, est, ing
	//
	// : ���� Ÿ���� �߰��� �� �ִ�.
	//
	///////////////////////////////////////////////////////////////////////
	switch (type)
	{
	case NO_SUFFIX_TYPE:
		break;
	case ES_PL_TYPE:
		if (analyzeESPl (dest, resultBuf, &count, syllable) == TRUE)
			return count;
		else
			break;
	case S_PL_TYPE:
		if (analyzeSPl (dest, resultBuf, &count) == TRUE)
			return count;
		else
			break;
	case S_POSS_TYPE:
		if (analyzeSPoss (dest, resultBuf, &count) == TRUE)
			return count;
		else
			break;
	case ED_PAST_TYPE:
		if (analyzeEDPast (dest, resultBuf, &count, syllable) == TRUE)
			return count;
		else
			break;
	case ER_COMP_TYPE:
		if (analyzeERComp (dest, resultBuf, &count, syllable) == TRUE)
			return count;
		else
			break;
	case EST_SUP_TYPE:
		if (analyzeESTSup (dest, resultBuf, &count, syllable) == TRUE)
			return count;
		else
			break;
	case ING_GERUND_TYPE:
		if (analyzeINGGerund (dest, resultBuf, &count, syllable) == TRUE)
			return count;
		else
			break;
	default:
		break;
	}
	
	if (syllable < 2)
		return count;

	nLen = strlen (dest);
	
	// 2�ܰ� : ���̻� �м��ϱ�
	if (searchSuffix (dest, nLen, &nPos))	// ���̻簡 �����ϸ�
	{
		for (i = nPos, j = 0; i < nLen; i++, j++)
			*(suffix + j) = *(dest + i);
		suffix[j] = NULL_CHAR;

		tmp = dest;
		tmp[nPos] = NULL_CHAR;
		if (nPos > 2)
		{
			if ((tmp[nPos-1] == tmp[nPos-2]) && (isVowel(tmp[nPos-2]) == FALSE))
				doubleConsChecked = TRUE;
		}

		nLen = strlen (tmp);
		if ((j == 1) && (suffix[0] == 's') && (isVowel (tmp[nLen-1]) == TRUE))
		{
			tmp[nLen] = suffix[0];
			tmp[nLen+1] = NULL_CHAR;
			suffix[0] = NULL_CHAR;
			nLen++;
		}
		else if ((j == 1) && (suffix[0] == 'y') && (syllable < 2))
		{
			tmp[nLen] = suffix[0];
			tmp[nLen+1] = NULL_CHAR;
			suffix[0] = NULL_CHAR;
			nLen++;		 
		 }
		
		result = getSearchedItem (db, tmp);
		if (result != NULL)		// && (doubleConsChecked == FALSE))
		{
			count = pushEngWordResult (resultBuf, count, tmp, "", suffix);
			strcpy (dest, tmp);
			/////////////////////////////////////////////////////////////
			// �������� ������ ���...
			/////////////////////////////////////////////////////////////
			if ((isVowel(suffix[0])) && (doubleConsChecked == FALSE))
			{
				tmp[nLen] = 'e';
				tmp[nLen+1] = NULL_CHAR;
				result = getSearchedItem (db, tmp);
				
				if (result != NULL)
				{
					count = pushEngWordResult (resultBuf, count, result, "", suffix);
					strcpy (dest, result);
				}
			}
		}
		else
		{
			/////////////////////////////////////////////////////////////
			// �������� ������ ���...
			/////////////////////////////////////////////////////////////
			if ((isVowel(suffix[0])) && (doubleConsChecked == FALSE))
			{
				tmp[nLen] = 'e';
				tmp[nLen+1] = NULL_CHAR;

				result = getSearchedItem (db, tmp);

				if (result != NULL)
				{
					count = pushEngWordResult (resultBuf, count, result, "", suffix);
					strcpy (dest, result);
				}
				else
				{

					tmp[nLen-1] = 'y';
					tmp[nLen] = NULL_CHAR;
					result = getSearchedItem (db, tmp);

					if (result != NULL)
					{
						count = pushEngWordResult (resultBuf, count, result, "", suffix);
						strcpy (dest, result);
					}
					else
					{
						tmp[nLen-1] = NULL_CHAR;
						result = getSearchedItem (db, tmp);

						if (result != NULL)
						{
							count = pushEngWordResult (resultBuf, count, result, "", suffix);
							strcpy (dest, result);
						}
					}
				}				
			}
			else
			{
				if (tmp[nLen-1] == 'i')
				{
					tmp[nLen-1] = 'y';
					tmp[nLen] = NULL_CHAR;
					result = getSearchedItem (db, tmp);

					if (result != NULL)
					{
						count = pushEngWordResult (resultBuf, count, result, "", suffix);
						strcpy (dest, result);
					}
				}
			}
			
			if (doubleConsChecked == TRUE)
			{
				tmp[nLen-1] = NULL_CHAR;
				result = getSearchedItem (db, tmp);
				if (result != NULL)
				{
					count = pushEngWordResult (resultBuf, count, result, "", suffix);
					strcpy (dest, result);
				}
				else
				{
					result = getSearchedItem (infl, tmp);
					if (result != NULL)
					{
						count = pushEngWordResult (resultBuf, count, result, "", suffix);
						strcpy (dest, result);
					}
				}
			}
			else
			{
				result = getSearchedItem (infl, tmp);
				if (result != NULL)
				{
					count = pushEngWordResult (resultBuf, count, result, "", suffix);
					strcpy (dest, result);
				}
			}
		}
	}
	/*
	nLen = strlen (dest);
 	�ణ ���ʿ��� �ܰ�...
	// 3�ܰ� : ���λ� �м��ϱ�
	if (searchPrefix (dest, nLen, &nPos))
	{
		for (i = 0, j = 0; i < nPos;)
			prefix[j++] = dest[i++];
		prefix[j] = NULL;

		for (i = nPos, j = 0; i < nLen;)
			tmp[j++] = dest[i++];
		tmp[j] = NULL;

		result = getSearchedItem (db, tmp);
		if (result != NULL)
		{
			count = pushEngWordResult (resultBuf, count, result, prefix, suffix);
			strcpy (dest, result);
		}

		result = getSearchedItem (infl, tmp);
		if (result != NULL)
		{
			count = pushEngWordResult (resultBuf, count, result, prefix, suffix);
			strcpy (dest, result);
		}
	}
*/	
	return count;
}


