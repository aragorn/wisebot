/**
 *
 * 'Test.c' for testing...
 *
 */

//#include "affile.h"
//#include "dicsearch.h"
#include "dema.h"
#include <time.h>
#include <stdio.h>

#include "auto_config.h"

#define DIC_DIR			ROOTDIR "/RunEnv"

int main (int argc, char* argv[])
{
	char buf[128];
	char tmp[128];
	int count = 0;
	int i = 0;
	int k = 1;
	FILE* fp;
	clock_t start, finish;
	double duration;
	FINAL_INFO eng[8];

	startDaumEMA (DIC_DIR "/prefix.lst",
				  DIC_DIR "/suffix.lst",
				  DIC_DIR "/entrylist.db",
				  DIC_DIR "/inflist.db");
	
	if (argc == 2)
	{
		fp = fopen (argv[1], "r");

		start = clock();	// �ð� ������ ���� ���� �ð�..
		while (!feof(fp))
		{
			fscanf (fp, "%s", buf);
			//printf ("###%s###\n", buf);
			count = HANL_AnalyzeEnglish (eng, buf, 0);

			printf ("[%.5d] [%d] [%s] : ", k++, count, buf);
			for (i = 1; i < (count+1); i++)
				printf ("[%s] ", eng->result_info[i].word);

			printf ("\n");
		}
		finish = clock();	// �ð� ������ ���� ��ġ�� �ð�..

		printf ("DURATION : %2.5f seconds\n", (double) (finish - start) / CLOCKS_PER_SEC);

		fclose(fp);
	}
	else
	{
		while (fgets(buf,1024,stdin) != NULL)
		{
			start = clock();	// �ð� ������ ���� ���� �ð�..
			buf[strlen(buf)-1] = '\0';
			count = HANL_AnalyzeEnglish (eng, buf, 0);
			for (i = 1; i < (count+1); i++)
				printf ("%d | ROOT: %s\n", i, eng->result_info[i].word);
	
			finish = clock();	// �ð� ������ ���� ���� �ð�..
			printf ("TOTAL COUNT : %d\n", count);
			printf ("DURATION : %2.5f seconds\n", (double) (finish - start) / CLOCKS_PER_SEC);
		}
	}
	endDaumEMA();
	
	return 1;
}
