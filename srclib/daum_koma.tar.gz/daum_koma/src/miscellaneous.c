#include <stdio.h>
#include <string.h>
#include "moran.h"
#include "moran_tagdef.h"

int HANL_InitilizeValuable(FINAL_INFO   *final_info, int *retidx, int   *iReanalysis, int   *TokenType)
{
	int	i;
	// XXX: need to memset?
	for(i = 1; i <= final_info->numberoftoken; i++)
	{
		final_info->result_info[i].word[0] = '\0';
		final_info->result_info[i].tag[0] = '\0';
		final_info->result_info[i].where = '\0';
	}
	//memset(&final_info->result_info[1],	0,result_info_size*(final_info->numberoftoken));
	final_info->numberoftoken = 1;

	*retidx = 0;
	*iReanalysis = 0;
	*TokenType = 0;
	return 1;
}

int HANL_SetResult_info(RESULT_INFO *result_info,
						int *ridx,  
						char *inputstring, 
						char *tag,
						int iWHERE_ALIAS_KEYWORD,
						int start,
						int end,
						int Ltagnum,
						int Rtagnum,
						int expand)
{
	sprintf(result_info[*ridx].word,"%s",inputstring);
	result_info[*ridx].where = iWHERE_ALIAS_KEYWORD;
	if(start > 0)   result_info[*ridx].start = start;
	if(end   > 0)   result_info[*ridx].end = end;
	if(Ltagnum > 0) result_info[*ridx].Ltag = Ltagnum;
	if(Rtagnum > 0) result_info[*ridx].Rtag = Rtagnum;
	result_info[*ridx].level = 1;
	result_info[*ridx].type  = 0;
	result_info[*ridx].Raction = 0;

	if(expand >= 0)
		result_info[*ridx].expand = expand;
	else
		result_info[*ridx].expand = 0;

	if(tag != NULL) strcpy(result_info[*ridx].tag, tag);

	return YES;
}

/**
 * HANL_put_result()
 *
 * res[]�� ���� ����� ���� �ִ´�.
 * word�� ���ξ�
 * type�� �ܾ�(���ξ�)�� ǰ�� �� ó�� ���
 * index�� res[]�� ���� index �̴�.
 * HANL_put_result()�� �־��� word, tag�� ����� �ִ´�
 */

int HANL_put_result(FINAL_INFO * final_info,char    *word, int action,int idx_type,char *pos, STACKS_INFO * stacks)
{
	int index;

#ifdef  DEBUG1
	printf("HANL_put_result()\n");
#endif
	if(final_info->numberoftoken == 0)  final_info->numberoftoken = 1;

	index = final_info->numberoftoken;

	/* ACTION == APPEND_IF_SAME_LEFT�� ��� ������ ����� ������ ���� Ÿ���ΰ�쿡�� ���ΰ� �ƴϸ� ������.
	 * ������ ��쿡 ������ �޸� �м������� �ϳ��� ���̾� �־�� �� */
	if(action == APPEND_IF_SAME_LEFT)
	{
		if(index == 0)          return(index);

		if(final_info->result_info[index-1].type != idx_type)           return(index);

		strcat(final_info->result_info[index-1].word,word);
		strcpy(final_info->result_info[index].tag,pos);
		return(index);
	}

	/* ACTION == APPEND_LEFT�ΰ�� ������ ����� ���δ�. ���̻��� ��쿡 ���̾�� �ϴ� ��찡 �߻��� �� ���� */
	if((action == APPEND_LEFT) && (index > 0) && (final_info->result_info[index-1].type == idx_type))
	{
		strcat(final_info->result_info[index-1].word,word);
		strcpy(final_info->result_info[index].tag,pos);
		return(index);
	}

	final_info->result_info[index].where = WHERE_GUESS_NOUN;
	final_info->result_info[index].Ltag =  L_NCN;
	final_info->result_info[index].Rtag =  R_J;
	final_info->result_info[index].type = idx_type;
	strcpy(final_info->result_info[index].tag,pos);

	if(strncmp(pos,"almost_name",11)!=0)        strcpy(final_info->result_info[index].word,word);

	final_info->result_info[index+1].type  = 0;

	return(index+1);
}


int HANL_InsertSlot(FINAL_INFO *final_info,
					FINAL_INFO *final_info_backup,
					RESULT_INFO *result_info,
					int *fidx,
					int *ridx,
					int *i)
{
	int j;

	if(final_info->numberoftoken == 1)
	{
		memcpy(&final_info->result_info[*fidx], &result_info[0], sizeof(final_info->result_info[0])*(*ridx));
		(*fidx) += (*ridx);
	}
	else
	{
		for( j = 1; j < final_info->numberoftoken; j++)
		{
			if(j == (*i))
			{
				memcpy(&final_info->result_info[*fidx], &result_info[0], sizeof(final_info->result_info[0])*(*ridx));
				*fidx += *ridx;
			}
			else
			{
				memcpy(&final_info->result_info[*fidx], &final_info_backup->result_info[j], sizeof(final_info->result_info[0]));
				*fidx += 1;
			}
		}
	}
	return (YES);
}

void HANL_InitializeFinal_Info(FINAL_INFO * final_info, int idx)
{
	*(final_info->result_info[idx].tag) = '\0';
	final_info->result_info[idx].where = 0;
	final_info->result_info[idx].expand = 0;
	final_info->result_info[idx].start = 0;
	final_info->result_info[idx].end = 0;
	//  memset(&final_info->result_info[idx],0,sizeof(final_info->result_info[0]));
}

int HANL_SetFinalinfo(FINAL_INFO *final_info,int idx,
					  int start,
					  int end,
					  int where,
					  int Lidx,
					  int Laction,
					  int Ltag,
					  int Ridx,
					  int Raction,
					  int Rtag,
					  char *tag,
					  int special_tag)
{


#ifdef  DEBUG1
	printf("HANL_SetFinalinfo()\n");
#endif
	final_info->result_info[idx].where = where;
	if(start >= 0)  final_info->result_info[idx].start = start;
	if(end >= 0)        final_info->result_info[idx].end = end;

	final_info->result_info[idx].Lidx = Lidx;
	final_info->result_info[idx].Ridx = Ridx;
	final_info->result_info[idx].Ltag = Ltag;
	final_info->result_info[idx].Rtag = Rtag;

	final_info->result_info[idx].Raction = Raction;
	final_info->result_info[idx].Laction = Laction;

	if(tag != '\0' && tag != NULL)  strcpy(final_info->result_info[idx].tag,tag);

	if(special_tag) final_info->result_info[idx].expand = -1;
	else            final_info->result_info[idx].expand = 0;
	return 1;

}

int HANL_CheckValidity(FINAL_INFO * final_info,int idx)
{

#ifdef  DEBUG1
	printf("HANL_CheckValidity()\n");
#endif
	if(     final_info->result_info[idx].where      == 0 && final_info->result_info[idx].type    == 0 &&
			final_info->result_info[idx].start      == 0 && final_info->result_info[idx].end     == 0 &&
			final_info->result_info[idx].Ltag       == 0 && final_info->result_info[idx].Rtag    == 0 &&
			final_info->result_info[idx].Lidx       == 0 && final_info->result_info[idx].Ridx    == 0 &&
			final_info->result_info[idx].Laction    == 0 && final_info->result_info[idx].Raction == 0)
		return FAIL;
	else    return  SUCCESS;
}

