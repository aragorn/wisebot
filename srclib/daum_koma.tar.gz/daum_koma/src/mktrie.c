/* $Id: mktrie.c,v 1.4 2006/04/19 04:23:24 nominam Exp $ */
#include	"trie.h"
#include	<stdio.h>
#include	<stdlib.h>
#include    <fcntl.h>
#include    <sys/stat.h>

static int	    TAGTYPE = 0;
static trie_node_t   *Index_List[1000000];
static int		Index_Seek[1000000];
static int	    NODE_NUM = 1;
static int	    NODE_SIZE = 1;
static int	    word_cnt = 1;
static char     *Data_File;
static char     *Data_File_Back;
static long     Data_File_Size;
static char     *Index_File;
static long     Index_File_Size;

#define		End_of_Keyword_Mark			"\t"
#define		End_of_Record_Mark			"\n"
#define		COMMENT_MARK				'#'

// XXX: use trie.c module instead of systemdic.c temporarily
#define ROOT_NODE		(trie->root_node)
static trie_t	*trie;

static void download_inmemory_trie_to_file(char *fn);
static int read_and_inmemory_trie_build(char *fn);
static void numbering_inmemory_trie_nodes(trie_node_t *node, int depth);

int main(int ac,char *ag[])
{ 
	int	i;

	// check parameter
	if(ac < 3) {
		fprintf(stderr,"���� :$%s �Է�ȭ�ϸ� ���ȭ�ϸ�\n",ag[0]);
		exit(1);
	}
	if(!strcmp(ag[1],ag[2]))
	{ 
		fprintf(stderr,"�Է�ȭ�ϰ� ���ȭ�ϸ��� ���� �� �����ϴ�.\n");
		exit(1);
	}

	// initialize dictionary handler
	trie = create_trie_handler();

	// read data & build dictionary
	read_and_inmemory_trie_build(ag[1]);
	optimize(trie, ROOT_NODE);
	numbering_inmemory_trie_nodes(ROOT_NODE, 0);
	download_inmemory_trie_to_file(ag[2]);

	return 0;
}

static int read_and_inmemory_trie_build(char *fn)/*{{{*/
{ 
	FILE  *fp,*fopen();
	char	record[10240];
	char	*data_start_position, *record_start_position, *record_end_position;
	int	rec_cnt=0;
	long	position, where, record_start, record_end, data_start;
	int   fd,what_first;
	struct stat   stbuf;
	int	new_data_start;
	char	*data_only;
	int	i;


	/* upload Data File */
	/* after building Index File, The data file will be dumped at the rear of index file */
	if(stat(fn,&stbuf) == -1) {
		fprintf(stderr,"Data File [%s] ERROR!!!\n",fn);
		return(-1);
	}
	Data_File = (char *)malloc(stbuf.st_size+1);
	Data_File_Back = (char *)malloc(stbuf.st_size+1);
	Data_File_Size = (unsigned long)(stbuf.st_size+1);
	fd = open(fn,O_RDONLY);
	read(fd,Data_File,stbuf.st_size);
	strcpy(Data_File_Back,Data_File);
	close(fd);

	where = 0;	/* start of Data File, the data's fseek position */
	record_start_position = Data_File;
	data_only = Data_File_Back;
	while(1) {
		rec_cnt++;
		if(*record_start_position == COMMENT_MARK) {
			while(*record_start_position != '\n') record_start_position++;
			while(*record_start_position == '\n') record_start_position++;
		}

		data_start_position = (char*)strstr(record_start_position, End_of_Keyword_Mark);
		if(data_start_position == NULL) break;
		*data_start_position = '\0';
		data_start_position += strlen(End_of_Keyword_Mark);
		record_end_position = (char*)strstr(data_start_position, End_of_Record_Mark);
		if(record_end_position == NULL) break;
		*record_end_position = '\0';
		record_end_position += strlen(End_of_Record_Mark);
		record_start = (record_start_position - Data_File);
		data_start = (data_start_position - Data_File);
		strcpy(record,record_start_position);

	   new_data_start = data_only - Data_File;
	   if(data_only == Data_File) {
		*data_only = '\0';
		data_only++;
		new_data_start = 1;
	   }
	   strcpy(data_only,Data_File+data_start);
	   data_only += strlen(Data_File+data_start);
	   *data_only = '\0';
	   data_only++;

	   if(trie_insert_entry(trie, record, new_data_start, 0) != 1) break;
	   record_start_position = record_end_position;
	   while(*record_start_position == '\n') record_start_position++;
	}
	Data_File_Size = (data_only - Data_File);
#ifdef	DEBUG
	printf("DATA FILE SIZE = %d -> %d\n", Data_File_Size, (data_only - Data_File));
	printf("DATA FILE = ");
	for(i=0;i<Data_File_Size;i++) 
	   if(Data_File[i] == '\0') printf("|"); else printf("%c", Data_File[i]);
	printf("\n");
#endif
	return(0);
}/*}}}*/

static void download_inmemory_trie_to_file(char    *fn)/*{{{*/
{
	FILE  *fp,*fopen();
	int   	i,j;
	trie_node_t     *cp;
	int		base,firsts=0,first_size=0;
	int		first_add[256];
	char		*data_only;
	unsigned char        size,add1,add2,add3,add4;
	unsigned long        yadd, dadd;
	int	data_start;

	fp = fopen(fn,"w");
	if(fp == NULL)
	{
		fprintf(stderr,"FILE WRITE ERROR [%s]\n",fn);
		exit(0);
	}
	for(i=0;i<256;i++) first_add[i] = 0;
	base = 256*4;

	for(cp=ROOT_NODE;cp != NULL;cp=cp->ynext) 		first_add[(unsigned char)cp->Str[0]] = Index_Seek[cp->index] + base;
#ifdef	DEBUG
	for(i=0;i<256;i++) if(first_add[i] != 0) printf("[%x] -> %d\n", i, first_add[i]);
#endif

	for(i=0;i<256;i++) 
	{
		yadd = first_add[i];
		add1 = (yadd & 0x00ff000000)>>24;
		add2 = (yadd & 0x0000ff0000)>>16;
		add3 = (yadd & 0x0000ff00)>>8;
		add4 =  yadd & 0x000000ff;
		fprintf(fp,"%c%c%c%c",add1,add2,add3,add4);
	}

	data_start = 256 * 4;
	for(i=1;i<NODE_NUM;i++) data_start += strlen(Index_List[i]->Str) + 9;

	for(i=1;i<NODE_NUM;i++) 
	{

		cp = Index_List[i];
		add1 = add2 = add3 = add4 = 0;
		if(cp->xnext != NULL) add1 = 0x80; else add1 = 0x00;
		if(cp->ynext != NULL) yadd = Index_Seek[cp->ynext->index] + base;
		else             yadd = 0;
		add1 = add1 | (yadd & 0x001f000000)>>24;
		add2 = (yadd & 0x0000ff0000)>>16;
		add3 = (yadd & 0x0000ff00)>>8;
		add4 =  yadd & 0x000000ff;
		fprintf(fp,"%c%c%c%c",add1,add2,add3,add4);

		if(cp->rsv0 != 0) dadd = data_start + cp->rsv0;
		else		   dadd = 0;
		add1 = (dadd & 0x00ff000000)>>24;
		add2 = (dadd & 0x0000ff0000)>>16;
		add3 = (dadd & 0x0000ff00)>>8;
		add4 =  dadd & 0x000000ff;
		fprintf(fp,"%c%c%c%c",add1,add2,add3,add4);

		fprintf(fp,"%s%c",cp->Str,0);

#ifdef	DEBUG
		  printf("\n");
		  printf("STRING  = [%s]\n", cp->Str);
		  if(cp->rsv0 != 0) printf("DATA    = [%s]\n", Data_File + cp->rsv0);
		  else			   printf("DATA    = [NULL]\n");
		  printf("STRLEN  = [%d]\n", strlen(cp->Str));
		  printf("KStart  = [%d]\n", cp->rsv1);
		  printf("DStart  = [%d]\n", cp->rsv0);
		  if(cp->xnext != NULL) printf("XNEXT = YES\n");
		  else 		 printf("XNEXT = NO\n");
		  if(cp->ynext != NULL) printf("YNEXT = [%x]\n", Index_Seek[cp->ynext->index]+base);
		  else 		 printf("YNEXT = NULL\n");
#endif
	}

	for(i=0;i<Data_File_Size; i++) fprintf(fp,"%c", Data_File[i]);

	fclose(fp);
}/*}}}*/

static void numbering_inmemory_trie_nodes(trie_node_t *node, int depth)/*{{{*/
{
	int i;

	if(node == NULL) return;
	Index_List[NODE_NUM] = node;
	Index_Seek[NODE_NUM+1] = Index_Seek[NODE_NUM] + strlen(node->Str) + 9; /* 4 + 4 + 1 */
	node->index = NODE_NUM++;

	if(node->xnext != NULL) {
		numbering_inmemory_trie_nodes(node->xnext,depth+1);
	}

	if(node->ynext != NULL) {
		numbering_inmemory_trie_nodes(node->ynext,depth);
	}
}/*}}}*/

