#include <stdio.h>
#include <string.h>
#include "moran.h"
#include "moran_tagdef.h"
#include "moran_grammar.h"
#include "HANL_error.h"

void print_zooword(char *pre, char *zoo, char *post)
{
	int	i;

	printf("%s", pre);

	for(i = 0; i < (int)strlen(zoo); i++)		printf("%c", zoo[i] & 0x7f);

	printf("%s", post);

}
void nprint_zooword(char *pre, char *zoo, char *post,int start, int end)
{
	int	i;

	printf("%s", pre);

	for(i=start;i<end;i++)		printf("%c", zoo[i] & 0x7f);

	printf("%s", post);

}

void HANL_error(int num,char * msg,char * func, int line)
{
	switch(num)
	{
		case HANL_DEFAULT : 
			fprintf(stderr, " -- %s : %d -- (%d)%s(%s)\n",func,line,num,"ERROR",msg);
			break;
		case HANL_PREDIC_OPEN_FAIL :
			fprintf(stderr, " -- %s : %d -- (%d)%s(%s)\n",func,line,num, "Can't open pre-analysis  dictionary file",msg);
			break;
		case HANL_ALIASDIC_OPEN_FAIL :
			fprintf(stderr, " -- %s : %d -- (%d)%s(%s)\n",func,line,num, "Can't open alias dictionary file",msg);
			break;
		case HANL_USERDIC_OPEN_FAIL :
			fprintf(stderr, " -- %s : %d -- (%d)%s(%s)\n",func,line,num, "Can't open user dictionary file",msg);
			break;
		case HANL_STOPWORDDIC_OPEN_FAIL :
			fprintf(stderr, " -- %s : %d -- (%d)%s(%s)\n",func,line,num, "Can't open stop-word dictionary file",msg);
			break;
		case HANL_SYSTEMDIC_OPEN_FAIL :
			fprintf(stderr, " -- %s : %d -- (%d)%s(%s)\n",func,line,num, "Can't open system dictionary file",msg);
			break;
		case HANL_FREQNOUNDIC_OPEN_FAIL :
			fprintf(stderr, " -- %s : %d -- (%d)%s(%s)\n",func,line,num, "Can't open noun-frequency dictionary file",msg);
			break;
		case HANL_OVERFLOW_STACK_SIZE :
			fprintf(stderr, " -- %s : %d -- (%d)%s\n",func,line,num, "overflow stack size");
			break;
		case HANL_OVERFLOW_RESULT_STRUCT :
			fprintf(stderr, " -- %s : %d -- (%d)%s\n",func,line,num, "overflow result_info structure");
			break;
		case HANL_EOJUL_TOO_LONG :
			fprintf(stderr, " -- %s : %d -- (%d)%s\n(%s)\n",func,line,num, "input eojul too long",msg);
			break;
		case HANL_OVERFLOW_TAG_LIST :
			fprintf(stderr, " -- %s : %d -- (%d)%s\n",func,line,num, "tag list array overflow");
			break;
		case HANL_STACK_POINTER_SMALL_THAN_ZERO :
			fprintf(stderr, " -- %s : %d -- (%d)%s\n",func,line,num, "stack pointer is small than zero");
			break;
		case HANL_INVALID_DATA :
			fprintf(stderr, " -- %s : %d -- (%d)%s\n",func,line,num, "invalid data");
			break;
	}
}
