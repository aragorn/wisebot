/****************************************************************
 *						DS OPTION				      			*
 *                                                              *
 *                       Program by Kim, Eung, Gyun				*
 *
 *                       email : jchern@daumcorp.com			*
 *                       at : 2005.11.04						*
 ****************************************************************/
#include 	"ds_option.h"
#include	"config.h"

typedef	struct	
{
	const	char	*m_Name;
	void	(*func)(void);
} STRUCT_FUNC_VALUE;

static STRUCT_FUNC_VALUE NLPfuncList[] = 
{
	{ "INDEX_SYNONLY"	,	Set_SIM_WORD_ONLY	},
	{ "INDEX_SYNORG"	,	Set_SIM_WORD_ORG	},
	{ "INDEX_SYNMULTI"	,	Set_SIM_WORD_MULTI	},
	{ "INDEX_EJIDX"		,	Set_EJIDX			},
	{ "INDEX_PHRASE"	, 	Set_COMB_NOUN		},
	{ "INDEX_VERB"		, 	Set_ROOT_VERB		},
	{ "INDEX_BASEIDX"	, 	Set_INDEXING_LEVEL1	},
	{ "INDEX_VERBADJIDX", 	Set_INDEXING_LEVEL2	},
	{ "INDEX_NUMENGIDX"	, 	Set_INDEXING_LEVEL3	},
	{ "INDEX_ALLIDX"	, 	Set_INDEXING_LEVEL4	},
    { NULL, 0 }
};

static STRUCT_FUNC_VALUE NLPIDXfuncList[] = 
{
    { "QUERY"			,	Set_BOOLEAN		},
    { NULL, 0 }
};

int	Check_hada_verb(int	i)
{
	if(i == R_NCP_N	||
			i == R_NCP_Y || 
			i == R_NCP_L ||
			i == R_NCP_F_Y ||
			i == R_NCP_F_L ||
			i == R_NCP_F_N ||
			i == R_NCP_NOCOM_N ||
			i == R_NCP_NOCOM_Y ||
			i == R_NCP_NOCOM_L ||
			i == R_NCP_NX ||
			i == R_NCP_YX ||
			i == R_NCP_LX )	return 1;
	else	return 0;


}

int Check_Predic_tag(int i)
{
	return Check_INDEXING_LEVEL(L_Tag_Idx[i]);
}

int Is_VERB(int i)
{
	if(i == L_PV || i == L_PA)	return 1;
	else						return 0;
}
int	Is_Rtag_EOMI(int i)
{
	if(i == R_EP || i == R_EF || i == R_EF_END || i == R_EF_CON || i == R_EFA || i == R_ETN)	return 1;
	else						return 0;
}

int	Is_NCP(int i)
{
	if(i == L_NCP)	return 1;
	else						return 0;
}

/** Option String�� �޾� ���� OPCode�� ��ȯ�Ͽ� �����ϴ� �Լ� */
int DS_NLPGetOpcode(const char *szOptionString,int *opcode)
{
	int i;
	char *token;
	char szBuffer[1024];

	if(szOptionString == NULL) return *opcode;
	strncpy(szBuffer, szOptionString, 1023);
	szBuffer[1023] = '\0';

	token = strtok( szBuffer, ":");

	for(i=0;NLPIDXfuncList[i].m_Name!=NULL;i++) 
	{
		if(strcmp(NLPIDXfuncList[i].m_Name, token) == 0) 
		{
			NLPIDXfuncList[i].func();
			while((token=strtok(NULL, ","))!= NULL) 
			{
				for(i=0;NLPfuncList[i].m_Name!=NULL; i++) 
				{
					if(strcmp(NLPfuncList[i].m_Name, token) == 0) 
					{
						NLPfuncList[i].func();
						break;
					}
				}
			}
			return 1;
		}
	}
	return 0;
}
