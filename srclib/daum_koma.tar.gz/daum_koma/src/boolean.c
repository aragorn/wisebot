/* $Id: boolean.c,v 1.14 2006/04/19 07:01:14 nominam Exp $ */
#ifdef WIN32
#	include "dha_win32.h"
#endif

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>

#ifndef WIN32
#	include <unistd.h>
#endif

#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h> 
#include <math.h>

#include "miscellaneous.h"
#include "errorlog.h"
#include "moran.h"
#include "manage_dict.h"
#include "moran_tagdef.h"
#include "moran_grammar.h"

int HANL_Check_ExpandString(FINAL_INFO *final_info, char *inputstring)
{
	int i;
	int expand = 0;
	int copy_num = 0;
	//  FINAL_INFO  final_info_backup;

#ifdef  DEBUG1
	printf("HANL_Check_ExpandString()\n");
#endif
	for(i = 1; i < final_info->numberoftoken; i++)
	{
		if(strcmp(inputstring,final_info->result_info[i].word) == 0)
		{
			if( i > 1 && final_info->result_info[i].expand > 0)
				final_info->result_info[i].expand = 0;

			HANL_InitializeFinal_Info(final_info,i);
			copy_num = final_info->numberoftoken - i - 1;

			if(copy_num > 0)
				memmove(&final_info->result_info[i],
						&final_info->result_info[i+1],
						sizeof(final_info->result_info[0])*copy_num);
			final_info->numberoftoken--;

			return 0;
		}
		if(final_info->result_info[i].expand != 0)  expand++;
	}

	if(expand > 0)
	{
		if(final_info->numberoftoken == (expand + 1))
			return 2;
		else
			return 1;
	}
	else   
		return 0;
}


int	HANL_Make_Boolean_Exp(
		FINAL_INFO * final_info,
		char * inputstring, 
		char * szResultBuffer, 
		char ** pqueryresult, 
		char * queryresult, 
		int TokenType,
		int exist_special_char)
{
	int	i = 0;
	int	j = 0;
	int	ret = 0;
	int	loop = 0;
	int	size = 0;
	int retidx = 0;
	char	*indexBound = queryresult+4096;
	int sim_level = Get_SIM_WORD();

	char *oper[] = {" | ", " & "};
	char result[MAX_RESULT][MAX_DICT_REF];

#ifdef  DEBUG1
	printf("HANL_Make_Boolean_Exp()\n");
#endif

	if(final_info->numberoftoken == 0)
	{
		sprintf(result[retidx++],"{ %s }",inputstring);
	}
	else if(final_info->numberoftoken == 1)
	{
		if(final_info->result_info[1].word[0] == '\0')
		{
			sprintf(result[retidx++],"{ %s }",inputstring);
		}
		else
		{
			if(final_info->result_info[1].Ltag = L_PV && Check_ROOT_VERB() && strcmp(inputstring,final_info->result_info[1].word) != 0)
			{
				sprintf(result[retidx++], "{ %s | %s }",inputstring ,final_info->result_info[1].word);
			}
			else
			{
				sprintf(result[retidx++], "{ %s }",final_info->result_info[1].word);
			}
		}
	}
	else if(final_info->numberoftoken == 2)
	{
		if(strcmp(inputstring,final_info->result_info[1].word) == 0 || inputstring[0] == '\0')
		{
			snprintf(result[retidx++],sizeof(result[retidx]),"{ %s }", final_info->result_info[1].word);
		}
		else
		{
			if(Check_INPUT_WORD())
			{
				snprintf(result[retidx++],sizeof(result[retidx]),"{ %s | %s }", inputstring, final_info->result_info[1].word);
			}
			else
			{
				snprintf(result[retidx++],sizeof(result[retidx]),"{ %s }", final_info->result_info[1].word);
			}
		}

	}
	else
	{
		ret = HANL_Check_ExpandString(final_info,inputstring);

		if(ret > 0)
		{
			if(ret == 1)
			{
				snprintf(result[retidx++],sizeof(result[retidx]),"{ %s | ( ", inputstring);
				for(i = 1; i < final_info->numberoftoken ;i++)
				{
					if(final_info->result_info[i].expand != 0)
					{
						if(final_info->result_info[i].expand == 1 && final_info->result_info[i].expand == -1)
						{
							snprintf(result[retidx++],sizeof(result[retidx]),"( %s | %s ) ", final_info->result_info[i].word,final_info->result_info[i+1].word);
							i++;
						}
						else
						{
							if(final_info->result_info[i].expand == -1)
							{
								snprintf(result[retidx++],sizeof(result[retidx]),"( %s | ", final_info->result_info[i].word);
							}
							else
							{
								snprintf(result[retidx++],sizeof(result[retidx]),"( %s ) | ( ", final_info->result_info[i].word);
							}

							loop = abs(final_info->result_info[i].expand);
							for(j = 0; j < loop;j++)
							{
								if(retidx >= MAX_RESULT)	
								{
									warn("%s[%d]Buffer overflow result_info",inputstring,retidx);
									goto OVER;
								}
								if(j != 0)		
								{
									if(final_info->result_info[i].expand > 0)	strcpy(result[retidx++],oper[1]);
									else										strcpy(result[retidx++],oper[0]);
								}

								strcpy(result[retidx++],final_info->result_info[i + j + 1].word);
							}
							if(retidx >= MAX_RESULT)	
							{
								warn("%s[%d]Buffer overflow result_info",inputstring,retidx);
								goto OVER;
							}
							strcpy(result[retidx++]," )");
							i += j;
						}
					}
					else
					{
						if(retidx >= MAX_RESULT)
						{
							warn("%s[%d]Buffer overflow result_info",inputstring,retidx);
							goto OVER;
						}
						strcpy(result[retidx++],final_info->result_info[i].word);

					}
					if((i + 1) < final_info->numberoftoken)	
					{
						if(retidx >= MAX_RESULT)
						{
							warn("%s[%d]Buffer overflow result_info",inputstring,retidx);
							goto OVER;
						}

						strcpy(result[retidx++],oper[1]);
					}
				}
				if(retidx >= MAX_RESULT)
				{
					warn("%s[%d]Buffer overflow result_info",inputstring,retidx);
					goto OVER;
				}
				strcpy(result[retidx++]," ) }");
			}
			else
			{
				i = 1;
				if(final_info->result_info[i].where == WHERE_ALIAS_KEYWORD && (sim_level == 3 || sim_level == 4))
				{
					snprintf(result[retidx++],sizeof(result[retidx]),"{ %s | ", inputstring);
				}
				else
				{
					if(Check_INPUT_WORD() && Check_HADA_VERB() && strcmp(inputstring,final_info->result_info[1].word) != 0)
					{
						snprintf(result[retidx++],sizeof(result[retidx]),"{ %s | ", inputstring);
					}
					else
					{
						snprintf(result[retidx++],sizeof(result[retidx]),"{ ");
					}
				}
				for(i = 1; i < final_info->numberoftoken ;i++)
				{
					strcpy(result[retidx++],final_info->result_info[i].word);
					if((i + 1) != final_info->numberoftoken)						strcpy(result[retidx++],oper[0]);
				}
				if(retidx >= MAX_RESULT)
				{
					warn("%s[%d]Buffer overflow result_info",inputstring,retidx);
					goto OVER;
				}
				strcpy(result[retidx++]," }");
			}
		}
		else
		{

			if(final_info->numberoftoken == 2)
							{
												if(retidx >= MAX_RESULT)
																	{
																							warn("%s[%d]Buffer overflow result_info",inputstring,retidx);
																												goto OVER;
																																}
																if(strcmp(final_info->result_info[1].word,inputstring) != 0)
																					{
																											if(Check_ROOT_VERB() || final_info->result_info[1].Ltag == L_PV)
																																		sprintf(result[retidx++], "{ %s | %s }",inputstring, final_info->result_info[1].word);
																																else
																																							sprintf(result[retidx++], "{ %s }",final_info->result_info[1].word);
																																				}
																				else
																										sprintf(result[retidx++], "{ %s }",inputstring);
																							}
						else
										{
															snprintf(result[retidx++],sizeof(result[retidx]),"{ %s | ( ", inputstring);

																			i = 1;
																							for(; i < final_info->numberoftoken ;i++)
																												{
																																		strcpy(result[retidx++],final_info->result_info[i].word);
																																							if(retidx >= MAX_RESULT)
																																													{
																																																				warn("%s[%d]Buffer overflow result_info",inputstring,retidx);
																																																										goto OVER;
																																																															}

																																												if((i + 1) != final_info->numberoftoken)						strcpy(result[retidx++]," & ");
																																																}
																											if(retidx >= MAX_RESULT)
																																{
																																						warn("%s[%d]Buffer overflow result_info",inputstring,retidx);
																																											goto OVER;
																																															}
																															strcpy(result[retidx++]," ) }");

																																		}








		}

	}

	if(queryresult[0] != '\0')
	{
		strcat(*pqueryresult,oper[1]);
		*pqueryresult = *pqueryresult + 3;
	}


	strcat(*pqueryresult,result[0]);
	*pqueryresult = *pqueryresult + strlen(result[0]);
	for(i = 1; i < retidx; i++)
	{
		size = strlen(result[i]);
		if(indexBound < *pqueryresult+size)
		{
			warn("output buffer overflow(4096)");
			break;
		}
		strcat(*pqueryresult,result[i]);
		*pqueryresult = *pqueryresult + size;
	}
	return (YES);

OVER:
	if(queryresult[0] != '\0')
	{
		strcat(*pqueryresult," & ");
		*pqueryresult = *pqueryresult + 3;
	}


	strcat(*pqueryresult,result[0]);
	*pqueryresult = *pqueryresult + strlen(result[0]);
	for(i = 1; i < retidx - 1; i++)
	{
		size = strlen(result[i]);
		if(indexBound < *pqueryresult+size)
		{
			warn("output buffer overflow(4096)");
			break;
		}
		if(i == (retidx - 2))
		{
			if(result[i][1] == '&')	
				break;
		}
		strcat(*pqueryresult,result[i]);
		*pqueryresult = *pqueryresult + size;
	}

	size = strlen(" ) } ");
	strcat(*pqueryresult," ) } ");
	*pqueryresult = *pqueryresult + size;

	return (YES);
}
