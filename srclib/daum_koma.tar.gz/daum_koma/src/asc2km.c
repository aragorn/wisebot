/***********************************************************************
	�ý��� �����ڵ�(Zoo Code)�� ������ ASCII�������� ��ȯ

				programmed by Cho, Young Hwan
					choyh@csking.kaist.ac.kr

***********************************************************************/
#include <stdio.h>
#include <ctype.h>
#include "dha.h"

void print_asc2km(char	*ascword)
{
	unsigned char		*cp;

	cp = (unsigned char *)ascword;
	while(*cp) 
	{
		if(*cp == '/') 
		{
			cp++;
			//printf("%c",toupper(*cp));
			printf("%c",tolower(*cp));
		}
		else
			printf("%c",(*cp)+128);
		cp++;
	}
	printf("\t ");
}

int	main(int	argc, char	*argv[])
{ 
	char  line[2048], ascword[2048], temp[1024];
	int   lnum, rnum, i=0;
	int   count = 0;
	FILE	*fp;

	fp = fopen(argv[1],"w");
	while(fgets(line,1024,stdin) != NULL) 
	{
		count++;
		if(sscanf(line,"%s %d %d",ascword, &lnum, &rnum) != 3) 
		{
			fprintf(stderr,"error at line[%s %s %d]\n",__FILE__,__FUNCTION__,__LINE__);
			continue;
		}
		print_asc2km(ascword);
		printf("%d \t%d\n", lnum, rnum);
		HANL_ks2kimmo(ascword,temp);
		fprintf(fp,"%s\t%d\t%d\n",temp,lnum, rnum);

	}
	fclose(fp);
}

