#include "manage_dict.h"
#include "hash.h"


#define REPEAT			1000

int main ()
{
	int datalen;
	char buf[16], outbuf[16];
	dic_t dic;
	hash_t *hash;

	// init hash handler
	printf("\ntest init...\n");
	if (hash_init(&dic) == -1) {
		fprintf(stderr, "cannot create hash\n");
		exit(1);
	}
	hash = (hash_t*)dic->childobj;
	hash->datasize = sizeof(struct _var);

	// open
	printf("\ntest open...\n");
	if (hash_open(&dic) == -1) {
		fprintf(stderr, "cannot open hash\n");
		exit(1);
	}

	// insert
	printf("\ntest insert...\n");
	for (i=0; i<REPEAT; i++) {
		sprintf(buf, "test%d", i);
		if (hash_insert(hash, buf, buf, strlen(buf)+1) == -1) {
			fprintf(stderr, "cannot insert key[%s], value[%s]\n", buf, buf);
			exit(1);
		}
		printf("insert key[%s], value[%s]\n", buf, buf);
	}

	// search
	printf("\ntest search...\n");
	for (i=0; i<REPEAT; i++) {
		sprintf(buf, "test%d", i);
		if (hash_search(hash, buf, outbuf, &datalen) == -1) {
			fprintf(stderr, "cannot search key[%s]\n", buf);
			exit(1);
		}
		printf("search key[%s], value[%s:%d]\n", buf, outbuf, datalen);
	}

	// close
	hash_close(dic);

	return 0;
}
