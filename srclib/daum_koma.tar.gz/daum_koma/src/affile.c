/*
 * FILE : affile.c
 */

#include "affile.h"
/////////////////////////////////////////////////////
// �������� ����


/////////////////////////////////////////////////////

#ifdef DEBUG
static int c = 0;
#endif

XNode* createXNode (char nChar, char nState, char nLevel)
{
	XNode* node = (XNode*) malloc (sizeof(XNode));

	node->curChar 	= nChar;
	node->curState	= nState;
	node->curLevel	= nLevel;
	
	node->downNode	= NULL;
	node->nextNode	= NULL;

#ifdef DEBUG1
	printf ("�޸� �Ҵ�>>> : %c\t%d\n", nChar, ++c);
#endif
	
	return node;
}

void deleteXNode (XNode* node)
{
	if (node)
	{
		if (node->downNode != NULL)
			deleteXNode (node->downNode);

		if (node->nextNode != NULL)
			deleteXNode (node->nextNode);
#ifdef DEBUG1
		printf ("�޸� ����<<<<< : %c\t%d\n", node->curChar, c--);
#endif 
		free (node);
	}
}

void displayXNodeList (XNode* node)
{
#ifdef DEBUG
	XNode* nNode = node->downNode;

	while (nNode != NULL)
	{
		printf ("LOADED...: %c\t", nNode->curChar);
		displayXNodeList (nNode);
		nNode = nNode->nextNode;
		printf ("\n");
	}
#endif
}

XNode* checkSiblingNode (XNode* node, char nChar, char state, char level)
{
	XNode* prevNode;
	XNode* nNode = node;

	while (nNode != NULL)
	{
		if (nNode->curChar == nChar)
		{
			if (state == ACCEPTED_STATE)
			{
				nNode->curState = ACCEPTED_STATE;
				nNode->curLevel = level;	// �� �����ο��� ���ʿ��� ����� ��...
			}
			return nNode;
		}
		prevNode = nNode;
		nNode = nNode->nextNode;
	}

	nNode = createXNode (nChar, state, level);
	prevNode->nextNode = nNode;

	return nNode;
}

int makeSuffixNode (XNode* node, char* s, char sl, char gLevel)
{
	XNode* nNode;
	int i = strlen (s) - 1;
	char nState = DENIED_STATE;
	
	if (gLevel < sl)
		return FALSE;
#ifdef DEBUG1
	printf ("INPUT: %s\t%d \n", s, i);
#endif 
	
	while (i > -1)
	{
		if (i == 0)
			nState = ACCEPTED_STATE;

		if (node->downNode != NULL)
			node = checkSiblingNode (node->downNode, s[i], nState, sl);
		else
		{
			nNode = createXNode (s[i], nState, sl);
			node->downNode = nNode;
			node = nNode;
		}
		i--;
	}

	return TRUE;
}

int makePrefixNode (XNode* node, char* p, char pl, char gLevel)
{
	XNode* nNode;
	int i = 0;
	int nLen = strlen(p);
	char nState = DENIED_STATE;
	
	if (gLevel < pl)
		return FALSE;

	while (i < nLen)
	{
		if (i == (nLen - 1))
			nState = ACCEPTED_STATE;

		if (node->downNode != NULL)
			node = checkSiblingNode (node->downNode, p[i], nState, pl);
		else
		{
			nNode = createXNode (p[i], nState, pl);
			node->downNode = nNode;
			node = nNode;
		}
		i++;
	}

	return TRUE;
}

XNode* loadSuffixFile (const char* file, char level)
{
	XNode* node;
	XNode* root;
	FILE* fp;
	char suffix[READ_LINE_MAX];
	char suffixLevel[8];

	if ((fp = fopen (file, "r")) == NULL)
	{
		fprintf (stderr, "Error in opening suffix file(%s)\n",file);
		return NULL;
	}

	node = createXNode (NULL_CHAR, DENIED_STATE, NULL_CHAR);
	root = node;
	
	while (!feof(fp))
	{
		fscanf (fp, "%s %s", suffix, suffixLevel);
#ifdef DEBUG1
		printf ("SUFFIX : %s\n", suffix);
#endif 
		makeSuffixNode (node, suffix, suffixLevel[0]-48, level);
		node = root;
	}

	fclose(fp);

	return node;
}

XNode* loadPrefixFile (const char* file, char level)
{
	XNode* node;
	XNode* root;
	FILE* fp;
	char prefix[READ_LINE_MAX];
	char prefixLevel[8];

	if ((fp = fopen (file, "r")) == NULL)
	{
		fprintf (stderr, "Error in opening suffix file(%s)\n",file);
		return NULL;
	}

	node = createXNode (NULL_CHAR, DENIED_STATE, NULL_CHAR);
	root = node;
	
	while (!feof(fp))
	{
		fscanf (fp, "%s %s", prefix, prefixLevel);
		makePrefixNode (node, prefix, prefixLevel[0]-48, level);
		node = root;
	}

	fclose(fp);

	return node;
}
