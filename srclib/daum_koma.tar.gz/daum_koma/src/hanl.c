#include	<stdio.h>
#include	<string.h>
#include	"moran.h"

int 	linecount = 0;
int main (int argc, char * argv[])
{
	FILE	*fp;
	int	i = 1, j = 0, pre = 1, size = 0, TokType = 0, _TokType = 0, idx_final_info = 0;
	char	*p,	*q,	*token, msg[1024], res[10240],	result[10240],	buffer[10240];
	void *final_info;

	if(argc == 2)		fp = fopen(argv[1],"r");	else			fp = stdin;

	final_info=(FINAL_INFO*)HANL_DirectNLPInit("/data3/jchern/HANL/RunEnv");
	_TokType = 0;


	
	
	
	
	printf("INPUT : ");
	while(fgets(buffer, 10240, stdin)) 
	{
		size = strlen(buffer);
		if(buffer[size - 1] == '\n')	buffer[size - 1] = '\0';
		HANL_DirectNLPProcess(final_info,NULL, buffer,10240,result);
		printf("%s\n",result);
		/*
		size = strlen(linebuf);
		if(linebuf[size - 1] == '\n')	linebuf[size - 1] = '\0';

		printf("%s\tRESULT : ",linebuf);
		linecount++;
		idx_final_info = 0;
		if(linebuf[0] == '\n')	continue;
		p = linebuf;
#ifdef	DEBUG
		printf("LEVEL\tTYPE\tSTART\tEND\tWHERE\tLtag\tRtag\tLidx\tRidx\tLaction\tRaction\tWORD\tTAG\n");
#endif
		while(RUN)
		{
			token = strstr(p," ");
			if(token == NULL || token[0] == '\0')
			{
				if(*p == '\0' ||  p == NULL)					break;
				else
				{
					while(RUN)
					{
						if ((TokType = KSC5601_GetTextToken (&p, buffer)) == TOKEN_NULL) break;

						size = strlen(buffer);
						if(size > 100)
						{
							strncpy(final_info.result_info[i].word, buffer,50);
							final_info.result_info[i].word[50] = '\0';
							strcpy(final_info.result_info[i].tag, "UNKNOW");
							i++;
							i = print_result(&final_info,1);

							for(j = 0; j < i; j++)
							{
								init_final_info(&final_info,j);
							}
							continue;
						}
						strcpy(res,buffer);
						TokenProcessing(TokType,buffer, res, msg);
						strcpy(buffer,res);

						if(CheckRunningCondition(TokType))
						{
							HANL_get_index(buffer,1, &final_info);
							if(final_info.result_info[0].where == WHERE_PREDICTIONARY)								pre = 0;
							else    pre = 1;
							i = pre;

							if(final_info.result_info[i].where == WHERE_PREDICTIONARY)	i = 0;
							i = print_result(&final_info,i);

							for(j = 0; j < i; j++)
							{
								init_final_info(&final_info,j);
							}
						}
						else
						{
							if(TokType != TOKEN_BLANK)
							{
								final_info.result_info[0].where = WHERE_PREPROCESSING;
								strcpy(final_info.result_info[0].word, buffer);
								strcpy(final_info.result_info[0].tag,msg);
								print_result(&final_info,0);
							}
						}
						if(*p == '\0' ||  p == NULL)		break;

					}
				}
				_TokType = 0;
				if(*p == '\0' ||  p == NULL)		break;
			}
			else
			{
				token[0] = '\0';
				token++;
			}

			while(1) 
			{
				if ((TokType = KSC5601_GetTextToken (&p, buffer)) == TOKEN_NULL) break;

				strcpy(res,buffer);
				TokenProcessing(TokType,buffer, res, msg);
				strcpy(buffer,res);

				if(CheckRunningCondition(TokType))
				{
					HANL_get_index(buffer,1, &final_info);

					if(final_info.result_info[0].where == WHERE_PREDICTIONARY)	pre = 0;
					else														pre = 1;
					i = pre;
					i = print_result(&final_info,i);

					for(j = 0; j < i; j++)
					{
						init_final_info(&final_info,j);
					}
				}
				else
				{
					if(TokType != TOKEN_BLANK)
					{
						final_info.result_info[0].where = WHERE_PREPROCESSING;
						strcpy(final_info.result_info[0].word, buffer);
						strcpy(final_info.result_info[0].tag,msg);
						print_result(&final_info,0);
					}
				}

				_TokType = 0;
			}
			p = token;
		}
		printf ("\n");
		//printf("\nINPUT : ");
		*/
		break;
	}
	//printf ("LINECOUNT:%d\n",linecount);
	HANL_DirectNLPFinal(final_info);
	return 0;
}

int	CheckRunningCondition(int TokType)
{
	/*
	if(TokType == TOKEN_KOREAN || TokType == TOKEN_KOR_HANJA || TokType == TOKEN_MIX_KOR_DGT)
			return 1;
	else 	return 0;
	*/

}

int	 print_result(FINAL_INFO * final_info, int i)
{
	while(1)
	{
		if(final_info->result_info[i].tag[0] == '\0' && i != 0 && final_info->result_info[i].word[0] == '\0')	break;
#ifdef	DEBUG
		printf("%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
				final_info->result_info[i].level,
					final_info->result_info[i].type,
					final_info->result_info[i].start,
					final_info->result_info[i].end,
					final_info->result_info[i].where,
					final_info->result_info[i].Ltag,
					final_info->result_info[i].Rtag,
					final_info->result_info[i].Lidx,
					final_info->result_info[i].Ridx,
					final_info->result_info[i].Laction,
					final_info->result_info[i].Raction,
					final_info->result_info[i].word,
					final_info->result_info[i].tag);	fflush(stdout);

#endif
				printf("%s/",final_info->result_info[i].word);			
				printf("%s/",final_info->result_info[i].tag);			
				fflush(stdout);
			i++;
	}
	return i;

}


int	TokenProcessing(int TokType, char * buffer, char *res, char *msg)
{
	switch(TokType)
	{
		/*
		case TOKEN_KOREAN : 		strcpy(msg,"nTOKEN_KOREAN");		break;
		case  TOKEN_KOR_HANJA:		HANL_hanja2ks_str(buffer,res);		strcpy(msg,"nTOKEN_KOR_HANJA");				break;
		case  TOKEN_KOR_JAPAN_H:	strcpy(msg,"nTOKEN_KOR_JAPAN_H");  	break;
		case  TOKEN_KOR_JAPAN_K:	strcpy(msg,"nTOKEN_KOR_JAPAN_K");  	break;
		case  TOKEN_ENGLISH:		strcpy(res, buffer);				Stem(res); 	strcpy(msg,"nTOKEN_ENGLISH");	break;
		case  TOKEN_ENGLISH2:		strcpy(msg,"nTOKEN_ENGLISH2");	 	break;
		case  TOKEN_DIGIT:			strcpy(msg,"nTOKEN_DIGIT");		   	break;
		case  TOKEN_DIGIT2:			strcpy(msg,"nTOKEN_DIGIT2");		break;
		case  TOKEN_MIX_ENG_DGT:	strcpy(msg,"nTOKEN_MIX_ENG_DGT");  	break;
		case  TOKEN_MIX_KOR_DGT:	strcpy(msg,"nTOKEN_MIX_KOR_DGT");  	break;
		case  TOKEN_SPECIAL:		strcpy(msg,"TOKEN_SPECIAL");		break;
		case  TOKEN_CONTROL:		strcpy(msg,"TOKEN_CONTROL");		break;
		case  TOKEN_BLANK:			strcpy(msg, "TOKEN_BLANK");			break;
		case  TOKEN_UNKNOWN1:		strcpy(msg,"nTOKEN_UNKNOWN1");		break;
		case  TOKEN_UNKNOWN2:		strcpy(msg,"nTOKEN_UNKNOWN2");		break;
		case  TOKEN_FUNC_BLANK:		strcpy(msg,"nTOKEN_FUNC_BLANK");		break;
		default :			strcpy(msg,"ERROR");				break;
		*/
	}
	return 0;
}
