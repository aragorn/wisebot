#include <stdio.h>
#include "hantype.h"
#include "convert.h"
#include "hancode.h"

hancode HANL_euckr2johab(hancode * word, hancode *dest)
{
	hancode x;
	x = WANSUNG[*word];
	if (dest != NULL) *dest = (x == 65535) ? 0 : HANCODE[x][1];
	return (x == 65535) ? 0 : HANCODE[x][1];
}

hancode HANL_johab2euckr(hancode * word, hancode *dest)
{
	hancode x;
	x = JOHAB[*word];
	if (dest != NULL) *dest = (x == 65535) ? 0 : HANCODE[x][0];
	return (x == 65535) ? 0 : HANCODE[x][0];
}
