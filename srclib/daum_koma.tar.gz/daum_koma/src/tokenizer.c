#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "moran.h"

static int cType1[] = {
       T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,	//007
       T_BL,   T_BL,   T_EX,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,	//015
       T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,	//023
       T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,	//031
       T_BL,   T_BF,   T_BF,   T_SC,   T_SC,   T_SC,   T_SC,   T_BF,	//039
       T_BL,   T_BL,   T_SC,   T_SC,   T_BL,   T_SC,   T_BF,   T_SC,	//047		//44 = ,
       T_DG,   T_DG,   T_DG,   T_DG,   T_DG,   T_DG,   T_DG,   T_DG,	//055
       T_DG,   T_DG,   T_SC,   T_SC,   T_SC,   T_SC,   T_SC,   T_SC,	//063
       T_SC,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,	//071	
       T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,	//079
       T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,	//087
       T_EN,   T_EN,   T_EN,   T_BL,   T_SC,   T_BL,   T_SC,   T_SC,	//095
       T_SC,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,	//103
       T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,	//111
       T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,	//119
       T_EN,   T_EN,   T_EN,   T_SC,   T_SC,   T_SC,   T_SC,   T_CK,	//127

       T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,	//135
       T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,	//143
       T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,	//151
       T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,	//159
       T_U1,   T_U2,   T_U2,   T_U2,   T_KO,   T_U2,   T_U2,   T_U2,	//167
       T_U2,   T_U2,   T_JH,   T_JK,   T_U2,   T_U1,   T_U1,   T_U1,	//175
       T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,	//183
       T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,	//191
       T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,	//199
       T_KO,   T_U1,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,	//207
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,	//215
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,	//223
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,	//231
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,	//239
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,	//247
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_U1,   T_U1 	//255
};

/**
 * �ܷ����� �Ϻ���� �� �ܷ��������� �Ǵ��ϱ� ����    ������ �����ϴ����� �˻�
 * ��� ������ ���� �˻���������. �̵�Ͼ��� �ܷ��� �˻縦 �ϱ����� ���
 */
int HANL_FromJapan(char * str)
{
	while(*str != '\0')
	{
		if(HANL_is_jongsung(str))       return (NO);

	}
	return (YES);

}

int		HANL_GetTokenType(char	s)
{
	return cType1[(unsigned char)(s)];
}

int		HANL_GetToken(char	*input,	char	*output,	char	**csp, int	*TokenType, int	size,int	*retsize)
{
	int		CharType;
	int		len = 1;
	int		exit = 0;
	int		sclen = 0;
	int		dglen = 0;
	int		enlen = 0;
	*csp = input;

	for(;;)
	{
		CharType = HANL_GetTokenType(**(csp));
		if(len == size-1 || sclen > 20)		
		{
			CharType = T_BL;
			goto BLANK;
		}
#ifdef	DEBUG
		printf("-- %d[%d]\n",CharType,(unsigned char)**csp);
#endif


		//if(*TokenType != 0 && (*TokenType & CharType) != CharType && (dglen > 0 || enlen > 0))	
		if(0)	
		{
			exit = 1;
		}
		else
		{
			if(!(CharType == T_BL || CharType == T_EX))
				*TokenType |= CharType;
			else
			{
				goto BLANK;
			}
		}



		switch(CharType)
		{
			case T_BL :
#ifdef	CHAR
				fprintf(stderr,"%s:%d\tBLANK(%d)\n",__FUNCTION__,__LINE__,len);
#endif	
				if(exit)	goto BLANK;	//T_BL
				*output = '\0';
				input = (*csp)++;
				len++;
				*retsize = len;
				return T_BL;
			case T_EX :
#ifdef	CHAR
				fprintf(stderr,"%s:%d\tEXIT(%d)\n",__FUNCTION__,__LINE__,len);
#endif	
				input = (*csp)++;//T_EX
				len++;
				*output = '\0';
				*retsize = len;
				return T_EX;
			case T_HJ :
#ifdef	CHAR
				fprintf(stderr,"%s:%d\tHANJA(%d)\n",__FUNCTION__,__LINE__,len);
#endif	
				*(output++) = *((*csp)++);//T_HJ
				len++;
				if((0x80 & **csp) != 0x80)
				{

					*output = '\0';
					**csp = '\0';
					*(*csp)++;
					**csp = '\0';
					*retsize = len;
					return T_EX;
				}

				*(output++) = *((*csp)++);
				len++;
				break;
			case T_KO :
#ifdef	CHAR
				fprintf(stderr,"%s:%d\tKOREAN(%d)\n",__FUNCTION__,__LINE__,len);
#endif	
				if(enlen > 4 || dglen > 4 || exit)
				{
					*TokenType &= ~CharType;
					goto BLANK;	//T_KO
				}
				*(output) = *((*csp)++);
				len++;
				if((0x80 & **csp) != 0x80)
				{

					*output = '\0';
					**csp = '\0';
					*(*csp)++;
					**csp = '\0';
					*retsize = len;
					return T_EX;
				}
				output++;
				CharType = HANL_GetTokenType(**(csp));
				*(output++) = *((*csp)++);
				len++;
				*TokenType |= CharType;
				break;
			case T_EN :	
#ifdef	CHAR
				fprintf(stderr,"%s:%d\tENGLISHKOREAN(%d)\n",__FUNCTION__,__LINE__,len);
#endif	
				if(exit)	goto BLANK; //T_EN	
				**csp = tolower(**csp);
				*(output++) = *((*csp)++);
				len++;
				enlen++;
				break;
			case T_U1 :
#ifdef	CHAR
				fprintf(stderr,"%s:%d\tUNKNOWN1(%d)\n",__FUNCTION__,__LINE__,len);
#endif	
				*(output++) = *((*csp)++);//T_U1
				len++;
				break;
			case T_JK :
			case T_JH :
			case T_U2 :
#ifdef	CHAR
				fprintf(stderr,"%s:%d\tJAPAN or UNKNOWN2(%d)\n",__FUNCTION__,__LINE__,len);
#endif	
				*(output++) = *((*csp)++);//T_JH,T_JH,T_U2
				len++;
				if((0x80 & **csp) != 0x80)
				{

					*output = '\0';
					**csp = '\0';
					*(*csp)++;
					**csp = '\0';
					*retsize = len;
					return T_EX;
				}
				*(output++) = *((*csp)++);
				len++;
				break;
			case T_BF :
#ifdef	CHAR
				fprintf(stderr,"%s:%d\tSPECIAL(.,\"etc(%d)\n",__FUNCTION__,__LINE__,len);
#endif	
				if(enlen > 0)			//T_BF
				{
					if(exit)	goto BLANK;	
					**csp = tolower(**csp);
					*(output++) = *((*csp)++);
					len++;
					enlen++;
					*TokenType &= ~CharType;
					break;
				}
			case T_DG :
#ifdef	CHAR
				fprintf(stderr,"%s:%d\tDIGIT(%d)\n",__FUNCTION__,__LINE__,len);
#endif	
				if(exit)	goto BLANK;	//T_DG
				*(output++) = *((*csp)++);
				len++;
				dglen++;
				break;
			case T_SC :
#ifdef	CHAR
				fprintf(stderr,"%s:%d\tSPECIAL CHAR(%d)\n",__FUNCTION__,__LINE__,len);
#endif	
				if(enlen > 0 || dglen > 0)//T_SC
				{
					*TokenType &= ~CharType;
				}
				sclen++;
				len++;
				*(output++) = *((*csp)++);
				break;
			case T_CK :
#ifdef	CHAR
				fprintf(stderr,"%s:%d\tCONTROL CHAR(%d)\n",__FUNCTION__,__LINE__,len);
#endif	
				if(exit)	goto BLANK;	//T_CK
				*(output++) = *((*csp)++);
				len++;
				break;
		}

	}

BLANK:
	*output = '\0';
	**csp = '\0';
	*(*csp)++;
	*retsize = len;
	return T_BL;
}

int	HANL_GetTokenCont(char	**bp, char	*cp)
{
	if(cp == NULL)
	{
		return (NO);
	}
	else
	{
		*bp =  cp;
		if(**bp == '\0' || **bp == '\n')
			return (NO);
		else	
			return (YES);
	}
}

int HANL_IfMixOtherCharactorSet(int TokenType)
{

#ifdef  DEBUG1
	printf("HANL_IfMixOtherCharactorSet()\n");
#endif
	int		kor = 0;
	int		eng = 0;
	int		dig = 0;

	if(TokenType & T_KO)	kor = 1;
	if(TokenType & T_DG)	dig = 1;
	if(TokenType & T_EN)	eng = 1;

	if(kor + dig + eng >= 2)
		return YES;
	else
		return NO;
}


#ifdef	MAIN
int		main(int argc, char * argv[])
{

	char	buffer[1024];
	char	output[1024];
	char	*cp;
	char	*op;
	char	*bp;
	int		size = 0;
	int		TokenType;
	FILE	*fp;
	op = output;
	bp = buffer;

	if(argc != 2)
	{
		fprintf(stderr,"%s <input file>\n",argv[0]);
		exit(1);
	}
	fp = fopen(argv[1],"r");
	
	while(fgets(bp,1024,fp) != NULL)
	{
		for(;;)
		{
			TokenType = 0;
			if(HANL_GetToken(bp,op,&cp,&TokenType,1024,&size) == -1)
			{
				printf("Error GetToken Func\n");
			}
			if(TokenType & T_EX)
			{
				printf("%s\n-------------------\n",op);
				bp = buffer;
			}
			else
			{
				printf("%s\n",op);
			}
			if(strcmp(op,"�ϸ�") == 0)
			{
				printf("breaking");
			}
			if(HANL_GetTokenCont(&bp,cp) == NO)
			{
				bp = buffer;
				op = output;
				break;
			}
		}
	}
	fclose(fp);
	return 0;
}
#endif

