/* $Id: mkdic.c,v 1.4 2006/04/19 04:23:24 nominam Exp $ */
/**********************************************************************

  ����� ������ �ҿ�� ������ �������ϴ� ���� v2.0

  Designed & Implemented by
  Cho, Young Hwan
  choyh@csking.kaist.ac.kr
  1997. 4. 4

  �ý��� ������ ����� �����ϳ� ���������� ���� ����
  ���ܵǾ��� �ѱ۰� �����ڰ� ���̾� ���Ǵ� ���� �����ϴ�.

 **********************************************************************/
#include 	"trie.h"
#include	<stdio.h>
#include	<stdlib.h>
#include	"moran.h"
#include	"moran_tagdef.h"

static int	    TAGTYPE = 0;
static trie_node_t  *Index_List[1000000];
static int		Index_Seek[1000000];
static int 		NODE_NUM = 1;
static int		NODE_SIZE = 1;
static int     	word_cnt = 1;
static int 		no_zoo_no_rev=0;

// XXX: use trie.c module temporarily
#define ROOT_NODE		(trie->root_node)
static trie_t 	*trie;

static void load_text_dict(char * fn);
static void down_load_dict(char *fn);
static int read_word(FILE *fp,char *rzooword);
static void numbering(trie_node_t *node, int depth);

int main(int ac, char *ag[])
{
	int	i;

	// check parameter
	if(ac < 3) 
	{ 
		fprintf(stderr,"���� :$%s [-x] �Է�ȭ�ϸ� ���ȭ�ϸ�\n",ag[0]);
		fprintf(stderr,"            -x : �ҿ�� ������ ���� ��\n");
		exit(1);
	}
	if(!strcmp(ag[1],"-x"))
	{
		no_zoo_no_rev=1;
		i=2;
	}
	else
	{
		no_zoo_no_rev=0;
		i=1;
	}
	if(!strcmp(ag[i],ag[i+1]))
	{ 
		fprintf(stderr,"�Է�ȭ�ϰ� ���ȭ�ϸ��� ���� �� �����ϴ�.\n");
		exit(1);
	}

	// initialize dictionary handler
	trie = create_trie_handler();

	// load text dictionary & build dictionary
	load_text_dict(ag[i]);
	optimize(trie, ROOT_NODE);
	numbering(ROOT_NODE, 0);
	down_load_dict(ag[i+1]);

	return 0;
}

static void down_load_dict(char *fn)/*{{{*/
{
	FILE  *fp,*fopen();
	int   	i,j;
	trie_node_t     *cp;
	int		base,firsts=0,first_size=0;
	unsigned char	info1,info2,info3,info4,info5;

	fp = fopen(fn,"w");
	if(fp == NULL) 
	{
		fprintf(stderr,"FILE WRITE ERROR [%s]\n",fn);
		exit(0);
	}
	for(cp=ROOT_NODE;cp!= NULL;cp=cp->ynext) firsts++;
	first_size = firsts*4;
	info1 = firsts;
	info2 = (TAGTYPE & 0xff00)>>8;
	info3 = (TAGTYPE & 0x00ff);
	info4 = (first_size & 0xff00)>>8;
	info5 = (first_size & 0x00ff);
	fprintf(fp,"%c%c%c%c%c",info1,info2,info3,info4,info5);
	fprintf(fp,"*");
	base = ftell(fp)+first_size;
	cp = ROOT_NODE;
	while(cp != NULL) {

		unsigned char	size,tag,add1,add2,add3;
		unsigned long	yadd;

		yadd = Index_Seek[cp->index] + base;
		add1 = (yadd & 0x007f0000)>>16;
		add2 = (yadd & 0x0000ff00)>>8;
		add3 =  yadd & 0x000000ff;
		fprintf(fp,"%c%c%c%c",cp->Str[0],add1,add2,add3);

#ifdef	DEBUG
		printf("*** %d %c %x %x %x\n",size,cp->Str[0],add1,add2,add3);
#endif
		cp = cp-> ynext;
	}
	for(i=1;i<NODE_NUM;i++) 
	{
		unsigned char	size,b1,b2,b3,b4;
		unsigned long	yadd;

		cp = Index_List[i];
		b1 = (cp->rsv0 & 0x03fc) >> 2;
		b2 = (cp->rsv0 & 0x03) << 6;
		if(cp->xnext != NULL) b2 = (0x20|b2);
		if(cp->ynext != NULL) yadd = Index_Seek[cp->ynext->index] + base;
		else		 yadd = 0;
		b2 = b2 | (yadd & 0x001f0000)>>16;
		b3 = (yadd & 0x0000ff00)>>8;
		b4 =  yadd & 0x000000ff;
		size = strlen(cp->Str)+4;

#ifdef DEBUG
		printf("[%x] ",ftell(fp));
		printf("%d %-10s %x %x %x %x\n",size,cp->Str,b1,b2,b3,b4);
#endif
		fprintf(fp,"%c%s%c%c%c%c",size,cp->Str,b1,b2,b3,b4);
	}

	fclose(fp);
}/*}}}*/

static void load_text_dict(char * fn)/*{{{*/
{
	FILE  *fp,*fopen();
	int   tagtype, cnt, tags[20][2], tmp_tag[2], i;
	unsigned char  keyword[1024];
	unsigned char  keyword2[1024];
	unsigned char  keyword3[1024];

	if((fp = fopen(fn,"r")) == NULL) 
	{
		fprintf(stderr,"DICT [%s] Not FOUND!!!\n",fn);
		exit(0);
	}
	while(1) 
	{
		word_cnt++;
		if(read_word(fp,keyword) != 1)
			break;

		if(keyword[0] == 'L' + 128) 
		{
			trie_insert_entry(trie, keyword, UNOUN_L_TAG, 0);
			continue;
		}
		if(HANL_is_jongsung(keyword[strlen(keyword) - 1]) == YES) 
		{
			trie_insert_entry(trie, keyword, UNOUN_Y_TAG, 0);
			continue;
		}
		trie_insert_entry(trie, keyword, UNOUN_N_TAG, 0);
	}
	fclose(fp);
}/*}}}*/

static int read_word(FILE *fp,char *rzooword)/*{{{*/
{
	char	ksword[1024], zooword[1024], line[1024];
	int	i,size;

	while(1) 
	{
		if(fgets(line,1024,fp) == NULL) return(0);
		if(sscanf(line,"%s",rzooword) != 1) continue;
		if(no_zoo_no_rev==0)
		{
			HANL_ks2kimmo(rzooword,zooword);
			strcpy(rzooword,zooword);
		}
		break;
	} 
	return(1);
}/*}}}*/

static void numbering(trie_node_t *node, int depth)/*{{{*/
{
	int i;

	if(node == NULL) return;
	Index_List[NODE_NUM] = node;
	Index_Seek[NODE_NUM+1] = Index_Seek[NODE_NUM] + strlen(node->Str) + 5;
	node->index = NODE_NUM++;

	if(node->xnext != NULL) {
		numbering(node->xnext, depth+1);
	}

	if(node->ynext != NULL) {
		numbering(node->ynext, depth);
	}
}/*}}}*/

