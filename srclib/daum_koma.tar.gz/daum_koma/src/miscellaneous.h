#ifndef _MISCELLANEOUS_H
#define _MISCELLANEOUS_H 1

#include "moran.h"

int HANL_InitilizeValuable(FINAL_INFO *final_info,
						   int *retidx,
						   int *iReanalysis,
						   int *TokenType);

int HANL_SetResult_info(RESULT_INFO *result_info,
						int *ridx,  
						char *inputstring, 
						char *tag,
						int iWHERE_ALIAS_KEYWORD,
						int start,
						int end,
						int Ltagnum,
						int Rtagnum,
						int expand);

int HANL_put_result(FINAL_INFO *final_info,
					char *word,
					int action,
					int idx_type,
					char *pos,
					STACKS_INFO * stacks);

int HANL_InsertSlot(FINAL_INFO *final_info,
					FINAL_INFO *final_info_backup,
					RESULT_INFO *result_info,
					int *fidx,
					int *ridx,
					int *i);

void HANL_InitializeFinal_Info(FINAL_INFO * final_info, int idx);

int HANL_SetFinalinfo(FINAL_INFO *final_info,int idx,
					  int start,
					  int end,
					  int where,
					  int Lidx,
					  int Laction,
					  int Ltag,
					  int Ridx,
					  int Raction,
					  int Rtag,
					  char *tag,
					  int special_tag);

int HANL_CheckValidity(FINAL_INFO * final_info,int idx);

#endif
