/* $Id: hash.c,v 1.3 2006/03/09 08:17:53 hanadmin Exp $ */

/**
 * Memory based Dynamic hash
 *   key size : variable
 *   data size: variable
 */
#include <stdio.h>
#include "hash.h"

/* bucket structure:
 *  +---------------------------------------------------------------------------
 *  | bucket header | ("key...." \0) | datasize (int) | data ... |  ( repeat )
 *  +---------------------------------------------------------------------------
 */

// data number per bucket (byte)
#define DEFAULT_BUCKET_SIZE 	        (512)

// the initial number of dir
#define DEFAULT_DIR_SIZE				(16)

typedef struct _bucket_header_t {
	unsigned int level:24;
	unsigned int key:24;
	unsigned int datanum:16;
	unsigned int occupiedsize:16;
} bucket_header_t;

/* return size of data
 *  a: keysize
 *  b: datasize */
#define DATA_SIZE(a,b)					((a) + 1 + sizeof(int) + (b))
/* return bucket pointer (void *)
 *  a: dynamic hash object pointer
 *  b: offset of bucket */
#define BUCKET(a,b)                     ((a)->buckets[(b)/(a)->bucketsize] + \
										(b) % (a)->bucketsize)
/* return bucket header structure pointer (bucket_header_t *)
 *  b: point of bucket */
#define BUCKET_HEADER(b)                ((bucket_header_t *)(b))
/* return data header structure pointer (data_header_t *)
 * a: bucket start pointer (void *)
 * b: size of each data
 * i: order number of data */
#define DATA_HEADER(a,b,i)              ((data_header_t *)((a)+ \
										sizeof(bucket_header_t)+ \
										((b)+sizeof(data_header_t))*(i)))
#define ENTRY_SIZE(a)					(*((int*)(a)))
#define ENTRY_DATA(a)					((void*)(a)+sizeof(int))


// if caller doesn't set data size
#define DEFAULT_DATASIZE	(sizeof(void*))

// for convenience
#define this				((hash_t*)dic->childobj)

int hash_init(dic_t *dic)
{
	dic->childobj = malloc(sizeof(hash_t));
	if (dic->childobj == NULL) { return -1; }

	this->dirsize = DEFAULT_DIR_SIZE;
	this->datasize = DEFAULT_DATASIZE;
	this->dataperbucket = DEFAULT_DATA_PER_BUCKET;
	return 1;
}

int hash_open(dic_t *dic)
{
	int i, j, bucketsize;

	/* allocate directory array */
	this->dirs = (void **)malloc(DEFAULT_DIR_SIZE * sizeof(void*));
	if (hash->dirs == NULL) {
		// error report
		return -1;
	}

	/* initialize directory array & buckets */
	for (i=0; i<DEFAULT_DIR_SIZE; i++) {
		this->dirs[i] = (void *)malloc(DEFAULT_BUCKET_SIZE);
		if (this->buckets == NULL) {
			// error report
			return -1;
		}
		BUCKET_HEADER(this->dirs[i])->level = DEFAULT_DIR_SIZE;
		BUCKET_HEADER(this->dirs[i])->key = i;
		BUCKET_HEADER(this->dirs[i])->datanum = 0;
		BUCKET_HEADER(this->dirs[i])->occupiedsize = 0;
	}

	return dh;

}

void hash_close(dic_t *dic)
{
	for (int i=0; i<this->nbuckets; i++)
		free(this->dirs[i]);
	free(this);
}

int hash_search(dic_t *dic, const char *key, void *outbuf, int *bufsize)
{
	void *ptr;
	bucket_header_t *bucket;

	bucket = (bucket_header_t*)this->dirs[hashfnct(key, this->dirsize)];
	if ((ptr = searchbucket(bucket, this->datasize, key)) == NULL) {
		// error("no data");
		return -1;
	}

	// copy data
	if (*bufsize > ENTRY_SIZE(ptr)) *bufsize = ENTRY_SIZE(ptr);
	memcpy(outbuf, ENTRY_DATA(ptr), *bufsize);

	return 1;
}

int hash_insert(dic_t *dic, const char *key, void *data, int datasize)
{
	void *data = NULL;
	bucket_header_t *bucket;

	bucket = (bucket_header_t*)this->dirs[hashfnct(key, this->dirsize)];

	while ((data = searchempty(bucket, datasize)) == NULL) {
		if (NEED_TO_DOUBLING(this, BUCKET(this, offset))) {
			if (doubling(this) == -1) {
				// error("cannot doubling");
				return -1;
			}
		}

		if (split(this, offset) == -1) {
			// error("cannot split bucket");
			return -1;
		}

		offset = this->dirs[hashfnct(key, this->dirsize)];
	}

	if (data == NULL) {
		// error("'data' must not be null: something goes wrong");
		return -1;
	}

	/* copy data */
	strncpy(data->key, key, MAX_KEY_LEN);
	data->key[MAX_KEY_LEN-1] = '\0';
	memcpy(DATA_CHUNK(data), value, this->datasize);

	return 1;
}

static void *searchempty(bucket_header_t *bucket, const int datasize)
{
	int i;
	void *ptr;

	/* linear search */
	ptr = DATA_START_POINT(bucket);
	for (i=0; i<bucket->datanum; i++) {
		SHIFT_TO_NEXTKEY(ptr);
	}
	if (ptr - bucket + datasize > DEFAULT_BUCKET_SIZE) return NULL;

	/*fprintf(stderr, "i(%d) == b->datanum(%d)\n", i, b->datanum);*/
	return ptr;
}

// if found the entity, return null and set data to the point
// if not, return next start point
static void * __bucket_strncmp(void *ptr, char *key, char **data, int *datasize) {
	int i;

	for ( ; *(char*)ptr!='\0' && *key!='\0'; ptr++, key++) {
		if (*(char*)ptr != *key) break;
	}

/* return the point to data
 *  a: pointer
 *  b: get data size */
#define SHIFT_TO_DATA(a,b)						\
	do { while (*(char*)(a) != '\0') (a)++; \
		(a)++; (b) = *(int*)(a); (a) += sizeof(int); \
	} while (0)
/* return the next entry point
 *  a: pointer */
#define SHIFT_TO_NEXTKEY(a)						\
	do { int skip; while (*(char*)(a) != '\0') (a)++; \
		(a)++; skip = *(int*)(a); \
		(a) += sizeof(int); (a) += skip; \
	} while (0)
/* return the point that data start
 *  a: point to bucket  */
#define DATA_START_POINT(a)						((void*)(a)+sizeof(bucket_header_t))

	// if same
	if (*(char*)ptr == '\0' && *key == '\0') {
		SHIFT_TO_DATA(ptr, *datasize);
		*data = ptr;
		return NULL;
	}
	else {
		SHIFT_TO_NEXTKEY(ptr);
	}

	return ptr;
}

// scan buchet & find data with matching key
static void *searchbucket(bucket_header_t *bucket, int *datasize, const char *key)
{
	int i;
	void *d = NULL, *ptr;

	if (bucket->datanum == 0) return NULL;

	ptr = DATA_START_POINT(bucket);
	/* linear search */
	for (i=0; i<bucket->datanum; i++) {
		if ((ptr = __bucket_strncmp(ptr, key, &d, &datasize)) == NULL) {
			break;
		}
	}

	return (i == bucket->datanum) ? NULL : d;
}

static unsigned short hashfnct(const char *key, const short dirsize)
{
	unsigned int hash;
	int i;

	for (hash=0, i=0; key[i]!='\0' && i<MAX_KEY_LEN; ++i) {
		hash += key[i];
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}

	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);

	return hash % dirsize;
}

static int doubling(dh_t *dh)
{
	dir_t *tmp;

	tmp = (void **)sb_realloc(dh->dirs, sizeof(void*) * dh->dirsize * 2);
	if (tmp == NULL) {
		// error("cannot doubling directory: %s", strerror(errorno));
		return -1;
	}

	memcpy(&(tmp[dh->dirsize]), tmp, sizeof(dir_t) * dh->dirsize);

	/*  printf("doubling is occured: %d -> %d\n", dh->dirsize, dh->dirsize*2);*/
	dh->dirs = tmp;
	dh->dirsize *= 2;

	return 1;
}

static int split(dh_t *dh, const int offset)
{
	int i, dataperbucket, next;
	dir_t *dir;
	bucket_header_t *b;
	data_header_t *d0, *d1;

	b = BUCKET_HEADER(dh, offset);

	dataperbucket = dh->dataperbucket;
	if (b->level*2 > dh->dirsize) {
		/* FIXME: what to be done here? */
		fprintf(stderr, "databucket is wrong: bucket level(%d) > "
				"dynamic hash dirsize(%d)\n",
				b->level, dh->dirsize);
		return -1;
	}

	/* make new bucket */
	while (IS_OVERFLOW(dh, BUCKET_SIZE(dh->datasize, dataperbucket))) {
		if (expandbucket(dh) == -1) {
			fprintf(stderr, "cannot expand bucket");
			return -1;
		}

		b = BUCKET_HEADER(dh, offset);
	}

	/* set directory & initialize bucket */
	/*  fprintf(stderr, "new buckets offset: %d\n", dh->usedsize);*/
	BUCKET_HEADER(dh, dh->usedsize)->level = b->level * 2;
	BUCKET_HEADER(dh, dh->usedsize)->key = b->key + b->level;
	/*  fprintf(stderr, "new buckets datanum: %d\n", dataperbucket);*/
	BUCKET_HEADER(dh, dh->usedsize)->datanum = dataperbucket;
	for (i=0; i<dataperbucket; i++) {
		DATA_HEADER(BUCKET(dh, dh->usedsize), dh->datasize, i)->key[0] = '\0';
	}

	for (i=1; i*(b->level)<dh->dirsize; i+=2) {
		dir = &(dh->dirs[b->key + i * b->level]);
		dir->offset = dh->usedsize;
	}

	dh->usedsize += BUCKET_SIZE(dh->datasize, dataperbucket);
	b->level *= 2;

	/*  fprintf(stderr, "b->datanum: %d\n", b->datanum);*/
	for (i=0; i<b->datanum; i++) {
		d0 = DATA_HEADER(BUCKET(dh, offset), dh->datasize, i);

		dir = &(dh->dirs[hashfnct(d0->key, dh->dirsize)]);
		next = dir->offset;
		if (offset != next) {
			/*          fprintf(stderr, "next buckets offset: %d\n", next);*/
			d1 = searchempty(BUCKET(dh, next), dh->datasize);
			if (d1 == NULL) {
				fprintf(stderr,
						"'next[%d]' bucket must have empty data slot\n",
						next);
				return -1;
			}

			strncpy(d1->key, d0->key, MAX_KEY_LEN);
			d1->key[MAX_KEY_LEN-1] = '\0';
			memcpy(DATA_CHUNK(d1), DATA_CHUNK(d0), dh->datasize);

			d0->key[0] = '\0';
		}
	}

	return 1;
}

static int expandbucket(dh_t *dh)
{
	void *tmp;
	tmp = sb_realloc(dh->buckets, dh->allocatedsize + EXPANSION_UNIT_SIZE(dh));
	if (tmp == NULL) {
		fprintf(stderr, "fail sb_realloc: %s", strerror(errno));
		return -1;
	}

	dh->buckets = tmp;
	dh->allocatedsize += EXPANSION_UNIT_SIZE(dh);
	return 1;
}

