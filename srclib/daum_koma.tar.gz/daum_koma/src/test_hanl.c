/* $Id: test_hanl.c,v 1.31 2006/05/03 06:56:28 jchern Exp $ */
#ifndef WIN32
#	include "auto_config.h"
#	define HANL_RUNENV_DIR		ROOTDIR "/RunEnv"
#	include "dha.h"
#else
#	define HANL_RUNENV_DIR		".\\RunEnv"
#	include "dha.h"
#endif

#include 	<stdio.h>
#include 	<string.h>
#include	<assert.h>




#define	MAX_LEN	1024
#define MAX_OUTPUT	4096

#define	BREAKING	"�λ걳��"

int	main (int	argc, char * argv[])
{
	int		count = 0;
	int		size = 0;
	char	buffer[MAX_LEN];
	char	result[MAX_OUTPUT];
	void 	*final_info;
	FILE	*fp;

	// 1) initialize module
	final_info = dha_initialize(HANL_RUNENV_DIR,NULL);
	assert(final_info != NULL);

	if(argc == 2)	
	{
		fp = fopen(argv[1],"r");
		if(fp == NULL)	fp = stdin;
	}
	else
	{
		fp = stdin;
	}

	while(fgets(buffer, MAX_LEN, fp) != NULL)
	{
		if (buffer[strlen(buffer)-1] == '\r') buffer[strlen(buffer)-1] = '\0';
		if (buffer[strlen(buffer)-1] == '\n') buffer[strlen(buffer)-1] = '\0';


		/*									 �˻��� �׽�Ʈ											*/
		/*	dha_analyze(final_info,"QUERY:INDEX_PHRASE,INDEX_VERB", buffer, MAX_OUTPUT, result);	*/
		/*																							*/
		
		/*									 ���ο� �׽�Ʈ											*/
			dha_analyze(final_info, NULL, buffer, MAX_OUTPUT, result);									
		/*																							*/

//		if(result[0] == '\0')	printf(">> �������\n");
//		else					printf(">> %s\n",result);
		printf("%s\n",result);

		result[0] = '\0';
		count++;
	}

	if(argc == 2) fclose(fp);

	// 3) finalize module
	dha_finalize(final_info);

	fprintf(stderr,"\n------------------------Program Exit---------------------\n");
	return 0;
}

