#include 	<stdio.h>
#include 	<string.h>
#include	<malloc.h>
#include 	<ctype.h>
#ifndef WIN32
#include	<unistd.h>
#endif
#include	<sys/stat.h>
#include	<fcntl.h>
#include "moran.h"
#define	KOREAN	0x80
#define THRESHOLD 240
#define MTHRESHOLD 150
#define MAXWORDSIZE 8
static unsigned char	DIC[ROW][LEN];

int		HANL_open_space(char	*fn)
{
	int		i = 0;
	int		size = 0;
	unsigned char	buffer[LEN];
	FILE	*fp;

	fprintf(stderr,"[MSG]load dictionary (%s)\n",fn);
	fp = fopen(fn,"r");
	if(fp == NULL)	return NO;
	while(fgets(buffer, LEN, fp) != NULL)
	{
		size = strlen(buffer);
		if(buffer[size - 1] == '\n')			buffer[size - 1] = '\0';
		strcpy(DIC[i++], buffer);
	}
	fclose(fp);
	return (YES);
}


void 	*BinarySearch(void * arr, int arrsize, void * data, int size)
{
	int		max = 0;
	int		min = 0;
	int		cur = 0;
	int		ret = 0;
	int		closecondition = 0;
	char	*token;
	char	temp[1024];
	char	value[LEN];
	char	keyword[LEN];
	char	tdata[LEN];
	max = arrsize - 1;


	strcpy(tdata, (char*)data);
	for(;;)
	{
		if(min > max)	closecondition = 1;
		cur = (min + max) / 2;
		strcpy(temp, DIC[cur]);
		token = strtok(temp,"\t");
		if(token != NULL)
		{
			strcpy(keyword, token);
			token = strtok(NULL,"\t");
			if(token != NULL)
			{
				strcpy(value, token);
			}
			else
			{
				value[0] = '\0';
			}

		}
		ret = strcmp(keyword, tdata);

		if( ret == 0 )
		{
			strcpy(data, value);
			return data;
		}
		else if( ret > 0 )
		{
			max = cur - 1;
		}
		else if( ret < 0 )
		{
			min = cur + 1;
		}
		if(closecondition)	break;
			
		
	}
	return NULL;
}

int CheckKorean(char * str)
{
	if(*str & KOREAN)	return SUCCESS;
	else				return FAIL;
}

int probability(char * string, int *point)
{
	unsigned char	*token;
	unsigned char	temp[32];
	token = BinarySearch(DIC,ROW,string,4);
	if(token != NULL && token[0] != '\0')
	{
			strcpy(temp, token);
			*point = (int)(temp[0]);
	}
	else
	{
		if(string[0] == '&' || string[0] == '+')
			*point = 500;
		else
			*point = 0;	
	}
	return SUCCESS;
}

int		HANL_InsertSpace(char * word, char * result, int	* space, int size,  char * div,int mod)
{

	char	*wp;
	char	*tar;
	char	*bwp;
	char	*btar;
	int		*bspace;
	int		iSpaceCount = 0;
	int		wcount = 0;
	int		first = 1;
	int		i = 0;
	int 	idx = 0;

	if(mod == YES)
	{
		bwp = wp = word; 
		bspace = space;
		btar = tar = &result[0];
		
		for(i = 0; i < size; i++)
		{
			if(CheckKorean(wp))
			{
				i++;
				*tar++ = *wp++;
				*tar++ = *wp++;
				wcount++;

				if(space[idx] >= THRESHOLD && i != 1)
				{
					*tar++ = *div;
					iSpaceCount++;
					if(wcount > MAXWORDSIZE)
					{
						HANL_InsertSpace(bwp, btar, bspace, strlen(btar) - 1, div, 2);
						tar = btar+(strlen(btar));
					}
					wcount = 0;
				}
				idx++;
			}
			else
			{
				*tar++ = *wp++;
				wcount += 0.5;
				if(space[idx] >= THRESHOLD || space[idx] == 0)
				{
					if(wp[i - 1] & KOREAN)	
					{
						*tar++ = *div;
						first = 1;
						iSpaceCount++;
					}
				}
				idx++;
			}
			*tar = '\0';
		}

		if(wcount > MAXWORDSIZE)
		{
			HANL_InsertSpace(bwp, btar, bspace, strlen(btar) - 1, div, 2);
			tar = btar+(strlen(btar));
		}


		*tar++ = *div;
		iSpaceCount++;
		*tar = '\0';
	}
	else
	{
		int idx = 0;
		int maxpoint = 0;
		int	max = 0;
		wp = word; 
		tar = result;
		size = strlen(result);
		if(result[size-1] == ' ')	size--;

		if(CheckKorean(wp))		i = 2;
		else					i = 1;

		for(; i < size; i++)
		{
			if(CheckKorean(wp))
			{
				if(space[idx] >= max)
				{
					max = space[idx];
					maxpoint = idx;
				}
				i++;
			}
			else
			{
				if(space[idx] >= max)
				{
					max = space[idx];
					maxpoint = idx;
				}

			}
			idx++;
		}

		idx = 0;	
		iSpaceCount++;
		for(i = 0; i < size; i++)
		{

			if(CheckKorean(wp))
			{
				*tar++ = *wp++;
				*tar++ = *wp++;
				i++;
			}
			else
			{
				*tar++ = *wp++;
			}

			if(idx == maxpoint  && max > MTHRESHOLD)
			{
				*tar++ = *div;
			}
			idx++;
		}
		*tar++ = *div;
		iSpaceCount++;
		*tar = '\0';
	}
	if(	iSpaceCount  > 1)	return YES;
	else					return NO;
}

int	HANL_AutoCorrection(char * buffer, char * tar, char  * div)
{
	int		size = 0;
	int		ispace = 0;
	int		point;
	char	*tp = NULL;
	char	*sp = NULL;
	char	*wp = NULL;
	char 	*twp = NULL;
	char 	*token = NULL;
	char	*result = NULL;
	char	word[MAX_DICT_REF];
	char	sword[MAX_DICT_REF];
	int		space[MAX_DICT_REF];

	result = tar;
	sp = sword;

	size = strlen(buffer);

	if(buffer[size - 1] == '\n')	buffer[size - 1] = '\0';


	strcpy(word,buffer);
	wp = word;
	size = strlen(word);

	if(size < 7)
	{
		return (NO);
	}
	else
	{
		for(;;)
		{
			if(CheckKorean(wp))
			{
				*sp++ = *wp++;	*sp++ = *wp++;
				twp = wp;
				if(CheckKorean(wp))
				{
					*sp++ = *wp++;	*sp++ = *wp++;
				}
				else			
				{
					*sp++ = *wp++;
				}
			}
			else
			{
				*sp++ = *wp++;
				twp = wp;
				if(CheckKorean(wp))
				{
					*sp++ = *wp++;	*sp++ = *wp++;
				}
				else				*sp++ = *wp++;
			}
			*sp = '\0';
			probability(sword,&point);
			space[ispace++] = point;
			sp = sword;
	
			if(*wp == '\0')
				break;
			else	
				wp = twp;
		}
		size = strlen(word);
		return HANL_InsertSpace(word,result,space,size, div, 1);
	}

	return NO;
}
