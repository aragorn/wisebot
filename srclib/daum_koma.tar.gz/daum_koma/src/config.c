/****************************************************************
 *						CONFIG					      			*
 *                                                              *
 *                       Programmed by Kim, YEung Gyun          *
 *                       email : jchern@daumcorp.com			*
 *                       at : 2005.11.04						*
 ****************************************************************/
#include 	"config.h"
#define	DEF_INDEXING_LEVEL	22
#define	DEF_SIM_WORD		23

char	*KEYWORD[CONFIGCOUNT] =
{
	"PRE_DIC",		//0	
	"STOP_DIC",		//1
	"USER_DIC",		//2
	"EJIDX",		//3
	"COMB_NOUN",	//4
	"POSITION",		//5
	"FIRST_NAME",	//6
	"PX_VERB",		//7
	"HADA_VERB",	//8
	"INPUT_WORD",	//9
	"ROOT_VERB",	//10
	"HANJA",		//11
	"DIGIT",		//12
	"HYPHEN",		//13
	"BOOLEAN",		//14
	"LEFT_ATTACH",	//15
	"RIGHT_ATTACH",	//16
	"HANUM",		//17
	"ENG",			//18
	"1SYALL",		//19
	"INPUT_CNOUN",	//20
	"AUTOCORRECTION",//21
	"INDEXING_LEVEL",//22
	"SIM_WORD",		//23
	"TAGGED_RESULT",//24
	"NULL",		//25
};


int HANL_CONFIG[CONFIGCOUNT];
int HANL_CONFIG_INDEXING_LEVEL = 0;
int HANL_CONFIG_SIM_WORD = 0;


void Set_Indexing_Level(int level)
{
	HANL_CONFIG_INDEXING_LEVEL  = level;
}


int	SetConfig(char * filename)
{
	int		idx = 0;
	int		ret = 0;
	int		size = 0;
	int		iconfig = 0;
	FILE 	*fp;
	char	buffer[1024];
	char	key[256];

	fp = fopen(filename,"rt");

	memset(HANL_CONFIG,0,CONFIGCOUNT);
	if(fp == NULL)
	{
		printf("file open error(%s)\n",filename);
		return -1;
	}
#ifdef	DEBUG2
	else	printf("Set configuration!\n");
#endif
	while(fgets(buffer,1024,fp) != NULL)
	{
		if(buffer[0] == '#')	continue;
		size = strlen(buffer);
		if(size < 4)	continue;
		DelNewline(buffer,size);

		ret = sscanf(buffer,"%s %d",key,&iconfig);
		if(ret != 2)	continue;
		for(;;)
		{
			if(strcmp(KEYWORD[idx],"NULL") == 0)	break;

			// XXX: actually, we don't need to ignore case
			if(strcmp(KEYWORD[idx],key) == 0)
//			if(strcasecmp(KEYWORD[idx],key) == 0)
			{
				if(idx == DEF_INDEXING_LEVEL)
				{
						HANL_CONFIG_INDEXING_LEVEL  = iconfig;
#ifdef	DEBUG2				
						printf("HANL_CONFIG_INDEXING_LEVEL=%d\n",iconfig);
#endif	
				}
				else if(idx == DEF_SIM_WORD)
				{
						HANL_CONFIG_SIM_WORD  = iconfig;
#ifdef	DEBUG2				
						printf("HANL_CONFIG_SIM_WORD=%d\n",iconfig);
#endif	
				}
				else
				{
					HANL_CONFIG[idx] = iconfig;
#ifdef	DEBUG2				
					printf("%s[%d]=%d\n",KEYWORD[idx],idx,iconfig);
#endif	
				}
				break;
			}
			else
			{
				idx++;
			}
		}
	}
	fclose(fp);
	return 1;
}

int	Check_PRE_DIC()		{	if(HANL_CONFIG[0] == SET) 		return 1;	else	return 0;}
int	Check_STOP_DIC()	{	if(HANL_CONFIG[1] == SET)		return 1;	else	return 0;}
int	Check_USER_DIC()	{	if(HANL_CONFIG[2] == SET)		return 1;	else	return 0;}
int	Check_EJIDX()		{	if(HANL_CONFIG[3] == SET)		return 1;	else	return 0;}
int	Check_COMB_NOUN()	{	if(HANL_CONFIG[4] == SET)		return 1;	else	return 0;}
int	Check_POSITION()	{	if(HANL_CONFIG[5] == SET)		return 1;	else	return 0;}
int	Check_FIRST_NAME()	{	if(HANL_CONFIG[6] == SET)		return 1;	else	return 0;}
int	Check_PX_VERB()		{	if(HANL_CONFIG[7] == SET)		return 1;	else	return 0;}
int	Check_HADA_VERB()	{	if(HANL_CONFIG[8] == SET)		return 1;	else	return 0;}
int	Check_INPUT_WORD()	{	if(HANL_CONFIG[9] == SET)		return 1;	else	return 0;}
int	Check_ROOT_VERB()	{	if(HANL_CONFIG[10] == SET)		return 1;	else	return 0;}
int	Check_HANJA()		{	if(HANL_CONFIG[11] == SET)		return 1;	else	return 0;}
int	Check_DIGIT()		{	if(HANL_CONFIG[12] == SET)		return 1;	else	return 0;}
int	Check_HYPHEN()		{	if(HANL_CONFIG[13] == SET)		return 1;	else	return 0;}
int	Check_BOOLEAN()		{	if(HANL_CONFIG[14] == SET)		return 1;	else	return 0;}
int	Check_LEFT_ATTACH()	{	if(HANL_CONFIG[15] == SET)		return 1;	else	return 0;}
int	Check_RIGHT_ATTACH(){	if(HANL_CONFIG[16] == SET)		return 1;	else	return 0;}
int	Check_HANNUM()		{	if(HANL_CONFIG[17] == SET)		return 1;	else	return 0;}
int	Check_ENGLISH()		{	if(HANL_CONFIG[18] == SET)		return 1;	else	return 0;}
int	Check_1SYALL()		{	if(HANL_CONFIG[19] == SET)		return 1;	else	return 0;}
int	Check_INPUT_CNOUN()	{	if(HANL_CONFIG[20] == SET)		return 1;	else	return 0;}
int	Check_AUTOCORRECTION(){	if(HANL_CONFIG[21] == SET)		return 1;	else	return 0;}
int Check_TAGGED_RESULT() { if(HANL_CONFIG[24] == SET)		return 1;	else	return 0;}
int	Get_SIM_WORD()		{	return HANL_CONFIG_SIM_WORD;}

int	Check_INDEXING_LEVEL(int i)
{
	if(i != 0 && HANL_CONFIG_INDEXING_LEVEL >= i)	
	{
		//warn(" indexing level : %d",HANL_CONFIG_INDEXING_LEVEL);
		return 1;
	}
	else	
		return 0;
}

void	Set_SIM_WORD_ORG(void)		{	HANL_CONFIG_SIM_WORD = 1;		}
void	Set_SIM_WORD_MULTI(void)	{	HANL_CONFIG_SIM_WORD = 2;		}
void	Set_SIM_WORD_ONLY(void)		{	HANL_CONFIG_SIM_WORD = 3;		}
void	Set_EJIDX(void)				{	HANL_CONFIG[3] = SET;			}
void	Set_COMB_NOUN(void)			{	HANL_CONFIG[4] = SET;			}
void	Set_ROOT_VERB(void)			{	HANL_CONFIG[10] = SET;			}
void	Set_BOOLEAN(void)			{	HANL_CONFIG[14] = SET;			}
void	Set_INDEXING_LEVEL1(void)	{	HANL_CONFIG_INDEXING_LEVEL = 1;	}
void	Set_INDEXING_LEVEL2(void)	{	HANL_CONFIG_INDEXING_LEVEL = 2;	}
void	Set_INDEXING_LEVEL3(void)	{	HANL_CONFIG_INDEXING_LEVEL = 3;	}
void	Set_INDEXING_LEVEL4(void)	{	HANL_CONFIG_INDEXING_LEVEL = 5;	}
