/*------------------------------------------------------------------------
 *
 *		�ѱ� ���� N-Byte ������ Code Conversion Program
 *
 *		Original 	by �̼���, KAIST
 *		Modified	by ����ȯ, KAIST 
 *				choyh@csking.kaist.ac.kr
 *
 *		  ������ �ڵ� ü�迡�� ASCII�� �ѱ��� ���ÿ� ��밡���ϵ���
 *		  �����Ͽ���. ������ �ڵ�� �ѱ� ���� ������� �Ͽ��� ������
 *		  �������� �뵵�� ������ ���Ҵµ�, �ѱ� �κп� MSB MASKING��
 *		  �ϰ� ������ 7��Ʈ�� Original�� �����ϴ�.
 *		  ����, "��"�� ���� �ڵ�� �����Ͽ���.
 *		  Original���� ASCII '8'�̾��µ�, ������ "4e"�� �����Ͽ� 
 *		  "��"�ұ�Ģ "�ϴ�+���" => "�ض�"�� �����ϵ��� �Ͽ���.
 *
 *	����: ���¼� �м����� ���� ���α׷��� �մ��� N-byte ���� �ڵ带
 *		����ϱ� ������ �Ϲ����� ���α׷����� ���� �մ����� �ʽ��ϴ�.
 *		������ �ڵ带 �����ϸ� �پ��� �������� ������ �����մϴ�.
 *
 *					  By Cho, Young Hwan. 1997. 6. 5
 *------------------------------------------------------------------------ */

#include	<stdio.h>
#include	<ctype.h>
#include	<string.h>
#include	"hantable.h"
#include    "hanja.h"
#include    "moran.h"
#include 	"hantype.h"
/*--------------------------------------------------
 *  C2S	: flag for Combination to Complete
 *  S2C : flag for Complete to Combination
 */

#define	C2S	0
#define S2C	1
#define KS_MASK 0x80


#define YES	1
#define NO	0

#define CHO_FILL	0x09
#define JUNG_FILL	0x10
#define JONG_FILL	0x01


#define ERROR	0
#define SUCC	1
#define MAX	1024

#define get_cho(x)	(((x) & 0x7C00) >> 10)
#define get_jung(x)	(((x) & 0x03E0) >> 5)
#define get_jong(x)	((x) & 0x001F)

unsigned char Chos[][2] = 
{
	"",  "", "g", "q", "n", "d", "f", "l", "m", "b", "r", "s", "v",  "", "j", "z", "c", "k", "t", "p", "h",
};

unsigned char Jungs[][2] = 
{
	"",   "",   "", "a","4e","ya","y8", "e",  "",  "", "9","ye","y9", "o","wa","w8",  "",  "","wu","yo", "u", 
	"we","w9","wi" , "",  "","yu", "_","yi", "i",
};

unsigned char Jongs[][2] = 
{
	""  ,  "",  "G", "Q","GS", "N","NJ","NH", "D", "L","LG","LM","LB","LS","LT","LP","LH", "M",  "", "B",
	"BS", "S", "V",  "*", "J", "C", "K", "T", "P", "H"
};

unsigned char Is_cho[] =  "ghqndlmbrsvfjzcktp";
unsigned char Is_jung[] = "aeoui_89";
unsigned char Is_half[] = "4wy";
unsigned char Is_jong[] = "NDLMBSJG*CPHQVTK";

unsigned char act_tbl[5][6] = {
    "05500",
    "13313",
    "88818",
    "99949",
    "66618"
};

int
HANL_hanja2ks_c2(unsigned char h1, unsigned char h2, unsigned char *k1, unsigned char *k2)
{
	unsigned short upper;
	unsigned short lower;
	unsigned short start;
	unsigned short end;
	unsigned short middle;
	unsigned short hanja;
	unsigned short hangul;

	upper = h1 ;
	lower = h2 ;
	hanja = (upper << 8) + lower;
	start = 0 ;
	end = MAX_HANJA_TABLE - 1 ;
	middle = ( start + end ) / 2 ;
	while ( 1 )
	{
		if ( hanja == hanja_table [middle][1] )
			break ;
		else if ( hanja < hanja_table [middle][1] )
			end = middle ;
		else
			start = middle ;

		middle = ( start + end ) / 2 ;
		if ( start == middle )
			break ;
	}
	hangul = hanja_table [middle][0] ;
	*k1 = hangul >> 8;
	*k2 = hangul & 0xff;
	return( 1 ) ;
}

int
HANL_is_hanja(unsigned char c1, unsigned char c2)
{
	if(!(c1&0x80) || !(c2&0x80))
		return(NO);
	if((c1 >= 0xca) && (c2 >= 0xa1) &&  (c1 <= 0xfd) && (c2 <= 0xfe))
		return(YES);
	return(NO);
}

/**
 * HANL_hanja2ks_str()
 * ���ڹ��ڿ��� �ѱ۷� �ٲٴ� �Լ�; �־��� len(byte����) ��ŭ�� ���ڿ��� �ٲپ� �ش�. */
int
HANL_hanja2ks_str(unsigned char *hanja, unsigned char *hangul)
{
	while(*hanja) 
	{
		if(!(*hanja & 0x80) || *(hanja+1) == '\0') 
		{
			*hangul = *hanja;
			hangul++;
			hanja++;
			continue;
		}
		if(HANL_is_hanja(*hanja, *(hanja+1))) 
		{
			HANL_hanja2ks_c2(*hanja, *(hanja+1), hangul, hangul+1);
			hangul+=2;
			hanja +=2;
			continue;
		}
		*hangul = *hanja;
		hangul++;
		hanja++;
		*hangul = *hanja;
		hangul++;
		hanja++;
	}
	*hangul = '\0';
}

int
HANL_is_hangul(unsigned char c1,unsigned char c2)
{
	if((c1 >= 0xb0) && (c2 >= 0xa1) && (c1 <= 0xc8) && (c2 <= 0xfe)) 
		return(YES);
	return(NO);
}

/* 2����Ʈ ���������� ����� ��ƾ */
int
HANL_make2c(unsigned char cho, unsigned char jung1, unsigned char jung2, unsigned char jong1, unsigned char jong2)
{
	int	i = 0;
	unsigned char	upper = 0;
	unsigned char	middle = 0;
	unsigned char	lower = 0;

	for (i = 0; i < 32; i++)
		if (Chos[i][0] == cho) 
		{
			upper = i;
			break;
		}
	for (i = 0; i < 32; i++)
		if (Jungs[i][0] == jung1 && Jungs[i][1] == jung2) 
		{
			middle = i;
			break;
		}
	for (i = 0; i < 32; i++)
		if (Jongs[i][0] == jong1 && Jongs[i][1] == jong2) 
		{
			lower = i;
			break;
		}
	if (upper == 0) 
	{
		if (middle != 0)
		{
			upper = 13;
		}
		else 
		{
			cho = tolower(jong1);
			for (i = 0; i < 32; i++)
				if (Chos[i][0] == cho) 
				{
					upper = i;
					break;
				}
			middle = JUNG_FILL;
			lower = JONG_FILL;
		}
	}
	if (lower == 0)
		lower = JONG_FILL;
	return   (unsigned int)(((upper << 10)+(middle << 5)+(lower)) | 0x8000);
}


int
HANL_whattype(unsigned char ch)
{
	unsigned char	ch1;

	if(ch == 0)	return -1;
	if(ch > HANGUL_MARK)	ch1 = ch-HANGUL_MARK;
	else					return 4;
	if (strchr((char *)Is_jung, (char)ch1)) return 2;
	if (strchr((char *)Is_cho,  (char)ch1)) return 0;
	if (strchr((char *)Is_half, (char)ch1)) return 1;
	if (strchr((char *)Is_jong, (char)ch1)) return 3;
	return 4;
}

int HANL_kimmo2ks(unsigned char *src,unsigned char *des)
{
	int i = 0, j = 0;
	unsigned int  action;
	unsigned char tag[MAX];
	unsigned char cho, jung1, jung2, jong1, jong2;
	unsigned char one;
	int	size  = 0;
	int value = 0;
	unsigned char tmp[MAX];

	if(src[0] == '\0')
		return FAIL;

	// XXX: useless check
	size = strlen(src);
	if(size >= MAX_LINE)
		return FAIL;

    if(src[size - 1] == 'y'+HANGUL_MARK)		src[size - 1] = '\0';
	else if(src[size - 1] == 'w'+HANGUL_MARK)	src[size - 1] = '\0';
	else if(src[size - 1] == '4'+HANGUL_MARK)	src[size - 1] = ('a' + HANGUL_MARK);
	
	while (src[i] && i < MAX) {
		tag[i] = HANL_whattype(src[i]);
		i++;
	}

    tag[i] = 4;
    i = 0;

    action = cho = jung1 = jung2 = jong1 = jong2 = 0;
	while (src[i]) 
	{
		if(src[i] >= HANGUL_MARK)
		{
			one = src[i] - HANGUL_MARK;
		}
		else 
		{ 
			tmp[j++] = src[i];
			i++;
			continue;
		}

		value = act_tbl[tag[i]][tag[i+1]];
        //printf("tag[%d] = %d,tag[%d+1]= %d value = %c\n",i,i,tag[i], tag[i+1],value);


		if (value == '1' || value == '8' || value == '3') 
		{
			if (jung1)				jung2 = one;
			else					jung1 = one;
			if (value == '8' || (value == '3' && jung2))
				action = 2;
		}
		else if (value == '2' || value == '9' || value == '4') 
		{
			if (jong1)				jong2 = one;
			else					jong1 = one;
			if (value == '9' || (value == '4' && jong2))
				action = 2;
		}
		else if (value == '5')		cho = one;
		else if (value == '6') 
		{
			tmp[j++] = one;
			action = 1;
		}

		if (action > 1) 
		{
			value = HANL_make2c(cho, jung1, jung2, jong1, jong2);
			tmp[j++] = (unsigned char)(value >> 8);
			tmp[j++] = (unsigned char)(value);
		}
		if (action > 0)
			action = cho = jung1 = jung2 = jong1 = jong2 = 0;
		i++;
	}
	tmp[j] = '\0';
	HANL_ks(tmp, des, 0);
	return (YES);
}


int
HANL_is_2vowel(unsigned char c)
{
	unsigned char temp = c - HANGUL_MARK;
	if (temp == 'y' || temp == 'w' || temp == '4')
		return YES;
	else	
		return NO;
}

int
HANL_is_jungsung(unsigned char c)
{
	int	i;
	unsigned char	temp = 0;
	static char jung[10] =
	{
		'a', 'e', 'o', 'u', '9', 
		'_', 'i', '4', 'w', 'y', 
	};

	for(i = 0; i < 10; i++)
	{
		temp = (unsigned char)(jung[i]+HANGUL_MARK);
		if(c == temp)	return(YES);
	}
	return(NO);

}

int
HANL_is_chosung(unsigned char    c)
{ 
	int   i;
	unsigned char	temp = 0;
	static char cho[18] =
	{
		'g', 'n', 'd', 'l', 'm', 
		'b', 's', 'j', 'c', 'k', 
		't', 'p', 'h', 'q', 'f',
		'r', 'v', 'z', 
	};

	for(i = 0; i < 18; i++)
	{
		temp = (unsigned char)(cho[i]+HANGUL_MARK);
		if(c == temp)	return(YES);
	}
	return(NO);
}

int
HANL_is_jongsung(unsigned char c)
{
	int   i = 0;
	static char jong[14] =
	{
		'G', 'N', 'D', 'L', 'M', 
		'B', 'S', '*', 'J', 'C',
		'K', 'T', 'P', 'H' 
	};

	for(i = 0; i < 14; i++)
	{
		if(c == jong[i]+HANGUL_MARK) 			return(YES);
	}
	return(NO);
}

int
HANL_Replace_2vowel_to_1vowel(unsigned char * zooword)
{
	unsigned char	*p;
	unsigned char	*q;
	p = zooword;
	while(p != NULL && *p != '\0')
	{
		if(*p == ('4' + HANGUL_MARK))
		{
			q = p;
			p++;

			if(*p == ('8' + HANGUL_MARK))
			{
				if(*(p+1) == '\0')
					*q = ('a' + HANGUL_MARK);//a
				break;
			}

		}
		if(*p == ('y' + HANGUL_MARK))
		{
			q = p;
			p++;
			switch(*p - HANGUL_MARK)
			{
				case 'a':
					break;
				case 'e':
					break;
				case 'i':
					break;
				case 'o':
					break;
				case '8':
					break;
				case '9':
					break;
			}
		}
		if(*p == ('w' + HANGUL_MARK))
		{
			q = p;
			p++;
			switch(*p - HANGUL_MARK)
			{
				case 'e':
					break;
				case '9':
					if(*(p+1) == '\0')
						*q = ('u' + HANGUL_MARK);//9
					break;
				case 'u':
					break;
				case 'a':
//					if(*(p+1) == '\0')						*q = ('o' + HANGUL_MARK);//a
					break;
				case '8':
					if((*(p-2) != '\0') && (*(p+1) != '\0'))
					{
						if(*(p-2) == ('d' + HANGUL_MARK) && *(p+1) == '\0')
						{
							*p = ('i' + HANGUL_MARK);//d
							p++;
							*p = ('e' + HANGUL_MARK);
							p++;
							*p = '\0';
						}
					}
					break;
				case 'i':
					break;
			}
		}
		p++;
	}
	return (NO);


}

int
HANL_preprocess_doi(unsigned char * zooword)
{
	unsigned char	*p;
	p = zooword;
	while(p != NULL && *p != '\0')
	{
		if(*p == ('d' + HANGUL_MARK))
		{
			p++;
			if(*p == ('w' + HANGUL_MARK))
			{
				p++;
				if(*p == ('8' + HANGUL_MARK))
				{
					*p = 'i' + HANGUL_MARK;		p++;
					*p = 'e' + HANGUL_MARK;		p++;
					*p = '\0';
					return (YES);
				}
			}
		}
		p++;
	}
	return (NO);

}

int
HANL_ks2kimmo(unsigned char *src,unsigned char *des)
{
	int one, i = 0;
	unsigned char tmp[MAX];
	unsigned char cho = 0;
	unsigned char jung = 0;
	unsigned char jong = 0;

	HANL_ks(src, tmp, S2C);

	while (one = tmp[i++]) 
	{
		if (one & KS_MASK) 
		{
			one <<= 8;
			one += (unsigned int)(tmp[i++]);

			cho  = get_cho(one);
			jung = get_jung(one);
			jong = get_jong(one);


			if (jung == JUNG_FILL && jong == JONG_FILL) 
			{
				*des++ = toupper(Chos[cho][0]) + HANGUL_MARK;
				//printf("�ʼ�:%c\n",Chos[cho][0]);
			}
			else 
			{
				if (Chos[cho][0]) 
				{
					*des++ = Chos[cho][0] + HANGUL_MARK;
					//printf("�ʼ�:%c\n",Chos[cho][0]);
				}
				if (Chos[cho][1]) 
				{
					*des++ = Chos[cho][1] + HANGUL_MARK;
					//printf("�ʼ�:%c\n",Chos[cho][1]);
				}
				if (Jungs[jung][0]) 
				{
					*des++ = Jungs[jung][0] + HANGUL_MARK;
					//printf("�߼�:%c\n",Jungs[jung][0]);
				}
				if (Jungs[jung][1]) 
				{
					*des++ = Jungs[jung][1] + HANGUL_MARK;
					//printf("�߼�:%c\n",Jungs[jung][1]);
				}
				if (Jongs[jong][0]) 
				{
					*des++ = Jongs[jong][0] + HANGUL_MARK;
					//printf("����:%c\n",Jongs[jong][0]);
				}
				if (Jongs[jong][1]) 
				{
					*des++ = Jongs[jong][1] + HANGUL_MARK;
					//printf("����:%c\n",Jongs[jong][1]);
				}
			}
		}
		else 
		{
			*des++ = (unsigned char) one;
		}
	}
	*des = '\0';
	return SUCC;
}

int
HANL_ks2kimmo2(unsigned char *src, unsigned char *des, int *whereis)
{
	int one, i = 0;
	unsigned char tmp[MAX];
	unsigned char cho, jung, jong;
	int  where;

	HANL_ks(src, tmp, S2C);
	where = 0;

	while(one = tmp[i++]) 
	{
		if(one & KS_MASK) 
		{
			one <<= 8;
			one += (unsigned int)(tmp[i++]);

			cho  = get_cho(one);
			jung = get_jung(one);
			jong = get_jong(one);

			if (jung == JUNG_FILL && jong == JONG_FILL) 
			{
				*des++ = toupper(Chos[cho][0]) + HANGUL_MARK;
				*whereis++ = where;
			}
			else 
			{
				if (Chos[cho][0]) 
				{
					*des++ = Chos[cho][0] + HANGUL_MARK;
					*whereis++ = where;
				}
				if (Chos[cho][1]) 
				{
					*des++ = Chos[cho][1] + HANGUL_MARK;
					*whereis++ = where;
				}
				if (Jungs[jung][0]) 
				{
					*des++ = Jungs[jung][0] + HANGUL_MARK;
					*whereis++ = where;
				}
				if (Jungs[jung][1]) 
				{
					*des++ = Jungs[jung][1] + HANGUL_MARK;
					*whereis++ = where;
				}
				if (Jongs[jong][0]) 
				{
					*des++ = Jongs[jong][0] + HANGUL_MARK;
					*whereis++ = where;
				}
				if (Jongs[jong][1]) 
				{
					*des++ = Jongs[jong][1] + HANGUL_MARK;
					*whereis++ = where;
				}
			}
			where += 2;
		}
		else
		{
			*des++ = (unsigned char) one;
			*whereis++ = where++;
			/*
			   whereis++;
			   where++;
			*/
		}
	}
	*des = '\0';
	*whereis++ = where;
	*whereis++ = where;
	*whereis = '\0';
	return SUCC;
}


int HANL_ks(unsigned char *src, unsigned char *des, int type)
{
#ifdef	SIZE_CHECK
	int	size = 0;
#endif
	int upper, result;
	unsigned char	c1, c2;

	while (*src) 
	{
		c1 = *src;
		if ((upper = (unsigned int)(*src++)) & KS_MASK) 
		{
			if(*src == '\0') break;
			c2 = *src;
			upper <<= 8;
			upper += (unsigned int)(*src++);
			if ((result = HANL_syllable(upper, type)) == ERROR)
			{
				//memcpy(des," ",sizeof(char));
				//des++;
				continue;
			}
			
#ifdef	SIZE_CHECK
			size++;
			size++;
#endif
			*des++ = (unsigned char)(result >> 8);
			*des++ = (unsigned char) result;
		}
		else
		{
#ifdef	SIZE_CHECK
			size++;
#endif
			*des++ = c1;
		}
	}
#ifdef	SIZE_CHECK
	if(size >= MAX)
	{
		fprintf(stderr,"[SIZE]%s:%d\tBuffer Overflow\n",__FUNCTION__,__LINE__);
	}
#endif
	*des = '\0';
	return SUCC;
}

/**
 *  NAME
 *	syllable(src, type)
 *  ARGUMENTS
 *	int src		: source code in lower 2 byte.
 *	int type	: flag one of C2S and S2C
 *  DESCRIPTION
 *	convert a syllable
 *  RETURN VALUES
 *	0	if error
 *	value	if corresponding code exists.
 */
int HANL_syllable(int src, int type)
{
	hancode value;

	if(src == 0xa1a4)	return src;
	if(type == S2C)
	{
		if(value = HANL_euckr2johab(&src,NULL))
			return value;
	}
	else if(type == C2S)
	{
		if(value = HANL_johab2euckr(&src,NULL))
			return value;
	}
	if (type == S2C) 
	{
		if (value = HANL_binsrch(JASOW2C, KEY_SIZE, src, 1))
			return value;
	}
	if (type == C2S) 
	{
		if (value = HANL_binsrch(JASOC2W, KEY_SIZE, src, 0))
			return value;
	}

}


int HANL_binsrch(int code[][2], int n, int key, int type)
{
	int lower = 0;
	int upper = n - 1;
	int mid = 0;

	while (lower <= upper) 
	{
		mid = (lower + upper) >> 1;
		if (key > code[mid][0])			lower = mid + 1;
		else if (key < code[mid][0])		upper = mid - 1;
		else if (key == code[mid][0])	return code[mid][1];
	}
	return ERROR;
}

/* �ѱ� ��Ʈ�� s2�� reverse�Ͽ� s1���� �����*/
void HANL_reverse(char *s1,char *s2)
{
	int		i = 0;
	int		last = 0;

	last = strlen(s2)-1;

	for(i = 0; i <= last; i++)
	{
		s1[i] = s2[last-i]; 
	}
	s1[last+1] = '\0';
}

/*
 * ���� �ڵ��� zoocode���� ���ϴ� ���� ��ŭ�� KS�ڵ�� �ٲپ��ش�. */
int HANL_make_morpheme(int start,int end,unsigned char *word,unsigned char *morpheme)
{
	char    kimmoword[MAX_LINE];

#ifdef  DEBUG1
	printf("HANL_make_morpheme()\n");
#endif
	if((end-start) < 0)
	{
		warn("Cann't make morpheme");
		strcpy(morpheme,"ERROR");
		return FAIL;
	}
#ifdef  DEBUG
	if (start > (int)strlen(word) || end > (int)strlen(word))
	{
		printf("%d %d %d %s\n", start, end, strlen(word), word);
	}
#endif

	strncpy(kimmoword,word+start,end-start+1);
	kimmoword[end-start+1] = '\0';
	HANL_kimmo2ks(kimmoword,morpheme);

	return SUCCESS;
}
