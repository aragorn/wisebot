#include <string.h>
#include "moran_tagdef.h"


int main(int argc, char * argv[])
{
	int		i = 0;
	int		lnum = 0;
	int		rnum = 0;
	char	ltag[1024];
	char	rtag[1024];
	if(argv[1] != NULL)		
	{
		lnum = atoi(argv[1]);
		printf("LTAG:%s\t",L_MTag_Set[lnum]);

	}

	if(argv[2] != NULL)
	{
		rnum = atoi(argv[2]);
		printf("RTAG:%s\t",R_MTag_Set[rnum]);
	}

}
