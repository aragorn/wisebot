/* $Id: hanlindex.c,v 1.7 2006/04/20 07:29:47 jchern Exp $ */
#include "auto_config.h"

#include 	<stdio.h>
#include 	<string.h>
#include  	"moran.h"

#define HANL_RUNENV_DIR		ROOTDIR "/RunEnv"

int	main (int argc, char *argv[])
{
	int		count = 1;
	int		size = 0;
	char	buffer[4096];
	char	result[4098];
	void 	*final_info;
	FILE	*fp;

	final_info = dha_initialize(HANL_RUNENV_DIR,NULL);
	if (final_info == NULL) {
		exit(1);
	}

	if(argc > 1) {
		fprintf(stderr, "usage: %s < inputfile", argv[0]);
		exit(1);
	}
	fp = stdin;

	while(fgets(buffer, 4096, fp) != NULL) {
		dha_analyze(final_info, NULL, buffer,4096,result);

		if(result[0] == '\0')		
			printf(">> �������\n");
		else	
			printf(">> %s\n",result);

		result[0] = '\0';
		count++;
	}

	dha_finalize(final_info);

	return 0;
}

