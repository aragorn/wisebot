#include <string.h>
#include <stdio.h>
#define	MAX	1024

int	main(int	argc, char *argv[])
{
	FILE	*fc;
	FILE	*fa;
	FILE	*fr;
	char	*cRetc;
	char	*cReta;
	char	tempc[MAX];
	char	tempa[MAX];
	char	bufferc[MAX];
	char	buffera[MAX];
	char	*token;
	char	*p;
	float	accuracy = 0.0;
	int		fail = 0;
	int		size = 0;
	int		correct = 0;
	int		incorrect = 0;
	int		total = 0;

	if(argc != 4)
	{
		printf("%s Candidate Answer result\n",argv[0]);
		exit(1);
	}
	fc = fopen(argv[1],"r");
	fa = fopen(argv[2],"r");
	fr = fopen(argv[3],"w");

	for(;;)
	{
		cRetc = fgets(bufferc,MAX,fc);
		cReta = fgets(buffera,MAX,fa);
		if(cRetc == NULL && cReta == NULL)	
		{
			printf("Complete Job\n");
			break;
		}

		total++;
		size = strlen(bufferc);
		if(bufferc[size - 1] == '\n')	bufferc[size - 1] = '\0';
		strcpy(tempc,bufferc);
		size = strlen(buffera);
		if(buffera[size - 1] == '\n')	buffera[size - 1] = '\0';
		strcpy(tempa,buffera);
		for(token  = strtok(buffera," "); token != NULL; token = strtok(NULL," "))
		{
			p = strstr(bufferc,token);
			if(p == NULL)
			{
				fprintf(fr,"X\t%s\t(%s)\n",tempc,tempa);
				incorrect++;
				fail = 1;
			}
		}
		if(fail != 1)
				fprintf(fr,"O\t%s\n",tempc);
		fail = 0;
	}
	fclose(fc);
	fclose(fa);
	fclose(fr);

	correct = total - incorrect;
	accuracy = (total-incorrect)*100;
	accuracy /= total;
	printf(" >> ------------------------------------------------------\n");
	printf(" >> ��ü �Է� ������		: %d����\n",total);
	printf(" >> ��Ȯ�� �м��� ������	: %d����\n",correct);
	printf(" >> �߸� �м��� ������		: %d����\n",incorrect);
	printf(" >> �м� ��Ȯ�� (%)		: %f\n",accuracy);
	printf(" >> ------------------------------------------------------\n");
	return 0;
}
