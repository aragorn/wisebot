#include "errorlog.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "manage_dict.h"

static unsigned long get_node(dic_t *dic,
		unsigned long address,
		unsigned char *index,
		unsigned int *tag,
		unsigned long *ynext,
		unsigned int *front,
		unsigned int *middle,
		unsigned int *rear,
		unsigned int *freq);

int fdict_init(dic_t *dic)
{
	return 1;
}

int	open_fdict(dic_t *dic)
{
	FILE  *fp;
	unsigned int  i,firsts,first_size;
	unsigned char add1,add2,add3;
	unsigned char info1,info2,info3,info4,info5;
	int           what_first;
	struct stat   stbuf;
	int		limit = 0;

	if(stat(dic->path,&stbuf) == -1) 
	{
		dic->use = NO;
		return -1;
	}

	// read whole file into memory
	dic->datasize = (unsigned long)(stbuf.st_size+1);
	dic->data = (unsigned char *)malloc(dic->datasize);

	fp = fopen(dic->path, "r");
	fread(dic->data, 1, stbuf.st_size, fp);
	fclose(fp);

	if((fp = fopen(dic->path,"rb"))== NULL) 
	{
		dic->use = NO;
		return -1;
	}
	info1 = fgetc(fp);
	info2 = fgetc(fp);
	info3 = fgetc(fp);
	info4 = fgetc(fp);
	info5 = fgetc(fp);
	firsts = info1;
	dic->tags_count  = ((info2&0x00ff)<<8)|(info3&0x00ff);
	first_size  = ((info4&0x00ff)<<8)|(info5&0x00ff);
	while(fgetc(fp) != '*') 
	{
		limit++;
		if(limit == 1000000)			return -1;
	}
	for(i=0;i<MAX_DICT_FIRSTS;i++) dic->first_char_addr[i] = 0;
	for(i=0;i<firsts;i++) 
	{
		what_first = (unsigned char)fgetc(fp);
		add1 = (unsigned int) fgetc(fp);
		add2 = (unsigned int) fgetc(fp);
		add3 = (unsigned int) fgetc(fp);
		dic->first_char_addr[what_first] = (unsigned long)(((add1&0x00ff)<<16)|((add2&0x00ff)<<8)|(add3&0x00ff));
	}
	fclose(fp);
	dic->use = YES;
	return 1;
}

void close_fdict(dic_t *dic)
{
	free(dic->data);
}

int match_fdict(dic_t *dic,const unsigned char *zooword,void *outbuf,int bufsize)
{
	int   size,i,length=0, result=0;
	unsigned int tag;
	unsigned char *prt, key[100],found[100];
	unsigned long address,ynext;
	int *front, *middle, *rear, *freq;

	debug("match_fdict called");
	front = outbuf;
	middle = (int*)((unsigned char *)outbuf + sizeof(int));
	rear = (int*)((unsigned char *)outbuf + 2 * sizeof(int));
	freq = (int*)((unsigned char *)outbuf + 3 * sizeof(int));

	*front = *middle = *rear = *freq = 0;
	if(dic->use == NO) return(0);
	prt = (unsigned char*)zooword;
	size = strlen((char *)zooword);
	address = dic->first_char_addr[*prt];
	if(address == 0) return(0);
	for(;;)
	{
		address = get_node(dic,address,key,&tag,&ynext,front,middle,rear,freq);
		for(i=0;key[i]!='\0';i++,prt++,length++)
			if(*prt != key[i]) break;
		if(i == 0) 
		{
			if(ynext!=0)    address = ynext;
			else         break;
			continue;
		}
		if(key[i] != '\0') break;
		if(tag != 0) 
		{
			strncpy(found,zooword,length);
			result = length;
			found[length] = '\0';
			if(!strcmp(zooword,found)) return(1);
		}
		if(*prt == '\0') break;
		if(address == 0) break;
	}
	*front = *middle = *rear = *freq = 0;
	return(0);
}

static unsigned long get_node(dic_t *dic,
		unsigned long address,
		unsigned char *index,
		unsigned int *tag,
		unsigned long *ynext,
		unsigned int *front,
		unsigned int *middle,
		unsigned int *rear,
		unsigned int *freq)
{
	int   i;
	unsigned int  a,b,size;
	unsigned long next_address;
	unsigned char buffer[100];

	*ynext = 0;
	*tag = 0;
	size = (unsigned int) dic->data[address++];
	for(i = 0; i < (int)size; i++) buffer[i] = dic->data[address++];
	if(0x20&buffer[size-3-8]) next_address = address;
	else              next_address = 0;
	a = buffer[size-4-8];
	b = buffer[size-3-8];
	*tag =  (unsigned int)((a & 0xff) << 2);
	*tag += (unsigned int)((b & 0xc0) >> 6);
	buffer[size-3-8] = buffer[size-3-8] & 0x001f;
	*ynext =  ((buffer[size-3-8]&0xff) << 16);
	*ynext += ((buffer[size-2-8]&0xff) << 8);
	*ynext +=  (buffer[size-1-8]&0xff);
	*front = ((buffer[size-8]&0xff) << 8);
	*front += (buffer[size-7]&0xff);
	*middle = ((buffer[size-6]&0xff) << 8);
	*middle += (buffer[size-5]&0xff);
	*rear = ((buffer[size-4]&0xff) << 8);
	*rear += (buffer[size-3]&0xff);
	*freq = ((buffer[size-2]&0xff) << 8);
	*freq += (buffer[size-1]&0xff);
	buffer[size-4-8] = '\0';
	strcpy(index,buffer);
	return(next_address);
}

/*void print_ftree(unsigned long address, unsigned char *prefix, FILE *fp)
{
	unsigned char keyword[1024];
	unsigned char hangul[1024];
	unsigned long ynext;
	unsigned int  tag;
	unsigned char key[100];
	int	front, middle, rear, freq;
	int   i;


	if(address == 0) return;

	address = HANL_get_fd_node(address,key,&tag,&ynext,&front,&middle,&rear,&freq);
	sprintf(keyword,"%s%s", prefix, key);
	HANL_kimmo2ks(keyword, hangul);
	if(tag != 0) printf("%s\t %d %d %d %d\n", keyword, freq, front, middle, rear);

	if(address != 0) HANL_print_ftree(address, keyword, fp);
	if(ynext !=0)    HANL_print_ftree(ynext, prefix, fp);

#endif
	return (YES);
}*/
