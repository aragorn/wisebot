/****************************************************************
*			STACK ����				*
*                                                               *
*                       Programmed by Cho, Young Hwan           *
*                       Modify by Kim, Eung, Gyun		*
*                       email : choyh@choyh.com			*
*                       at : 3/20 2005                          *
****************************************************************/
#include 	<stdio.h>
#include 	<string.h>
#include	<malloc.h>
#include 	<ctype.h>
#ifndef WIN32
#include	<unistd.h>
#endif
#include	<sys/stat.h>
#include	<fcntl.h>
#include  	"moran.h"
#include	"moran_tagdef.h"
#include	"moran_grammar.h"


int	HANL_InitStack(STACKS_INFO * stacks)
{
	stacks->unknown = 0;
	stacks->stack_info.unknowninfo = 0;
	stacks->stack_info_backup.unknowninfo = 0;
	stacks->stack_info.STACK_CIT_INDEX = 0; 
	stacks->stack_info_backup.STACK_CIT_INDEX = 0;

}

int	HANL_UnknownProcessBasedStack(STACKS_INFO *stacks, unsigned char *zooword)
{
	int	i;
	int	sp = 0;
	int	backup = 0;

	if(0 < stacks->stack_info.unknowninfo && stacks->stack_info.unknowninfo < MAX_STACK_SIZE)
	{
		for(i = 1; i < stacks->stack_info.unknowninfo; i++)
		{
			if(stacks->stack_info.STACK_POSI_FROM[i] == 0 || (int)stacks->stack_info.STACK_POSI_FROM[i] <  backup)
				break;
			else
			{
				backup = stacks->stack_info.STACK_POSI_FROM[i];
				sp++;
			}
		}


		stacks->stack_info.STACK_CIT_NUM[sp] = 1;

		stacks->stack_info.STACK_POSI_FROM[sp] = stacks->stack_info.STACK_POSI_TO[sp-1] + 1;
		stacks->stack_info.STACK_POSI_TO[sp] = strlen((char*)zooword) + 4;
		stacks->stack_info.STACK_CIT_LIST[sp][i][0] = R_UNKNOWN;
		stacks->stack_info.STACK_CIT_LIST[sp][i][1] = L_UNKNOWN;
		stacks->stack_info.STACK_CIT_INDEX = sp + 2;
		return (YES);
	}
	else
	{
		return (NO);
	}
}

/**************************************************************
  ���� �˻��� ������ �ʿ��� ���� ���۷��̼� �κ�

  - push 	: ���ؿ� �߰�
  - pop	: ���ؿ��� ����
  - top	: ������ �ֱ� ���� �˻�
 ***************************************************************/
/* -------------------------------------------------------------
   ���� �˻� ���߿� ������ ����ϴµ�,
   TOP�� ������ �� ���� ���� �����ϴ� �뵵�� ����Ѵ�
   ------------------------------------------------------------- */
int	HANL_top(unsigned int list[MAX_STACK_SIZE][2],STACKS_INFO * stacks)
{
	int	i;

	if(stacks->stack_info.STACK_CIT_INDEX == 0)
	{
		return(0);
	}

	if(stacks->stack_info.STACK_CIT_INDEX > MAX_STACK_SIZE)
	{
		warn("overfolow stack size");
		return MAX_STACK_SIZE-1;
	}

	for(i = 0; i < (int)stacks->stack_info.STACK_CIT_NUM[stacks->stack_info.STACK_CIT_INDEX-1]; i++) 
	{
		list[i][0] = stacks->stack_info.STACK_CIT_LIST[stacks->stack_info.STACK_CIT_INDEX-1][i][0];
		list[i][1] = stacks->stack_info.STACK_CIT_LIST[stacks->stack_info.STACK_CIT_INDEX-1][i][1];
	}
	list[i][0] = 0;
	list[i][1] = 0;
	return(stacks->stack_info.STACK_CIT_NUM[stacks->stack_info.STACK_CIT_INDEX-1]);
}

/* -------------------------------------------------------------
   ���� �˻� ���߿� ������ ����ϴµ�,
   POP�� ������ �� ���� ���� �����ϴ� �뵵�� ����Ѵ�.
   ------------------------------------------------------------- */
void	HANL_pop(STACKS_INFO * stacks)
{
	void	HANL_pop();
	stacks->stack_info.STACK_CIT_INDEX--;
#ifdef 	DEBUGK
	printf("-> ������ �� ���� ���� ����HANL_pop()\n");
#endif
	if((int)stacks->stack_info.STACK_CIT_INDEX < 0)
	{
		warn("overfolow stack size");
	}

#ifdef DEBUG
	printf("HANL_pop(%d,%d) \n", stacks->stack_info.STACK_POSI_FROM[stacks->stack_info.STACK_CIT_INDEX],
			stacks->stack_info.STACK_POSI_TO[stacks->stack_info.STACK_CIT_INDEX]
		  );
#endif

}

/* -------------------------------------------------------------
   ���� �˻� ���߿� ������ ����ϴµ�,
   PUSH�� ���ؿ� ���ο� ���� �� ���� �����ϴ� �뵵�� ����Ѵ�
   ------------------------------------------------------------- */
void	HANL_push(int cnt,unsigned int list[MAX_STACK_SIZE][2],int from,int to,STACKS_INFO * stacks)
{
	int		i;
	void	HANL_push();
#ifdef DEBUG
	printf("HANL_push(%d, from %d, to %d) at Stack[%d]\n", cnt, from, to, stacks->stack_info.STACK_CIT_INDEX);
#endif

	if(cnt < 0)// ������±��̸�
	{
		stacks->stack_info.is_special[stacks->stack_info.STACK_CIT_INDEX] = SPECIAL_ENTRY; 
		cnt = cnt * -1; 
	}
	else
	{
		stacks->stack_info.is_special[stacks->stack_info.STACK_CIT_INDEX] = NORMAL_ENTRY;
	}



	stacks->stack_info.STACK_CIT_NUM[stacks->stack_info.STACK_CIT_INDEX] = cnt;

	for(i = 0; i < cnt; i++) 
	{
		stacks->stack_info.STACK_CIT_LIST[stacks->stack_info.STACK_CIT_INDEX][i][0] = list[i][0];
		stacks->stack_info.STACK_CIT_LIST[stacks->stack_info.STACK_CIT_INDEX][i][1] = list[i][1];
	}
	stacks->stack_info.STACK_POSI_FROM[stacks->stack_info.STACK_CIT_INDEX] = from;
	stacks->stack_info.STACK_POSI_TO[stacks->stack_info.STACK_CIT_INDEX] = to;

	if(stacks->stack_info.STACK_CIT_INDEX >= MAX_STACK_SIZE)
	{
		warn("overfolow stack size");
		stacks->stack_info.STACK_CIT_INDEX = 0;
	}
	stacks->stack_info.STACK_CIT_INDEX++;
}

/* ------------------------------------------------------------
 * ���� �м��Ǵ� ������ ���ؼ� Ư�� ����(������ ����ִ���, 
 * ����� Űǥ�����̴���)�� ������ BACKUP STACK�� ī�Ǹ� �Ѵ�)
 * -----------------------------------------------------------*/
void	HANL_copy_stack(STACKS_INFO * stacks)
{
	int	i;
	int	j;
	void	HANL_copy_stack();

	for(i = 0; i < (int)(stacks->stack_info.STACK_CIT_INDEX); i++) 
	{
		stacks->stack_info_backup.STACK_CIT_NUM[i] = stacks->stack_info.STACK_CIT_NUM[i];

		for(j = 0; j < (int)(stacks->stack_info_backup.STACK_CIT_NUM[i]); j++) 
		{
			stacks->stack_info_backup.STACK_CIT_LIST[i][j][0] = stacks->stack_info.STACK_CIT_LIST[i][j][0]; 
			stacks->stack_info_backup.STACK_CIT_LIST[i][j][1] = stacks->stack_info.STACK_CIT_LIST[i][j][1]; 
		}

		stacks->stack_info_backup.STACK_POSI_FROM[i] = stacks->stack_info.STACK_POSI_FROM[i] ;
		stacks->stack_info_backup.STACK_POSI_TO[i]   = stacks->stack_info.STACK_POSI_TO[i];
		stacks->stack_info_backup.is_special[i]      = stacks->stack_info.is_special[i];
	}
	stacks->stack_info_backup.STACK_CIT_INDEX = stacks->stack_info.STACK_CIT_INDEX;
}


int     HANL_stack_empty(STACKS_INFO * stacks)
{
	if(stacks->stack_info_backup.STACK_CIT_INDEX == 0)
		return(1);
	else	
		return(0);

}

int     HANL_stack_have_special_entry(STACKS_INFO * stacks)
{
	int   i;

	for(i = 0; i < (int)stacks->stack_info.STACK_CIT_INDEX; i++)
	{
		if((int)stacks->stack_info.is_special[i] == 1)			return(1);
	}
	return(0);

}

int     HANL_stack_backup_has_no_special_entry(STACKS_INFO * stacks)
{
	int   i;

	for(i = 0; i < (int)stacks->stack_info_backup.STACK_CIT_INDEX; i++)
	{
		if((int)stacks->stack_info_backup.is_special[i] == 1) 
			return(0);
	}
	return(1);

}

/* ------------------------------------------------------------
 * BACKUP STACK�� CURRENT STACK�� ī���Ѵ�.
 * ������ ���α׷��� �Ǿ� �ִ� �κ��� �ּ��� �������� �ʱ� ����
 * -----------------------------------------------------------*/
int	HANL_copy_stack_backup(STACKS_INFO * stacks)
{
	int     i;
	int     j;

#ifdef DEBUG
	printf("Copy Stack BACK  CALLed !!! \n");
	printf("STACK has [%d] morphemes\n", stacks->stack_info_backup.STACK_CIT_INDEX);
#endif

	for(i = 0; i < (int)stacks->stack_info_backup.STACK_CIT_INDEX; i++)
	{
		stacks->stack_info.STACK_CIT_NUM[i] = stacks->stack_info_backup.STACK_CIT_NUM[i];

		for(j = 0; j < (int)stacks->stack_info.STACK_CIT_NUM[i]; j++)
		{
			stacks->stack_info.STACK_CIT_LIST[i][j][0] = stacks->stack_info_backup.STACK_CIT_LIST[i][j][0];
			stacks->stack_info.STACK_CIT_LIST[i][j][1] = stacks->stack_info_backup.STACK_CIT_LIST[i][j][1];
		}

		stacks->stack_info.STACK_POSI_FROM[i] = stacks->stack_info_backup.STACK_POSI_FROM[i];
		stacks->stack_info.STACK_POSI_TO[i] = stacks->stack_info_backup.STACK_POSI_TO[i];
		stacks->stack_info.is_special[i] = stacks->stack_info_backup.is_special[i];
#ifdef DEBUG
		printf("Stack[%d] = (%d, %d) with %d match, and is_special=%d\n", i, stacks->stack_info.STACK_POSI_FROM[i],
				stacks->stack_info.STACK_POSI_TO[i], stacks->stack_info.STACK_CIT_NUM[i],
				stacks->stack_info.is_special[i]);
#endif

	}
	stacks->stack_info.STACK_CIT_INDEX = stacks->stack_info_backup.STACK_CIT_INDEX;
#ifdef DEBUG
	printf("Copy Stack Back returns = %d\n", stacks->stack_info.STACK_CIT_INDEX);
#endif

	return(int)(stacks->stack_info.STACK_CIT_INDEX);
}
