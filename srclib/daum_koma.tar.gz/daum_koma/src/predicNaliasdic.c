/****************************************************************
 *			���ξ� ������� ���̺귯��  �κ�	*
 *                                                               *
 *                       Programmed by Cho, Young Hwan           *
 *                       Modify by Kim, Eung, Gyun		*
 *                       email : choyh@choyh.com			*
 *                       at : 3/20 2005                          *
 ****************************************************************/
#include "predicNaliasdic.h"
#include "config.h"
#include "codelib.h"

#include <stdlib.h>

//6.25����   22/6.25/65 22/����/65
//���ִ¼���  33/����/129 87/��/197 22/����/65


#ifdef WIN32
#	include "strtok_r.h"
#endif

/* ��м� ������ �м��� ����� final_info ����ü�� �Ľ��Ͽ� �� �Է� */
int	HANL_ParsingPreviouslyAnalyzedDictionary(FINAL_INFO * final_info,char * targetString, int i, char * inputstring)
{
	int		ret = 0;
	int		ltagnum = 0;
	int		rtagnum = 0;
	
	char	*bp = NULL;
	char	*wp = NULL;
	char	*wpp = NULL;
	char	*bar = NULL;
	char	*token = NULL;
	char	word[MAX_LINE];
	char	string[MAX_LINE];
	unsigned char	zooword[MAX_LINE];

	token = strstr(targetString,"\t");
	*(token++) = '\0';
	if(token != NULL)	strcpy(string,token);
	else	return NO;

	//�ϳ��� ���� ����
	wp = strtok_r(string,DEF_DIV_SPACE,&bp);

	for(;;)
	{
	
		if(wp == NULL)	break;

		//���±�
		wpp = wp;
		bar = strstr(wp,DEF_DIV_SLASH);
		if(bar != NULL)
		{
			*(bar)++ = '\0';
			ltagnum = atoi(wpp);
		}
		else	return NO;

		//Ű����
		wpp = bar;
		bar = strstr(bar,DEF_DIV_SLASH);
		if(bar != NULL)
		{
			*(bar)++ = '\0';
			strcpy(word,wpp);
		}
		else	return NO;

		//���±�
		wpp = bar;
		bar = strstr(bar,DEF_DIV_SLASH);
		if(bar != NULL)
		{
			*(bar)++ = '\0';
			rtagnum = atoi(wpp);
		}
		else
		{
			rtagnum = atoi(wpp);
		}
			
		
		if (Check_Predic_tag(ltagnum))	
		{
			final_info->result_info[final_info->numberoftoken].Ltag = ltagnum;
			final_info->result_info[final_info->numberoftoken].Rtag = rtagnum;
			final_info->result_info[final_info->numberoftoken].Lidx = L_Tag_Idx[ltagnum];
			final_info->result_info[final_info->numberoftoken].Ridx = R_Tag_Idx[rtagnum];
			final_info->result_info[final_info->numberoftoken].Laction = L_Tag_Action[ltagnum];
			final_info->result_info[final_info->numberoftoken].Raction = R_Tag_Action[rtagnum];
			if(HANL_ks2kimmo(word,zooword) == 0) 	return(NO);
			
			final_info->result_info[final_info->numberoftoken].start = 
				final_info->result_info[final_info->numberoftoken-1].end;

			final_info->result_info[final_info->numberoftoken].end =
				final_info->result_info[final_info->numberoftoken-1].end+(int)strlen(zooword);
		
			strcpy(final_info->result_info[final_info->numberoftoken++].tag,L_Tag_Set[ltagnum]);
		}
		
		//�ϳ��� ���� ����
		wp = strtok_r(NULL,DEF_DIV_SPACE,&bp);
	}

	if(HANL_ks2kimmo(inputstring,zooword) == 0) 	return(NO);
	return HANL_AboutIndexing(final_info,zooword,&ret);

}



int	HANL_PreviouslyAnalyzedDictionary(char   *ksword,FINAL_INFO * final_info)
{
	int		i = 0;
	int		size = 0;
	int		sim_level = 0;
	char	*pWord = NULL;
	char	*token = NULL;
	char    res[1024] = {0,};
	char	buffer[1024] = {0,};

	size = (int)strlen(ksword);
	DelNewline(ksword,size);
	pWord = ksword;
	sim_level = Get_SIM_WORD();

#ifdef	DEBUG1
	printf("HANL_PreviouslyAnalyzedDictionary()\n");
#endif
	HANL_call_search_trie(pWord, res,PREDIC);
	if(*res != '\0')
	{
		final_info->result_info[final_info->numberoftoken].where = WHERE_PREDICTIONARY;
		if(HANL_ParsingPreviouslyAnalyzedDictionary(final_info, res,final_info->numberoftoken,pWord) == YES)
		{
			pWord = pWord+strlen(res);
			strcpy(ksword, pWord);
		}
	}

	if(res != NULL && (pWord == NULL || strlen(ksword) <= strlen(res)))
	{
#ifdef	DEBUG3
		printf("��м����� �м��� �Ϸ�Ǿ����ϴ�\n");
#endif
		if(sim_level > 0)
		{
			for(i = 1; i <= final_info->numberoftoken; i++)
			{
				*buffer = '\0';

				HANL_call_search_trie(final_info->result_info[i].word, buffer,ALIASDIC);
#ifdef	DEBUG3			
				printf("���� ����(%s)(%s)\n",final_info->result_info[i].word, buffer);
#endif			
				if(*buffer != '\0')
				{
					final_info->numberoftoken = i;
					token = strstr(buffer,SEP);

					if(token != NULL)
					{
						*(token)++ = '\0';
						final_info->numberoftoken = HANL_ParsingAliasDictionaryResultParsing(final_info, token, final_info->numberoftoken,final_info->result_info[i].word);

						i = final_info->numberoftoken;
						if(strcmp(final_info->result_info[i + 1].tag,TAG_JOSA) == 0)
						{
							strcpy(final_info->result_info[i + 1].tag,TAG_JOSA);
							i++;
						}
					}
				}
			}


		}
		return YES;
	}
	return NO;
}


int		HANL_SetMorph(morphem * morph,int *midx, char * str,int tagnum)
{
	strcpy(morph[(*midx)].word, str);
	morph[(*midx)++].tagnum = tagnum;
	return YES;
}

/* ���� ������ �м��� ����� final_info ����ü�� �Ľ��Ͽ� �� �Է� */
int	HANL_ParsingAliasDictionaryResultParsing(FINAL_INFO * final_info,char * s, int i, char * inputstring)
{
	int     k = 0;
	int		start = 0;
	int		where = 0;
	int		size = 0;
	int		midx = 0;
	int		ridx = 0;
	int		fidx = 1;
	int		tagnum = -1;
	int		sim_level = 0;
	int		old_tagnum = 0;
	int		new_tagnum = 0;
	int		all_same_tagnum = 1;

	char    *bp = NULL;
	char	*str = NULL;
	char    *bar = NULL;
	char	*token = NULL;
	char	string[1024];
	unsigned char  	temp[MAX_LINE];

	morphem     morph[10];
	RESULT_INFO result_info[10];
	FINAL_INFO  final_info_backup;

#ifdef	DEBUG1
	printf("HANL_ParsingAliasDictionaryResultParsing()\n");
#endif
	sim_level = Get_SIM_WORD();

	if(!final_info->numberoftoken)  final_info->numberoftoken = 1;

	memcpy(&final_info_backup.result_info[0], &final_info->result_info[0], sizeof(final_info->result_info[0])*final_info->numberoftoken);

	strcpy(string,s);
	str = string;
	token = strtok_r(str,DEF_DIV_SPACE,&bp);

	if(token != NULL)
	{
		bar = strstr(token,DEF_DIV_SLASH);
		*(bar)++ = '\0';
		old_tagnum = atoi(bar);
		if(Check_INDEXING_LEVEL(R_Tag_Idx[old_tagnum]))
		{
			HANL_SetMorph(morph, &midx, str,old_tagnum);
		}
	}

	if(final_info->result_info[i].expand < 0)	sim_level = 4;

	token = strtok_r(NULL,DEF_DIV_SPACE,&bp);

	while(token != NULL && (sim_level == 2 || sim_level == 4))
	{
		str = token;
		bar = strstr(token,DEF_DIV_SLASH);
		*(bar)++ = '\0';
	
		tagnum = atoi(bar);
		HANL_SetMorph(morph,&midx, str,tagnum);
		new_tagnum = morph[midx-1].tagnum;
		if(old_tagnum != new_tagnum && all_same_tagnum == 1)	
			all_same_tagnum = 0;
		token = strtok_r(NULL,DEF_DIV_SPACE,&bp);
	}


	if(sim_level == 1 || sim_level == 2)// �Է� ������ ��� 
	{
		HANL_SetResult_info(result_info, &ridx, inputstring, NULL, WHERE_ALIAS_KEYWORD, 0, strlen(result_info[ridx].word),final_info->result_info[i].Ltag,  morph[k].tagnum, -1);
		if(all_same_tagnum)	
			result_info[ridx].expand = 1 + i;
		ridx++;
	}

	start = (int)strlen(result_info[ridx].word);
	where = WHERE_ALIAS_KEYWORD;
//	fprintf(stderr,"start : %d -- where : %d\n",start,where);
	// ù��° ���Ǿ ���
	if(midx > 0)
	{
		HANL_SetResult_info(result_info,&ridx,morph[0].word,R_MTag_Set[morph[0].tagnum], where, 0, size,final_info->result_info[i].Ltag,  morph[k].tagnum, -1);
		if(all_same_tagnum)	
		{
			if(ridx > 0 && result_info[ridx - 1].expand == 0)           result_info[ridx - 1].expand = ridx + 1;
			result_info[ridx].expand = 0;
		}
		ridx++;
	}


	if(sim_level == 2 || sim_level == 4) 							// �ι�° ������ ���Ǿ ���
	{
		if(all_same_tagnum)	
		{
			if(midx >= 1)			result_info[ridx-1].expand = 1 + i;
		}

		for(k = 1; k < midx; k++)
		{
			HANL_SetResult_info(result_info, &ridx, morph[k].word,R_MTag_Set[morph[k].tagnum],WHERE_ALIAS_KEYWORD,0,strlen(result_info[ridx].word),final_info->result_info[i].Ltag, morph[k].tagnum, -1);
			if(all_same_tagnum)	
			{
				if(sim_level == 4)		result_info[ridx].expand = 1 + k + i;
				else					result_info[ridx].expand = 2 + k + i;
			}
			ridx++;
		}
	}
	result_info[ridx - 1].expand = 0;
	///////////////////////////////////////////////////////////////////////////
	// ���� ����
	if(Check_ROOT_VERB() )
	{
		for(k = 0; k < ridx; k++)
		{
			if((R_PV_RG <= result_info[k].Rtag && result_info[k].Rtag <= R_PV_CON_S) ||
					(R_PA_RG <= result_info[k].Rtag && result_info[k].Rtag <= R_PA_AUX_CON_B))
			{
				if(result_info[k+1].Rtag == R_EP || 
						result_info[k+1].Rtag == R_EF ||
						result_info[k+1].Rtag == R_EF_END ||
						result_info[k+1].Rtag == R_EF_CON ||
						result_info[k+1].Rtag == R_EFA || 
						result_info[k+1].Rtag == R_ETN)
				{

					HANL_RestoreInputVerb(result_info[k].word, result_info[k+1].word, temp);
					HANL_RestoreRootVerb(result_info[k].word, result_info[k+1].word, result_info[k].Rtag);//HANL_rcv_form
					//HANL_RestoreRootVerb(result_info[k].word, result_info[k+1].word);						//attach '��'
					strcpy(result_info[k].word,temp);
					result_info[k].expand = -1;
					strcpy(result_info[k+1].tag, result_info[k].tag);
					k++;
				}
			}
		}
	}
	///////////////////////////////////////////////////////////////////////////

	if(ridx > 0)
	{
		HANL_InsertSlot(final_info, &final_info_backup, result_info, &fidx, &ridx, &i);
		final_info->numberoftoken += (ridx-1);
	}
	else
	{
		fidx = final_info->numberoftoken;
	}

	HANL_Recombination(final_info);

	return fidx;
}

int		HANL_RestoreInputVerb(char	 *word1, char	*word2, char *temp)
{
	char	abc1[1024];
	char	abc2[1024];
	char	abc3[1024];
	int		len = 0;
	if(HANL_ks2kimmo(word1,abc1) == 0)	return(NO);
	if(HANL_ks2kimmo(word2,abc2) == 0)	return(NO);

	len = (int)strlen(abc1) - 1;
	if(((unsigned char)(abc1[len] - 128) == (int)'o') && (unsigned char)(abc2[0] - 128) == (int)'a')
	{
		abc1[len] = 128 + 'w';
	}
	sprintf(temp,"%s%s",abc1,abc2);
	HANL_kimmo2ks(temp,abc3);
	strcpy(temp,abc3);
	return (YES);

}

int		HANL_Recombination(FINAL_INFO	*final_info)
{
	int		i;
	int     size;
	char    temp[256];
	for(i = 1; i < final_info->numberoftoken; i++)
	{
		size = (int)strlen(final_info->result_info[i].word);
		if((char)final_info->result_info[i].word[size-2] == (char)0xa4)
		{
			if(HANL_ks2kimmo(final_info->result_info[i].word,temp) == 0)   return(NO);
			HANL_make_morpheme(0,(int)strlen(temp),temp,final_info->result_info[i].word);
			return YES;
		}
	}
	return NO;
}
