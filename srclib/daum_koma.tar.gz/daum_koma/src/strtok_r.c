#include "strtok_r.h"
#include <stdio.h>

#ifdef WIN32
// XXX: assume delim is only one, although we accept array of characters
char *strtok_r(char *str, char *delim, char **ptrptr) 
{
	char *ptr;

	// set start point
	if (str == NULL) {
		if (*ptrptr == NULL) return NULL;
		str = *ptrptr;
	}

	if (str[0] == '\0') return NULL;

	// skip sequence of delim
	while (*str == *delim && *str!='\0') str++;
	if (*str == '\0') return NULL;
	ptr = str;

	// find next delim
	while (*str != *delim && *str!='\0') str++;
	if (*str != '\0') {
		*str = '\0';
		*ptrptr = ++str;
	}
	else {
		*ptrptr = NULL;
	}

	return ptr;
}
#endif
