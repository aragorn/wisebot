/* $Id: trie.c,v 1.8 2006/04/27 01:29:49 nominam Exp $ */
#include "trie.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define         EMPTY                   0
#define         XNEXT                   1
#define         YNEXT                   2
#define         COMPLETE                3
#define         MIDLE                   4

static trie_node_t* get_node(trie_t *trie);
static trie_node_t *match_trie(trie_t *trie, const char *key, char *rest, int *status);

trie_t *create_trie_handler()
{
	trie_t *trie;
	trie = (trie_t *)malloc(sizeof(trie_t));

	trie->root_node = NULL;
	return trie;
}

void destroy_trie_handler(trie_t *this)
{
	free(this);
}

int trie_insert_entry(trie_t *trie, const char *key, int rsv0, int rsv1)
{
	trie_node_t *new, *cp;
	int str_len, i, status;
	char rest[1024], *s;

	cp = match_trie(trie, key, rest, &status);
	str_len = strlen(rest);
	s = &rest[0];
	if(str_len >= 1)
	{
		new = get_node(trie);
		new->Code = *s; s++;
		if(cp == NULL)
		{
			new->ynext = trie->root_node;
			trie->root_node = new;
		}
		else
		{
			if(status == XNEXT)
				cp->xnext = new;
			if(status == YNEXT)
			{
				new->ynext = cp->ynext;
				cp->ynext  = new;
			}
			if(status == MIDLE)
			{
				new->ynext = cp->xnext;
				cp->xnext  = new;
			}
		}
		cp = new;
	}
	for(i=1;i<str_len;i++)
	{
		new = get_node(trie);
		new->Code = *s; s++;
		cp->xnext = new;
		cp = new;
	}

	cp->rsv0 = rsv0;
	cp->rsv1 = rsv1;
	return 1;
}

static trie_node_t *match_trie(trie_t *trie,const  char *key, char *rest, int *status)
{
	const	char		*s;
	int			midle_chance = 1;
	trie_node_t     *cp,*cp_1;

	cp   = trie->root_node;
	cp_1 = NULL;
	s = key;
	*status = YNEXT;
	if(cp == NULL) // if root
	{
		strcpy(rest,s);
		*status = EMPTY;
		return(NULL);
	}
	for(;;)
	{
		if(*s == '\0')
		{
			strcpy(rest,"");
			*status = COMPLETE;
			return(cp_1);
		}
		if(cp->Code == *s)
		{
			s++;
			if(*s == '\0')
			{
				strcpy(rest,"");
				*status = COMPLETE;
				return(cp);
			}
			cp_1 = cp;
			cp = cp->xnext;
			if(cp == NULL)
			{
				strcpy(rest,s);
				*status = XNEXT;
				return(cp_1);
			}
			midle_chance=1;
			continue;
		}

		if((midle_chance == 1) && (*s < cp->Code))
		{
			strcpy(rest,s);
			*status = MIDLE;
			return(cp_1);
		}

		if(cp->ynext == NULL)
		{
			strcpy(rest,s);
			*status = YNEXT;
			return(cp);
		}

		if((cp->ynext != NULL) && (*s < cp->ynext->Code))
		{
			strcpy(rest,s);
			*status = YNEXT;
			return(cp);
		}
		cp_1 = cp;
		cp   = cp->ynext;
		midle_chance=0;
	}
}

static trie_node_t* get_node(trie_t *trie)
{
	trie_node_t *new;

//	NODE_SIZE++;
	new = (trie_node_t *)malloc(sizeof(trie_node_t));
	if(new == NULL)
	{
		fprintf(stderr," NO MORE SPACE !!! EXIT\n");
		exit(0);
	}

	new->Code = '\0';
	new->rsv0  = 0;
	new->rsv1  = 0;

	new->xnext = NULL;
	new->ynext = NULL;

	return new;
}

void optimize(trie_t *trie, trie_node_t *node)
{
	char    *ptr;

	if(node == NULL) return;
	ptr = node->Str;
	*ptr = node->Code;
	ptr++;
	while(1)
	{
		if(node->xnext == NULL) break;
		if(node->xnext->ynext != NULL) break;
		if(node->rsv0 != 0) break;

		*ptr = node->xnext->Code;
		ptr++;

		node->rsv0 = node->xnext->rsv0;
		node->rsv1 = node->xnext->rsv1;

		node->xnext = node->xnext->xnext;
	}
	*ptr = '\0';
	if(node->xnext != NULL) optimize(trie, node->xnext);
	if(node->ynext != NULL) optimize(trie, node->ynext);
}

void print_tree(trie_node_t *node, int depth)
{
	int i;

	if(node == NULL) return;
	printf("->[%c|%d]",node->Code, node->rsv0);
	if(node->xnext != NULL) print_tree(node->xnext,depth+1);
	if(node->ynext != NULL) {
		printf("\n");
		for(i=0;i<depth;i++) printf("->{ # }");
		print_tree(node->ynext,depth);
	}
}
