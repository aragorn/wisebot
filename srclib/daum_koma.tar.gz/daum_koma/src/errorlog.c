/* $Id: errorlog.c,v 1.13 2006/04/27 01:29:49 nominam Exp $ */
#ifdef WIN32
#	define COLOROFF
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "errorlog.h"

int screenlog = 1;
int errorlog_level = LEVEL_DEBUG;
static FILE *fplog = NULL;

void open_errorlog(const char *file) 
{
		if (screenlog)
			return;

		if((fplog = freopen(file,"a",stderr)) == NULL)
		{
			fprintf(stderr, "cannot open error log file %s", file);
			exit(1);
		}
//		setlinebuf(stderr);
		return;
}

#ifdef WIN32
void debug(char *format, ...)
{
	va_list args;

	va_start(args, format);
	vfprintf(stdout, format, args);
	fprintf(stderr, "\n");
	va_end(args);
}

void info(char *format, ...)
{
	/* not implemented in win32 platform */
}

void warn(char *format, ...)
{
	/* not implemented in win32 platform */
}

void error(char *format, ...)
{
	/* not implemented in win32 platform */
}
#endif

void errorlog(int level, const char *file, int line, const char *format, ...) 
{
	va_list args;

	va_start(args, format);

	if (level >= errorlog_level)
		switch (level) 
		{
#ifdef	COLOROFF
			case LEVEL_DEBUG:
				fprintf(stderr,"[debug] %s:%d: ",file, line);				break;
			case LEVEL_INFO:
				fprintf(stderr,"[info*] %s:%d: ",file, line);				break;
			case LEVEL_WARN:
				fprintf(stderr,"[warn*] %s:%d: ",file, line);				break;
			case LEVEL_ERROR:
				fprintf(stderr,"[error] %s:%d: ",file, line);				break;
#else				
			case LEVEL_DEBUG:
				fprintf(stderr,"[%s%sdebug%s] %s:%d: ",GREEN,BOLD,RESET, file, line);				break;
			case LEVEL_INFO:
				fprintf(stderr,"[%s%sinfo*%s] %s:%d: ",BLUE,BOLD,RESET, file, line);				break;
			case LEVEL_WARN:
				fprintf(stderr,"[%s%swarn*%s] %s:%d: ",YELLOW,BOLD,RESET, file, line);				break;
			case LEVEL_ERROR:
				fprintf(stderr,"[%s%serror%s] %s:%d: ",RED,BOLD,RESET, file, line);					break;
#endif
		}

	vfprintf(stderr, format, args);
	fprintf(stderr, "\n");
	va_end(args);
}

void log_assert(const char *file, int line, int statm, const char *format, ...) 
{
	va_list args;
	va_start(args, format);
	if (!statm) 
	{
		errorlog(LEVEL_ERROR,file,line,format,args);
		exit(1);
	}
	va_end(args);
}
