/* $Id: mksti.c,v 1.16 2006/04/28 01:16:31 jchern Exp $ */
/**********************************************************************

  �ý��� ������ �������ϴ� ���� v2.0

  Designed & Implemented by
  Cho, Young Hwan
  choyh@csking.kaist.ac.kr
  1997. 4. 4

 **********************************************************************/
//#include 	"systemdic.h"
//#include	"manage_dict.h"
#include	"trie.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "moran.h"
#include "moran_tagdef.h"

#define MAX_NODE_NUM		2000000
#define MAX_LEN				4000
#define MAX_TAG_LIST		30
#define MAX_TAG_NUM			40

/* local function */

void init_tag_ble();
void down_load_dict(char *fn);
void load_special_dict(char *fn);
void load_text_dict(char *fn);

static int unify_num(int tags[][2],int cnt);
static void numbering(trie_node_t *node, int depth);
static int read_zoo_word(FILE *fp,char *word,int *lnum,int *rnum);
static int check_tagtype(int tags[MAX_TAG_NUM][2],int size);

/* variables */
static int	TAGS_SIZE[MAX_LEN];
static int	L_TAGS_LIST[MAX_LEN][MAX_TAG_NUM];
static int	R_TAGS_LIST[MAX_LEN][MAX_TAG_NUM];
static int	TAGTYPE = 0;

static trie_node_t *Index_List[MAX_NODE_NUM];
static int  Index_Seek[MAX_NODE_NUM];
static int	NODE_NUM = 1;
static int	NODE_SIZE = 1;
static int	word_cnt = 1;

// XXX: temporary; use trie.c module directly
//      must use systemdic.c module
//#define TRIE_OBJ		(((systemdic_t*)sdic.childobj)->trie)
//#define ROOT_NODE		(((systemdic_t*)sdic.childobj)->trie->root_node)
//static dic_t sdic;

#define TRIE_OBJ		(trie)
#define ROOT_NODE		(trie->root_node)
static trie_t *trie;

int main(int ac,char * ag[])
{
	int	i;

	// parameter check
	if(ac != 4) 
	{ 
		fprintf(stderr,"���� :$%s �Է�ȭ�ϸ� ��������ϸ� ���ȭ�ϸ�\n",ag[0]);
		exit(1);
	}
	if(!strcmp(ag[1],ag[2]))
	{
		fprintf(stderr,"�Է�ȭ�ϰ� ���ȭ�ϸ��� ���� �� �����ϴ�.\n");
		exit(1);
	}

	// XXX: static variables are already zero
	for(i = 0; i < MAX_LEN; i++)
	{
		memset(L_TAGS_LIST[i],0,MAX_TAG_NUM);
		memset(R_TAGS_LIST[i],0,MAX_TAG_NUM);
	}

	// initialize
	trie = create_trie_handler();
//	systemdic_init(&sdic);
//	systemdic_open(&sdic);

	init_tag_ble();
	load_text_dict(ag[1]);
	load_special_dict(ag[2]);

	// build dictionary
	optimize(TRIE_OBJ, ROOT_NODE);
	numbering(ROOT_NODE, 0);

#ifdef	DEBUG
	fprintf(stderr,"[mksti]\t%d Word LOADED!!!\n",word_cnt);
	fprintf(stderr,"[mksti]\t%d Nodes (%d%% Optimized)\n", NODE_NUM,(((NODE_SIZE-NODE_NUM)*100)/NODE_SIZE));
	fprintf(stderr,"[mksti]\t%d Tag Types\n\n",TAGTYPE);
	fprintf(stderr,"[mksti]\t%d Byte Needed!!!\n",Index_Seek[NODE_NUM-1]+MAX_TAG_NUM);
#endif

	down_load_dict(ag[3]);

	return 0;
}

void init_tag_ble()/*{{{*/
{

	TAGS_SIZE[BOE] = 1;     /* Left Space, Start of word-phrase */
	L_TAGS_LIST[BOE][0] = L_BOE;
	R_TAGS_LIST[BOE][0] = R_BOE;
#ifdef	DEBUG
	fprintf(stderr,"	[mksti]\tL_BOE = %d\tR_BOE=%d\n",L_BOE,R_BOE);
#endif
	TAGS_SIZE[EOE] = 1;     /* Right Space, End of word-phrase */
	L_TAGS_LIST[EOE][0] = L_EOE;
	R_TAGS_LIST[EOE][0] = R_EOE;
#ifdef	DEBUG
	fprintf(stderr,"	[mksti]\tL_EOE = %d\tE_BOE=%d\n",L_EOE,R_EOE);
#endif
	TAGS_SIZE[NO_WHITE] = 1;        /* Left Special Characters */
	L_TAGS_LIST[NO_WHITE][0] = L_UNKNOWN;
	R_TAGS_LIST[NO_WHITE][0] = R_UNKNOWN;
	TAGS_SIZE[UNOUN_N_TAG] = 1;     /* ����� ������ �������� ���Ͽ� */
	L_TAGS_LIST[UNOUN_N_TAG][0] = L_UNOUN;
	R_TAGS_LIST[UNOUN_N_TAG][0] = R_UNOUN_N;
	TAGS_SIZE[UNOUN_Y_TAG] = 1;     /* ����� ������ �������� ���Ͽ� */
	L_TAGS_LIST[UNOUN_Y_TAG][0] = L_UNOUN;
	R_TAGS_LIST[UNOUN_Y_TAG][0] = R_UNOUN_Y;
	TAGS_SIZE[UNOUN_L_TAG] = 1;     /* ����� ������ �������� ���Ͽ� */
	L_TAGS_LIST[UNOUN_L_TAG][0] = L_UNOUN;
	R_TAGS_LIST[UNOUN_L_TAG][0] = R_UNOUN_L;
	TAGS_SIZE[ENG_N_TAG] = 1;       /* ���� �ܾ ���Ͽ� */
	L_TAGS_LIST[ENG_N_TAG][0] = L_ENG;
	R_TAGS_LIST[ENG_N_TAG][0] = R_ENG_N;
	TAGS_SIZE[ENG_Y_TAG] = 1;       /* ���� �ܾ ���Ͽ� */
	L_TAGS_LIST[ENG_Y_TAG][0] = L_ENG;
	R_TAGS_LIST[ENG_Y_TAG][0] = R_ENG_Y;
	TAGS_SIZE[ENG_C_TAG] = 1;       /* ���� �ܾ ���Ͽ� */
	L_TAGS_LIST[ENG_C_TAG][0] = L_ENG;
	R_TAGS_LIST[ENG_C_TAG][0] = R_ENG_C;
	TAGS_SIZE[NUM_TAG] = 5; /* ���ڿ��� ���Ͽ�      */
	L_TAGS_LIST[NUM_TAG][0] = L_NUM;
	R_TAGS_LIST[NUM_TAG][0] = R_NUM;
	L_TAGS_LIST[NUM_TAG][1] = L_NUM;
	R_TAGS_LIST[NUM_TAG][1] = R_NUM_Y;
	L_TAGS_LIST[NUM_TAG][2] = L_NUM;
	R_TAGS_LIST[NUM_TAG][2] = R_NUM_L;
	L_TAGS_LIST[NUM_TAG][3] = L_NUM;
	R_TAGS_LIST[NUM_TAG][3] = R_NUM_X;
	L_TAGS_LIST[NUM_TAG][4] = L_NUM;
	R_TAGS_LIST[NUM_TAG][4] = R_NUM_N;
	TAGS_SIZE[HANJA_TAG] = 1;   /* ���ڿ��� ���Ͽ�      */
	L_TAGS_LIST[HANJA_TAG][0] = L_HANJA;
	R_TAGS_LIST[HANJA_TAG][0] = R_HANJA;
	TAGTYPE = SDICT_TAG_START;

}/*}}}*/

void down_load_dict(char *fn)/*{{{*/
{
	FILE    *fp;
	int   	i,j;
	trie_node_t *cp;
	int		base,firsts=0,first_size=0;
	unsigned char	info1,info2,info3,info4,info5;

	fp = fopen(fn,"w");
	if(fp == NULL) 
	{
		fprintf(stderr,"[mksti]\tFILE WRITE ERROR [%s]\n",fn);
		exit(0);
	}
//	printf("%d LRCTYPE DOWNLOAD!!!!\n",TAGTYPE);

	for (cp=ROOT_NODE; cp!=NULL; cp=cp->ynext) 
		firsts++;

	first_size = firsts*5;// 5��(cp->Str[0],add1,add2,add3,add4))�� ���� ����
#ifdef	DEBUG
	fprintf(stderr,"[mksti]\tù��� %d��\n",firsts);
#endif

	info1 = firsts;
	info2 = (TAGTYPE & 0xff00)>>8;
	info3 = (TAGTYPE & 0x00ff);
	info4 = (first_size & 0xff00)>>8;
	info5 = (first_size & 0x00ff);
	fprintf(fp,"%c%c%c%c%c",info1,info2,info3,info4,info5);


	printf("#ifndef	__SYSTEMLOG_H_\n");
	printf("#define	__SYSTEMLOG_H_\n");
	printf("//[�±�Ÿ��]\t���±�\t���±�\n");
	printf("static int	TAGLIST[%d][2] = {\n",TAGTYPE);
	printf("/*[%4d]*/\t{%3d,%3d},\n", 0,0,0);
	
	for(i = 1; i < TAGTYPE; i++) 
	{
		fprintf(fp,"%d ",TAGS_SIZE[i]);

		for(j=0;j<TAGS_SIZE[i];j++) 
		{
			fprintf(fp,"%3d %3d ", L_TAGS_LIST[i][j],R_TAGS_LIST[i][j]);
	
			if(j == 0)
			{
				printf("/ *[%4d]* /\t{%3d,%3d},",i,L_TAGS_LIST[i][j],R_TAGS_LIST[i][j]);
			}
			else
			{
				printf("\t/ *{%3d,%3d}* /",L_TAGS_LIST[i][j],R_TAGS_LIST[i][j]);
			}
		}
		printf("\n");
	}

	
	
	printf("};\n");
	printf("#endif\n");

	fprintf(fp,"*");
	base = ftell(fp)+first_size;
	cp = ROOT_NODE;

	while(cp != NULL) 
	{ 
		unsigned char	add1,add2,add3,add4;
		unsigned long	yadd;

		yadd = Index_Seek[cp->index] + base;
		add1 = (yadd & 0x7f000000)>>24;
		add2 = (yadd & 0x00ff0000)>>16;
		add3 = (yadd & 0x0000ff00)>>8;
		add4 =  yadd & 0x000000ff;
		fprintf(fp,"%c%c%c%c%c",cp->Str[0],add1,add2,add3,add4);

#ifdef  DEBUG
		printf("*** %d %c %x %x %x\n",size,cp->Str[0],add1,add2,add3);
#endif
		cp = cp-> ynext;
	}

#ifdef	DEBUG
	fprintf(stderr,"[mksti]\t������ġ : %x\n",ftell(fp));
#endif
	for(i=1;i<NODE_NUM;i++)
	{
		unsigned char   size,b1,b2,b3,b4,b5,b6;
		unsigned long   yadd;

		cp = Index_List[i];
		b1 = (cp->rsv0 & 0xff0) >> 4;
		b2 = (cp->rsv0 & 0x0f) << 4;
		if(cp->xnext != NULL) b2 = (0x08|b2);
		if(cp->ynext != NULL) yadd = Index_Seek[cp->ynext->index] + base;
		else             yadd = 0;
		if(cp->rsv1 == SPECIAL_ENTRY) b2 = b2 | 0x04;
		b3 = (yadd & 0xff000000)>>24;
		b4 = (yadd & 0x00ff0000)>>16;
		b5 = (yadd & 0x0000ff00)>>8;
		b6 =  yadd & 0x000000ff;
		size = strlen(cp->Str)+6;

#ifdef DEBUG
		fprintf(stderr,"size = %d\n",size);
		printf("[%x] ",ftell(fp));
		printf("%d %-10s %2x%2x%2x%2x (b2 = %2x) \n",size,cp->Str,b1,b2,b3,b4,b2);
		fprintf(stderr,"%c%s%c%c%c%c%c%c\n",size,cp->Str,b1,b2,b3,b4,b5,b6);
#endif
#ifdef	WIN32
		if(size == 10 || b1 == 10 || b2 == 10 || b3 == 10 || b4 == 10 || b5 == 10 || b6 == 10)
		{
			if(size == 10)		fputc('10',fp);
			else				fprintf(fp,"%c",size);

			fprintf(fp,"%s",cp->Str);

			if(b1 == 10)		fputc('10',fp);
			else				fprintf(fp,"%c",b1);

			if(b2 == 10)		fputc('10',fp);
			else				fprintf(fp,"%c",b2);

			if(b3 == 10)		fputc('10',fp);
			else				fprintf(fp,"%c",b3);

			if(b4 == 10)		fputc('10',fp);
			else				fprintf(fp,"%c",b4);

			if(b5 == 10)		fputc('10',fp);
			else				fprintf(fp,"%c",b5);

			if(b6 == 10)		fputc('10',fp);
			else				fprintf(fp,"%c",b6);
		}
		else
		{
			fprintf(fp,"%c%s%c%c%c%c%c%c",size,cp->Str,b1,b2,b3,b4,b5,b6);
		}
#else
		fprintf(fp,"%c%s%c%c%c%c%c%c",size,cp->Str,b1,b2,b3,b4,b5,b6);
#endif

	}

	fclose(fp);
}/*}}}*/

void load_special_dict(char *fn)/*{{{*/
{
	FILE  *fp,*fopen();
	int     tagtype;
	int     tags[MAX_TAG_NUM][2];
	char    zooword[100];

	memset(tags,0,sizeof(int)*MAX_TAG_NUM*2);
	if((fp = fopen(fn,"r")) == NULL)
	{
		fprintf(stderr,"[mksti]\tDICT [%s] Not FOUND!!!\n",fn);
		exit(0);
	}
	for(;;)
	{
		if(read_zoo_word(fp,zooword,&tags[0][0],&tags[0][1]) != 1)
			break;

		tagtype = check_tagtype(tags,1);
		//insert_sdict(&sdic, zooword, (int[]) {tagtype, SPECIAL_ENTRY}, sizeof(int)*2);
		trie_insert_entry(trie, zooword, tagtype, SPECIAL_ENTRY);
	}
	fclose(fp);

}/*}}}*/

int intcompare(const void *i,const void *j)
{
	return(*(int*)i - *(int*)j);
}

void load_text_dict(char *fn)/*{{{*/
{
	FILE *fp;
	int	cnt;
	int	tagtype;
	int	tags[MAX_TAG_NUM][2];
	int	tmp_tag[2];
	char	zooword[100];
	char	zooword_1[100];


	memset(zooword_1,0,100);
	memset(zooword,0,100);
	memset(tags,0,sizeof(int)*MAX_TAG_NUM*2);
	if((fp = fopen(fn,"r")) == NULL) 
	{
		fprintf(stderr,"[mksti]\tDICT [%s] Not FOUND!!!\n",fn);
		exit(0);
	}
	read_zoo_word(fp,zooword_1,&tags[0][0],&tags[0][1]);
	cnt = 1;
	for(;;)
	{
		word_cnt++;

		if(read_zoo_word(fp,zooword,&tmp_tag[0],&tmp_tag[1]) != 1) 
		{
			if(cnt >= MAX_TAG_NUM)
			{
				fprintf(stderr,"[mksti]\t[1]������ ������ �ִ�\n");
			}
			qsort(tags,cnt,sizeof(int)*2,intcompare);
			cnt = unify_num(tags,cnt);
			tagtype = check_tagtype(tags,cnt);
			//insert_sdict(&sdic, zooword_1, (int[]) {tagtype, NORMAL_ENTRY}, sizeof(int)*2);
#ifdef	DEBUG
			printf("insert : %s\ttagtype = %d\n",zooword_1, tagtype);
#endif
			trie_insert_entry(trie, zooword_1, tagtype, NORMAL_ENTRY);
			break;
		}

		if(strcmp(zooword_1,zooword)==0)	// ������ 
		{
			tags[cnt][0] = tmp_tag[0];
			tags[cnt][1] = tmp_tag[1];
			if(cnt >= MAX_TAG_NUM)
			{
				fprintf(stderr,"[mksti]\t[2]������ ������ �ִ�\n");
			}
			cnt++;
		}
		else		
		{
			qsort(tags,cnt,sizeof(int)*2,intcompare);//�ٸ���

			cnt = unify_num(tags,cnt);
			tagtype = check_tagtype(tags,cnt);

			//insert_sdict(&sdic, zooword_1, (int[]) {tagtype, NORMAL_ENTRY}, sizeof(int)*2);

#ifdef	DEBUG
			printf("insert : %s\ttagtype = %d\n",zooword_1, tagtype);
#endif
			trie_insert_entry(trie, zooword_1, tagtype, NORMAL_ENTRY);
			strcpy(zooword_1,zooword);
			tags[0][0] = tmp_tag[0];
			tags[0][1] = tmp_tag[1];
			cnt = 1;
		}
	}
	fclose(fp);
}/*}}}*/

static void numbering(trie_node_t *node, int depth)/*{{{*/
{
	if(node == NULL) return;
	Index_List[NODE_NUM] = node;
	Index_Seek[NODE_NUM+1] = Index_Seek[NODE_NUM] + strlen(node->Str) + 7;
	node->index = NODE_NUM++;

	if(node->xnext != NULL) {
		numbering(node->xnext, depth+1);
	}

	if(node->ynext != NULL) {
		numbering(node->ynext, depth);
	}
}/*}}}*/

static int unify_num(int tags[][2],int cnt)/*{{{*/
{
	/* �±׿��� ���� �±׹�ȣ�� �ִ����� �˻� */

	int	i,j;
	if(cnt >= MAX_TAG_NUM)
	{
		fprintf(stderr, "[mksti]\t[3]������ ������ �ִ�\n");
	}

	for(i = 0; i < cnt-1;) 
	{
		if((tags[i][0] == tags[i+1][0]) && (tags[i][1] == tags[i+1][1])) 
		{
			for(j = i + 1; j < cnt-1; j++) 
			{
				tags[j][0] = tags[j+1][0];
				tags[j][1] = tags[j+1][1];
			}
			cnt--;
			continue;
		}
		i++;
	} 
	return(cnt);
}/*}}}*/

static int read_zoo_word(FILE *fp,char *word,int *lnum,int *rnum)/*{{{*/
{
	//if(fscanf(fp,"%s %d %d", word,lnum,rnum)!=3)
	if(fscanf(fp,"%s\t%d\t%d", word,lnum,rnum)!=3)
	{
			return(0);
	}
	return(1);
}/*}}}*/

static int check_tagtype(int tags[MAX_TAG_NUM][2],int size)/*{{{*/
{
	int	i,j,find;

	for(i = 1; i < TAGTYPE; i++) 
	{
		find = 1;
		if(size == TAGS_SIZE[i])
		{
			for(j = 0; j < size; j++) 
			{
				if((tags[j][0] != L_TAGS_LIST[i][j]) || (tags[j][1] != R_TAGS_LIST[i][j]))
				{ 
					find = 0;
					break; 

				}
			}

			if(find == 1)		return(i);
		}
	}

	TAGS_SIZE[TAGTYPE] = size;

	for(i = 0; i < size; i++) 
	{
		L_TAGS_LIST[TAGTYPE][i] = tags[i][0];
		R_TAGS_LIST[TAGTYPE][i] = tags[i][1];
	}
	return(TAGTYPE++);
}/*}}}*/
