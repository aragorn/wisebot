/****************************************************************
 *			���ξ� ������� ���̺귯��  �κ�					*
 *                                                              *
 *                       Programmed by Cho, Young Hwan          *
 *                       Modify by Kim, Eung, Gyun				*
 *                       email : jchern@daumcorp.com			*
 *                       at : 3/20 2005                         *
 ****************************************************************/
#include "miscellaneous.h"
#include "aboutIndexing.h"
#include "errorlog.h"

#define result_info_size		(sizeof(RESULT_INFO))

void	HANL_LeftAppend(FINAL_INFO * final_info, int pidx, int lidx)
{
#ifdef  DEBUG1
	    printf("HANL_LeftAppend()\n");
#endif

	if (1 <= pidx && pidx < MAX_STACK_SIZE) 
	{
		if(Check_1SYALL())//����Ʈ ����������?(�繫�ڵ�ȭ)
		{
			final_info->result_info[pidx].end  = final_info->result_info[lidx].end;
			final_info->result_info[pidx].Rtag = final_info->result_info[lidx].Rtag;
			final_info->result_info[pidx].Raction = 0;
			HANL_InitializeFinal_Info(final_info, lidx);
			final_info->numberoftoken--;
			memcpy(&final_info->result_info[lidx],&final_info->result_info[lidx+1],
					result_info_size*(final_info->numberoftoken - lidx));
		}
	}
}

void	HANL_LeftAppendAttach(FINAL_INFO * final_info, int pidx, int lidx)
{
#ifdef  DEBUG1
	    printf("HANL_LeftAppendAttach()\n");
#endif
	if (1 <= pidx && pidx < MAX_STACK_SIZE) 
	{
		if(Check_1SYALL())
		{
			final_info->result_info[lidx].start  = final_info->result_info[pidx].start;

			if(final_info->result_info[pidx].Ltag == L_HANUM && final_info->result_info[lidx].Ltag == L_NBU)
			{
				final_info->result_info[lidx].Ltag = L_NCN;
				final_info->result_info[lidx].Rtag = R_NCN_N;
				strcpy(final_info->result_info[lidx].tag,"ncn");
			}
			else
			{
				if(final_info->result_info[pidx].Ltag == L_XSP)
				{
					final_info->result_info[lidx].Ltag = L_NCP;
					strcpy(final_info->result_info[lidx].tag ,"ncp");
				}
				else
				{
					final_info->result_info[lidx].Ltag = final_info->result_info[pidx].Ltag;
					strcpy(final_info->result_info[lidx].tag ,final_info->result_info[pidx].tag);
				}
			}

			final_info->result_info[pidx].expand = -1;
			final_info->result_info[lidx].Raction = 0;

		}
		else
		{
			final_info->result_info[lidx].start  = final_info->result_info[pidx].start;

			if(final_info->result_info[pidx].Ltag == L_HANUM && final_info->result_info[lidx].Ltag == L_NBU)
			{
				final_info->result_info[lidx].Ltag = L_NCN;
				final_info->result_info[lidx].Rtag = R_NCN_N;
				strcpy(final_info->result_info[lidx].tag,"ncn");

			}
			else
			{
				final_info->result_info[lidx].Ltag = final_info->result_info[pidx].Ltag;
				final_info->result_info[lidx].Rtag = final_info->result_info[pidx].Rtag;
				if(final_info->result_info[pidx].tag[0] != '\0')
					strcpy(final_info->result_info[lidx].tag,final_info->result_info[pidx].tag);
			}

			final_info->result_info[pidx].expand = -1;
			final_info->result_info[lidx].Raction = 0;

		}
	}
}

void	HANL_RightAppend(FINAL_INFO * final_info, int aidx, int ridx)
{

	int		length;
#ifdef  DEBUG1
	printf("HANL_RightAppend()\n");
#endif
	if(0 < aidx && ridx < MAX_STACK_SIZE && aidx > ridx)
	{
		final_info->result_info[ridx].end  = final_info->result_info[aidx].end;
		final_info->result_info[ridx].Ltag   = final_info->result_info[aidx].Ltag;
		length = final_info->numberoftoken-1-aidx;
		if(length > 0)
		{
			memmove(&final_info->result_info[aidx],&final_info->result_info[aidx+1],result_info_size*length);
			HANL_InitializeFinal_Info(final_info,aidx+length);
		}
		final_info->numberoftoken--;
	}
}


void	HANL_RightAttachCompound(FINAL_INFO * final_info, int aidx, int ridx)
{

#ifdef  DEBUG1
	printf("HANL_RightAttachCompound()\n");
#endif
	if(0 < aidx && ridx < MAX_STACK_SIZE && aidx > ridx)
	{
		if(final_info->result_info[ridx].start != final_info->result_info[aidx].start)
		{
			final_info->result_info[ridx].expand = -1;
			final_info->result_info[aidx].expand = 0;
			final_info->result_info[ridx].end   = final_info->result_info[aidx].end;
			final_info->result_info[ridx].Rtag  = final_info->result_info[aidx].Rtag;
			if(final_info->result_info[aidx].tag[0] != '\0')
				strcpy(final_info->result_info[ridx].tag,final_info->result_info[aidx].tag);
		}
	}
}


int	HANL_Check_PX_Verb(FINAL_INFO * final_info, int ridx)
{
	char	*token1;
	char	*token2;

#ifdef  DEBUG1
	printf("HANL_Check_PX_Verb()\n");
#endif
	token1 = strstr(final_info->result_info[ridx].tag,"pv");
	token2 = strstr(final_info->result_info[ridx].tag,"pa");
	if(token1 == NULL && token2 == NULL)	return (NO);


	token1 = strstr(final_info->result_info[ridx + 1].tag,"e");
	token2 = strstr(final_info->result_info[ridx + 1].tag,"e");
	if(token1 == NULL && token2 == NULL)	return (NO);

	token1 = strstr(final_info->result_info[ridx + 2].tag,"pv");
	token2 = strstr(final_info->result_info[ridx + 2].tag,"pa");
	if(token1 == NULL && token2 == NULL)	return (NO);

	token1 = strstr(final_info->result_info[ridx + 3].tag,"e");
	token2 = strstr(final_info->result_info[ridx + 3].tag,"e");
	if(token1 == NULL && token2 == NULL)	return (NO);
	return (YES);
}

int	HANL_DoHadaVerbProcessing(FINAL_INFO * final_info, unsigned char   *zooword, int *i, int ret)
{
	int	ltag = -1;
	int	rtag = -1;
	int	expand = 0;
	int	opt_root = 0;

	char	*pDef;
	char	*pWord;
	unsigned char   idxword[MAX_LINE] = {0,};
	unsigned char   revised_word[MAX_LINE] = {0,};//�����ϴ�

	FINAL_INFO		final_info_backup;

#ifdef  DEBUG1
	    printf("HANL_DoHadaVerbProcessing()\n");
#endif


	if(ret == NO)	return NO;//'�ھ����� '�ϴ�' �Ǵ� '�Ǵ�'�� �ƴѰ��

	
	opt_root  = Check_ROOT_VERB();

	if(HANL_make_morpheme(final_info->result_info[*i].start, (final_info->result_info[*i].end), zooword, idxword))
	{
		if(opt_root)
		{
			memcpy(&final_info_backup.result_info[1],&final_info->result_info[(*i)+1],result_info_size*(final_info->numberoftoken-(*i)-1));
		
			pWord = revised_word;
			if(HANL_IsNoun_L(final_info->result_info[*i].Ltag, 2) == (YES) && HANL_IsNoun_L(final_info->result_info[*i + 1].Ltag, 2) == (NO))
			{
				if(ret == 1)		pDef = DEF_HADA;
				if(ret == 2)		pDef = DEF_DOIDA;
			
				ltag = L_PV;
				rtag = R_PV_RG;
				expand = -1;
				sprintf(revised_word,"%s%s",idxword,pDef);

				strcpy(final_info->result_info[(*i)+1].word,pWord);
				strcpy(final_info->result_info[(*i)+1].tag,L_MTag_Set[L_PV]);
				final_info->result_info[(*i)+1].where = WHERE_SUCCESS;
				final_info->result_info[(*i)+1].start = -1;
				final_info->result_info[(*i)+1].end = -1;
				final_info->result_info[(*i)+1].Ltag = ltag;
				final_info->result_info[(*i)+1].Rtag = rtag;
				final_info->result_info[(*i)+1].expand = expand;

				memcpy(&(final_info->result_info[(*i)+2]),&(final_info_backup.result_info[1]),
						result_info_size*(final_info->numberoftoken-(*i)-1));
				strcpy(final_info->result_info[*i].word,idxword);
				(*i)++;
				final_info->numberoftoken++;
			}
		}
		else
		{
			strcpy(final_info->result_info[*i].word,idxword);
		}
	}
	return (YES);
}


int	HANL_DoNotHadaVerbProcessing(FINAL_INFO * final_info, unsigned char   *zooword, int *i)
{
	unsigned char	bp;
	unsigned char   idxword[MAX_LINE] = {0,};

#ifdef  DEBUG1
	printf("HANL_DoNotHadaVerbProcessing()\n");
#endif
	if(*i < 0)	
	{
		error("Can't make morpheme");
		return NO;
	}
	if(final_info->result_info[*i].start  == 0 && final_info->result_info[*i].end == 0 && final_info->result_info[*i].tag[0] == '\0')
	{
		return -2;
	}
	if(final_info->result_info[*i].start < 0)
	{
		error("start is small than zero");
		return -3;
	}
	if(final_info->result_info[*i].end < 0)
	{
		error("end is small than zero");
		return -4;
	}

	if(final_info->result_info[*i].end < final_info->result_info[*i].start)	
	{
		error("start is small than end");
		return -5;
	}
	else
	{
		if((int)zooword[final_info->result_info[*i].start] == 214)	//if HM('V')
		{
			zooword[final_info->result_info[*i].start-1] = 229;		//if HM('e')
			(final_info->result_info[*i].start)--;
		}

		bp = zooword[final_info->result_info[*i].end+1];
		zooword[final_info->result_info[*i].end+1] = '\0';
		if(*i < MAX_STACK_SIZE && HANL_make_morpheme(final_info->result_info[*i].start,final_info->result_info[*i].end,zooword,idxword))
		{
			zooword[final_info->result_info[*i].end+1] = bp;
			if(*i > 1)
			{
				if((final_info->result_info[(*i)-1].Raction == R_RESTORE) && Check_ROOT_VERB())
				{
					if(strncmp(idxword,DEF_DA,2) == 0)
					{
						HANL_InitializeFinal_Info(final_info, *i);
						final_info->numberoftoken --;
						return (YES);
					}
				}
			}
			strcpy(final_info->result_info[*i].word, idxword);
			return (YES);
		}
		else
		{
		zooword[final_info->result_info[*i].end+1] = bp;
#ifdef	DEBUG
			int		iret;
			sprintf(idxword,"i:%d:start:%d:end:%d:zooword:%s:iret:%d",*i,final_info->result_info[*i].start,final_info->result_info[*i].end,zooword,iret);
			error("%s",idxword);
#endif
			warn("invalid index");
			return -10;
		}
	}
	error("Can't make morpheme");
	return -100;
}

int	HANL_GetValidIndexDecrease(FINAL_INFO * final_info, int pidx, int lidx)
{

#ifdef  DEBUG1
	printf("HANL_GetValidIndexDecrease()\n");
#endif
	for(pidx = lidx - 1; pidx >= 1; pidx--)//check valid space
	{
		if(HANL_CheckValidity(final_info, pidx))	return pidx;
	}
	return -1;
}
int	HANL_GetValidIndexIncrease(FINAL_INFO * final_info, int aidx, int ridx)
{

#ifdef  DEBUG1
	printf("HANL_GetValidIndexIncrease()\n");
#endif
	for(aidx = ridx + 1; aidx < final_info->numberoftoken; aidx++)//check valid space
	{
		if(HANL_CheckValidity(final_info, aidx))	return aidx;
	}
	return -1;
}

int	HANL_LeftRefineFinal_info(FINAL_INFO * final_info, unsigned char * zoooword)
{
	int	lidx = 0;//���� index
	int	pidx = 0;//���� ��ġ�� index(����)

#ifdef  DEBUG1
	printf("HANL_LeftRefineFinal_info()\n");
#endif
	if(Check_LEFT_ATTACH())/* LEFT  TAG PROCESSING */
	{
		for(lidx = final_info->numberoftoken-1; lidx > 0; lidx--)
		{
			if(final_info->result_info[lidx].Laction ==  L_LEFT_APPEND)
			{
				pidx = HANL_GetValidIndexDecrease(final_info, pidx, lidx);
				if(pidx < 0)	break;
				HANL_LeftAppend(final_info, pidx, lidx);
			}
			else if(final_info->result_info[lidx].Laction == L_LEFT_APPEND_ATTACH)
			{
				pidx = HANL_GetValidIndexDecrease(final_info, pidx, lidx);
				if(pidx < 0)	break;
				HANL_LeftAppendAttach(final_info, pidx, lidx);	
			}
			else if(final_info->result_info[lidx].Laction == L_RESTORE)
			{
				final_info->result_info[lidx].Raction = R_RESTORE;
			}
		}
	}
	return (YES);
}
int	HANL_RightRefineFinal_info(FINAL_INFO	*final_info,unsigned char * zooword)
{
	int		ridx = 0;//���� index
	int		aidx = 0;//���� ��ġ�� index(����)

#ifdef  DEBUG1
	printf("HANL_RightRefineFinal_info()\n");
#endif
	if(Check_RIGHT_ATTACH() && final_info->numberoftoken > 1)// RIGHT TAG PROCESSING //
	{
		for(ridx = 1; ridx < final_info->numberoftoken-1; ridx++)
		{
			if(final_info->result_info[ridx].Raction != R_RESTORE)
			{
				if(final_info->result_info[ridx].Raction == R_RIGHT_APPEND)
				{
					aidx = HANL_GetValidIndexIncrease(final_info,aidx,ridx);
					if(aidx < 0 || final_info->result_info[aidx].Ltag == L_NCN)	break;
					HANL_RightAppend(final_info, aidx, ridx);
					return (YES);
				}
				else if(final_info->result_info[ridx].Raction == R_ATTACH_COMPOUND)
				{
					aidx = HANL_GetValidIndexIncrease(final_info,aidx,ridx);
					if(aidx < 0 || final_info->result_info[aidx].Ltag == L_NCN)	break;
					HANL_RightAttachCompound(final_info,aidx,ridx);
					return (YES);
				}
			}
		}
	}
	return (YES);

}

int	HANL_MakeInputVerb(FINAL_INFO	*final_info,FINAL_INFO	* final_info_result, char	*input_word,int	*ridx,int	*fidx)
{

	if(final_info->result_info[(*ridx)+1].start == 0)//�Է¾����� �����ϱ� ����  -> "���"�� ��� ridx�� '��' ridx+1�� '��'
	{
		memcpy(&final_info_result->result_info[(*fidx)],&final_info->result_info[(*fidx)],result_info_size);
		strcpy(final_info_result->result_info[(*fidx)++].word,input_word);
	}
	else
	{
		if(0 < *fidx  && *fidx <= MAX_DICT_REF && *input_word != '\0')
		{
			memcpy(&(final_info_result->result_info[(*fidx)]),&final_info->result_info[*ridx],result_info_size);
			if(*input_word != '\0')		strcpy(final_info_result->result_info[(*fidx)].word,input_word);
			(*ridx)++;
			return (YES);
		}
		else
		{
			return (NO);
		}
	}

	return (YES);
}

int		HANL_MakeRestoredWord(FINAL_INFO	*final_info,FINAL_INFO	*final_info_result,char	*restored_word,int	*ridx,int	*fidx)
{
	int		Laction;
	int		Raction;
	int		resultidx = 0;
	RESULT_INFO	result_info[10];


	if(*restored_word != '\0')
	{
		if(HANL_Check_PX_Verb(final_info,*ridx))//���� -> ���� '���'�� �������(resturn YES), '����'�� �����(resturn NO)
		{
			memcpy(&final_info_result->result_info[*fidx],&final_info->result_info[*ridx], result_info_size);/* ���� ����   */
			strcpy(final_info_result->result_info[*fidx].word,restored_word);/* ���� ����   */
			final_info_result->result_info[(*fidx)++].Raction = 1;
			return 2;
		}
		else
		{
			Laction = final_info_result->result_info[*fidx].Laction;
			Raction = final_info_result->result_info[*fidx].Raction;

			memcpy(&result_info[resultidx],&final_info->result_info[*ridx],result_info_size);
			strcpy(result_info[resultidx].word,restored_word);
			result_info[resultidx].expand = 0;
			/*strcpy(result_info[resultidx].tag,final_info->result_info[(*ridx)-1].tag);//'�����ϴ�'�� '��' �� ���� ����'nc'�� ����
			if((*ridx) -1 > 0)
			{
				result_info[resultidx].Ltag = final_info->result_info[(*ridx)-1].Ltag;
				result_info[resultidx].Rtag = final_info->result_info[(*ridx)-1].Rtag;
			}*/
			result_info[resultidx].Laction = Laction;
			result_info[resultidx].Raction = Raction;
			memcpy(&final_info_result->result_info[(*fidx)++],&result_info[resultidx],result_info_size);
			return 2;
		}
	}
	return NO;
}


int	HANL_Restoration(FINAL_INFO * final_info, FINAL_INFO * final_info_result, unsigned char   *zooword,int ridx, int *fidx)
{
	int		size = 0;
	int		opt_root = 0;
	int		opt_input = 0;

	char	input_word[1024];
	char	restored_word[1024];

	unsigned char	follow;
	unsigned char   src[MAX_LINE];

	int	HANL_rcv_form();


#ifdef  DEBUG1/*{{{*/
	printf("HANL_Restoration()\n");
#endif
#ifdef	DEBUG
	printf("input_word(%s\n",input_word);
#endif/*}}}*/
	input_word[0] = restored_word[0] = '\0';

	size = (final_info->result_info[ridx].end - final_info->result_info[ridx].start + 1);

	if(size < 0)	return (NO);

	strncpy(src,&zooword[final_info->result_info[ridx].start],size);
	src[size] = '\0';
	follow = zooword[final_info->result_info[ridx].start + (size)];


#ifdef  DEBUG/*{{{*/
	printf("src[size]=%c\tfollow=%c\n",src[size] - 128,follow-128);
#endif/*}}}*/

	if(HANL_rcv_form(src,follow,restored_word,final_info->result_info[ridx].Rtag) == NO)	return NO;

	HANL_kimmo2ks(zooword,input_word);/*	�Է� ���� */

	
	if(strcmp(restored_word, input_word) == 0)		*restored_word = '\0';

#ifdef	DEBUG/*{{{*/
	HANL_kimmo2ks(src,input_word);/*	�Է� ���� */
	printf("input_word(%s\n",input_word);
#endif/*}}}*/

	opt_root = Check_ROOT_VERB();
	opt_input = Check_INPUT_WORD();

	if(opt_root == 1 && opt_input == 1)
	{
		if(HANL_MakeInputVerb(final_info,final_info_result,input_word, &ridx, fidx) == YES)/* Make Input Verb */
		{
			return HANL_MakeRestoredWord(final_info,final_info_result,restored_word,&ridx,fidx);/* Restore Root Verb */
		}
		else	return NO;
	}
	else if(opt_input == 1)		
		return HANL_MakeInputVerb(final_info,final_info_result,input_word, &ridx, fidx);/* Make Input Verb */
	else if(opt_root == 1)		
		return HANL_MakeRestoredWord(final_info,final_info_result,restored_word,&ridx,fidx);
		
	return HANL_MakeRestoredWord(final_info,final_info_result,restored_word,&ridx,fidx);
}

int HANL_ProcessRestoredVerb(FINAL_INFO * final_info, unsigned char   *zooword)
{
	int		i;
	int		fidx = 1;
	char	temp[1024];
	FINAL_INFO	final_info_result;
#ifdef  DEBUG1
	printf("HANL_ProcessRestoredVerb()\n");
#endif

	for(i = 1; i < final_info->numberoftoken; i++)		
	{
		if(final_info->result_info[i].Raction == R_RESTORE)	
		{
			if(HANL_Restoration(final_info, &final_info_result, zooword, i, &fidx) == NO)// restore irregular verb//
			{ 
				final_info->numberoftoken = 1;//jchern//
				return (NO);
			}
		}
		else
		{
			memcpy(&(final_info_result.result_info[i]),&(final_info->result_info[i]),result_info_size);
			fidx++;
		}
	}
	memcpy(&final_info->result_info[1], &final_info_result.result_info[1], result_info_size*(fidx - 1));
	final_info->numberoftoken = fidx;
	return (YES);
}

int HANL_RefineFinal_info(FINAL_INFO * final_info, unsigned char   *zooword, int *ret)
{
	int		iret;

#ifdef  DEBUGK
	printf("-> ���������� �ϰų�, �����Ǵ� �������� ���¼Ҹ� ���δ�HANL_RefineFinal_info()\n");
#endif
#ifdef  DEBUG1
	printf("HANL_RefineFinal_info()\n");
#endif

	if(final_info->numberoftoken < 0)	return (NO);

	HANL_LeftRefineFinal_info(final_info, zooword);//������

	//������� ����
	if(HANL_ProcessRestoredVerb(final_info, zooword) == NO)		return (NO);

	if(final_info->numberoftoken < 1)	return (NO);

	iret = HANL_RightRefineFinal_info(final_info, zooword);//������

	HANL_ProcessHadaVerbOrNot(final_info, zooword);//�ϴٵ����� ���� ����
	HANL_Process1Syall(final_info); //1������ ������ ���� ���� ó��

	return (SUCCESS);
}


int	HANL_ProcessHadaVerbOrNot(FINAL_INFO	*final_info, unsigned char * zooword)
{
	int		i;

#ifdef  DEBUGK
	printf("-> '�ϴ�'�� ������ �ִ� ���������� �˻��Ͽ� ���縦 ����HANL_ProcessHadaVerbOrNot()\n");
#endif
#ifdef  DEBUG1
	printf("HANL_ProcessHadaVerbOrNot()\n");
#endif
	for(i = 1; i < final_info->numberoftoken; i++)
	{
		/*�ϴٵǴ� ���� �ڿ� "��,��"�� �������� üũ (eg. ����'��'��)*/
		if(final_info->result_info[i].Ltag == L_NCP && final_info->result_info[i + 1].Ltag != L_NCN)
		{
			if(HANL_DoHadaVerbProcessing(final_info, zooword, &i, HANL_CheckHadaDoidaVerb(zooword, final_info->result_info[i].end)) == NO)
			{
				if(HANL_DoNotHadaVerbProcessing(final_info, zooword, &i) != YES)
					return NO;
			}
		}
		else if(*(final_info->result_info[i].word) == '\0')
		{
			if(HANL_DoNotHadaVerbProcessing(final_info, zooword, &i) != YES)	
				return NO;

		}
	}
	return (YES);
}

int	HANL_Process1Syall(FINAL_INFO * final_info) 
{

	int		TokenType;	
	char	input[1024];

#ifdef  DEBUGK
	printf("-> '��1'�� ���� ª�� ���¼ҵ��� ������ �õ�HANL_Process1Syall()\n");
#endif
#ifdef  DEBUG1
	printf("HANL_Process1Syall()\n");
#endif
	if((final_info->numberoftoken == 3 || final_info->numberoftoken == 4) && strlen(final_info->result_info[2].word) < 2 && Check_1SYALL())
	{
		if(final_info->result_info[1].Raction != R_ATTACH_COMPOUND)
		{
			strcpy(input,final_info->result_info[1].word);
			strcat(input,final_info->result_info[2].word);
			//HANL_CheckCharSet(&TokenType, input, output);

			if(HANL_IfMixOtherCharactorSet(TokenType) == YES)
			{
				strcpy(final_info->result_info[2].word, input);
			}
			if(final_info->numberoftoken == 4)
			{
				final_info->result_info[1].expand = 2;
				final_info->result_info[2].expand = 1;
			}
		}
	}
	return 1;
}

int	HANL_ProcessEng(FINAL_INFO * final_info)
{
	int	i = 0;
	int	k = 0;
	int	length = 0;
	int	total = final_info->numberoftoken;

#ifdef  DEBUGK
	if(total > 0)	        printf("-> ����� ������ �ϳ��� ó��HANL_ProcessEng()\n");
#endif
#ifdef  DEBUG1
	printf("HANL_ProcessEng()\n");
#endif
	if(final_info->numberoftoken >= 1)
	{
		total = final_info->numberoftoken;
		for(i = total-1; i > 1; i--)
		{
			if(final_info->result_info[i].Ltag == L_ENG || final_info->result_info[i].Ltag == L_ALPABET)
			{
				if(final_info->result_info[i-1].Ltag == L_ENG || final_info->result_info[i-1].Ltag == L_ALPABET)
				{
					final_info->result_info[i-1].end = final_info->result_info[i].end;
					length = (total - i - 1);

					if(length > 0)
					{
						for(k = (i); k <= (i+length) ; k++)
						{
							memcpy(&final_info->result_info[k],&final_info->result_info[k+1],result_info_size);
						}
						total--;
					}
					else
					{
						HANL_InitializeFinal_Info(final_info,i);
					}
					final_info->numberoftoken --;
				}
			}
		}
	}
	else	return (NO);
	return (YES);
}

int	HANL_ProcessHanNum(FINAL_INFO * final_info)
{
	int	i = 0;
	int	k = 0;
	int	total;
	int	length = 0;

#ifdef  DEBUGK
	if(total > 0)	        printf("-> ����� ������ �ϳ��� ó��HANL_ProcessHanNum()\n");
#endif
#ifdef  DEBUG1
	printf("HANL_ProcessHanNum()\n");
#endif
	if(final_info->numberoftoken >= 1)
	{
		total = final_info->numberoftoken;
		for(i = total-1; i > 1; i--)
		{
			if(final_info->result_info[i].Ltag == L_HANUM ||
					final_info->result_info[i].Ltag == L_NUM ||
					final_info->result_info[i].Ltag  == L_CONNUM)
			{
				if(final_info->result_info[i-1].Ltag == L_HANUM || 
						final_info->result_info[i-1].Ltag == L_NUM ||
						final_info->result_info[i-1].Ltag == L_CONNUM)
				{
					final_info->result_info[i-1].end = final_info->result_info[i].end;
					length = (total - i - 1);

					if(length > 0)
					{
						for(k = (i); k <= (i+length) ; k++)
						{
							memcpy(&final_info->result_info[k],&final_info->result_info[k+1],result_info_size);
						}
						total--;
					}
					else
					{
						HANL_InitializeFinal_Info(final_info,i);
					}
					final_info->numberoftoken --;
				}
			}
		}
	}
	else	return (NO);

	return (YES);
}

int	HANL_Process_Special_char(FINAL_INFO * final_info, char	*inputstring, int	TokenType, int *exist_special_char)
{
	int i = 0;
	int	processed = 0;

	char	*special_char[] = { "-","_","NULL"};

#ifdef  DEBUG1
	        printf("HANL_Process_Special_char()\n");
#endif

#ifdef	DEBUGK
	        printf("-> -,_�� ���� Special ĳ���͸� ó��HANL_Process_Special_char()����\n");
#endif
	for(;;)
	{
		if(strcmp(special_char[i],"NULL") == 0)	break;
		if(strcmp(special_char[i],inputstring) == 0)	
		{
			*exist_special_char = 1;
			HANL_NotAnalyze(final_info, inputstring, TokenType);
			processed = 1;
			break;
		}
		else			
		{
			i++;
		}
	}

	if(processed)	return (YES);
	else			return (NO);
}


#define	RangeCheck(s1,e1,s2,e2)	(	((s2-s1) >= 0 && (e1-e2) >= 0) || ((s1-s2) >= 0 && (e2-e1) >= 0)) ? (1):(0) 
int	HANL_CheckRange(int	start1, int	end1, int	start2, int	end2)
{
	int	end;
	int	start;

	
	/*	--------------------------
 		s1   s2           e2    e1 
		+--+--+--+--+--+--+--+--+-
		1  2  3  4  5  6  7  8  9  
		--------------------------*/
	start = start2 - start1;
	end = end1 - end2; 
	if(start >= 0 && end >= 0)	return (YES);

	
	/*	---------------------------
 		s2   s1           e1    e2 
		+--+--+--+--+--+--+--+--+--
		1  2  3  4  5  6  7  8  9  
		---------------------------*/
	start = start1 - start2;
	end = end2 - end1; 
	if(start >= 0 && end >= 0)	return (YES);

	return (NO);
}

int	HANL_CheckLRActionWord(int	expand)
{
	if(expand != 0)	return (NO);
	else			return (YES);

}

int	HANL_IsCompoundNound_R(FINAL_INFO	*final_info, int * iRet)
{
	int	i;

	for(i = 1; i < final_info->numberoftoken - 1; i++)
	{
		if(HANL_IsNoun_R(final_info->result_info[i].Rtag) == YES)
		{
			if((HANL_IsNoun_R(final_info->result_info[i+1].Rtag) == YES))
			{
				if(!RangeCheck(final_info->result_info[i].start,	final_info->result_info[i].end,	
							final_info->result_info[i+1].start,		final_info->result_info[i+1].end))
				{
					*iRet = i;
					return (YES);
				}
				else
				{
					i++;
				}
			}
			else
			{
				i++;
			}
		}
	}
	return (NO);
}

int	HANL_IsCompoundNound_L(FINAL_INFO	*final_info)
{
	int	i;

	for(i = 1; i < final_info->numberoftoken; i++)
	{
		if(HANL_IsNoun_L(final_info->result_info[i].Ltag,2) == YES)
		{
			if(HANL_IsNoun_L(final_info->result_info[i+1].Ltag,2) == YES)		return (YES);
			else															i++;
		}
	}
	return (NO);
}

int	HANL_AddInputCompoundNoun(FINAL_INFO * final_info, int iret)
{
	int		i;
	int		backupidx = 0;
	int		iCountNoun = 0;
	int		iStartCnoun = 0;
	int		iFirstMatch = 0;
	FINAL_INFO	final_info_backup;

	for(i = iret; i < final_info->numberoftoken; i++)
	{
		if(HANL_IsNoun_R(final_info->result_info[i].Rtag) == YES)
		{
			if(iFirstMatch == 0)	//The Noun is searched firstly	
			{
				iStartCnoun = i;
				iFirstMatch = 1;
				if(final_info->numberoftoken > i + 2)	final_info->result_info[i].expand = i + 2;
			}
			iCountNoun++;
		}
		else
		{
			if(iCountNoun != 0)	break;
		}
	}

	if(iCountNoun > 1) 
	{
		final_info_backup.result_info[iStartCnoun].expand = iStartCnoun+1;
		if(iStartCnoun == 1)
		{
			memcpy(&final_info_backup.result_info[2],&final_info->result_info[iStartCnoun],result_info_size*(final_info->numberoftoken-1));
			backupidx = 1;
		}
		else
		{
			memcpy(&final_info_backup.result_info[1],&final_info->result_info[1],result_info_size*(iStartCnoun-1));
			backupidx = iStartCnoun;
		}

		for(i = iStartCnoun; i < (iCountNoun+iStartCnoun); i++)
		{
			if(i == iStartCnoun)	strcpy(final_info_backup.result_info[backupidx].word,final_info->result_info[i].word);
			else					strcat(final_info_backup.result_info[backupidx].word,final_info->result_info[i].word);
		}
		final_info_backup.result_info[backupidx].expand = iCountNoun;
		
		strcpy(final_info_backup.result_info[backupidx].tag,final_info->result_info[iStartCnoun+iCountNoun-1].tag);
		final_info_backup.result_info[backupidx].Ltag = final_info->result_info[iStartCnoun+iCountNoun-1].Ltag;
		final_info_backup.result_info[backupidx].Rtag = final_info->result_info[iStartCnoun+iCountNoun-1].Rtag;

		final_info_backup.numberoftoken = final_info->numberoftoken + 1;
		if(iStartCnoun != 1)
		{
			memcpy(&final_info_backup.result_info[backupidx+1],&final_info->result_info[iStartCnoun],
					result_info_size*final_info->numberoftoken-iStartCnoun);
		}
		memcpy(&final_info->result_info[1],&final_info_backup.result_info[1],result_info_size*(final_info_backup.numberoftoken-1));
		final_info->numberoftoken = final_info->numberoftoken + 1;
	}
	return (YES);
}

int	HANL_CheckHadaDoidaVerb(unsigned char * src,int to)//�ϴٵǰ� ���� ���� "��,��"�� �������� üũ (eg. ����'��'��)
{
	int		size;
	char	*HADA[] = 
	{
		"��",//�� 
		"�",//�� 
		"��",//��
		"��"//��   
	};
#ifdef  DEBUG1
	        printf("HANL_CheckHadaDoidaVerb()\n");
#endif
	size = strlen(src);
	if(0 <= to && to < MAX_LINE)
	{
		if(size < to)	return (NO);
		to++;

		/* �ϴ� */
		if((strncmp(&src[to],HADA[0], 2)) == 0)		return 	1;
		if((strncmp(&src[to],HADA[1], 2)) == 0)		return 	1;

		/* �Ǵ� */
		if((strncmp(&src[to],HADA[2], 2)) == 0)		return 	2;
		if((strncmp(&src[to],HADA[3], 2)) == 0)		return 	2;
	}
	else	return (NO);

	return (NO);
}

int	HANL_CopulaPostProcessing(FINAL_INFO *final_info)
{
	int	i;
	int	size;

#ifdef  DEBUGK
	printf("-> '�浿��'���� �˻��Ͽ� ���¼Ұ��� ������ �õ�HANL_CopulaPostProcessing()\n");
#endif
#ifdef  DEBUG1
	printf("HANL_CopulaPostProcessing()\n");
#endif
	if(final_info->numberoftoken > 1)
	{
		for(i = 1; i < final_info->numberoftoken; i++)
		{
			if(final_info->result_info[i].Ltag == L_NQ_PER2)
			{
				if(final_info->result_info[i+1].Ltag == L_NC_ONE_IDX)
				{
					final_info->result_info[i].end = final_info->result_info[i+1].end;
					size = final_info->numberoftoken - (i+1) - 1;
					if(size > 0)
					{
						memcpy(&final_info->result_info[i+1], &final_info->result_info[i+2],result_info_size*size);
						HANL_InitializeFinal_Info(final_info,final_info->numberoftoken-1);
						final_info->numberoftoken--;
					}
					return (YES);
				}
			}
		}
	}
	return (NO);
}

int	HANL_PositionProcessing(FINAL_INFO *final_info)
{
	int	i;
	int	size;

#ifdef  DEBUGK
	printf("-> '�λ���'���� �˻��Ͽ� ���¼Ұ��� ������ �õ�HANL_PositionProcessing()\n");
#endif
#ifdef  DEBUG1
	printf("HANL_PositionProcessing()\n");
#endif
	if(final_info->numberoftoken > 1)
	{
		for(i = 1; i < final_info->numberoftoken; i++)
		{
			if(final_info->result_info[i].Ltag == L_NQ_PER1)
			{
				if(final_info->result_info[i+1].Ltag == L_XSN_NQ_WRK_IDX)
				{
					final_info->result_info[i].end = final_info->result_info[i+1].end;
					size = final_info->numberoftoken - (i+1) - 1;
					if(size > 0)
					{
						memcpy(&final_info->result_info[i+1], &final_info->result_info[i+2],result_info_size*size);
						HANL_InitializeFinal_Info(final_info,final_info->numberoftoken-1);
						final_info->numberoftoken--;
					}
					return (YES);
				}
			}
		}
	}
	return (NO);
}


int	HANL_PostIndexing(postindex * idx)
{
	if(idx->opt())	idx->post(idx->final_info);
	return 1;
}


int	HANL_AboutIndexing(FINAL_INFO * final_info, unsigned char * zooword,int *ret)
{
	postindex pidx;
	pidx.final_info = final_info;

	pidx.opt = Check_FIRST_NAME;
	pidx.post = HANL_CopulaPostProcessing;//�浿�̴� => �浿��+�� | �浿+��+��
	HANL_PostIndexing(&pidx);
	
	pidx.opt = Check_POSITION;
	pidx.post = HANL_PositionProcessing;//�����=> ����� | ��+����
	HANL_PostIndexing(&pidx);
	
	pidx.opt = Check_HANNUM;
	pidx.post = HANL_ProcessHanNum;;//1��9õ => 1�ﱸõ | 1+��+��+õ
	HANL_PostIndexing(&pidx);	

	pidx.opt = Check_ENGLISH;
	pidx.post = HANL_ProcessEng;;//p d a �� => pda��
	HANL_PostIndexing(&pidx);	
	return HANL_RefineFinal_info(final_info,zooword, ret);
}


