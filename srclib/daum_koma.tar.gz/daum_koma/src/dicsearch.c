/**************************************************************
 *
 * @ ������� �˻��� ���� BTREE ����
 * ��Ŭ�� ����Ÿ���̽� �̿�
 * 
 **************************************************************/
#include "dicsearch.h"

DB* openDBFile (const char* dbFile)
{
	DB 	*db;

	db = dbopen (dbFile, O_CREAT | O_RDWR, 0644, DB_BTREE, NULL);
	if (db == NULL)
	{
		fprintf (stderr, "DB OPEN ERROR : %s\n", dbFile);
		return NULL;
	}

	return db;
}

void closeDBFile (DB* db)
{
	db->close (db);
}

char* getSearchedItem (DB* db, char* item)
{
	DBT		key;
	DBT		content;
	int 	ret;

	key.data = item;
	key.size = strlen (item) + 1;

	ret = db->get (db, &key, &content, 0);
	if (ret == 0)	// �����ϸ�..
		return content.data;
	else
		return NULL;
}

int createDBFile (const char* dbFile, const char* inFile)
{
	DB		*db;
	DBT		key;
	DBT		content;
	int		ret = 0;
	int		size = 0;
	int 	count = 0;
	FILE	*fp;

	char 	*token;
	char	value[DB_RECORD_MAX];
	char	keyword[DB_RECORD_MAX];

	db = dbopen (dbFile, O_CREAT | O_RDWR, 0644, DB_BTREE, NULL);
	if (db == NULL)
	{
		fprintf (stderr, "DB OPEN ERROR : %s\n", dbFile);
		return 1;
	}

	fp = fopen (inFile, "r");
	if (fp == NULL)
	{
		fprintf (stderr, "File OPEN ERROR : %s\n", inFile);
		return 1;
	}

	while (!feof(fp))
	{
		fscanf (fp, "%s %s", value, keyword);
		count++;

		key.data = value;
		key.size = strlen(value) + 1;

		ret = db->get (db, &key, &content, 0);

		if (ret == 0)
			printf ("Already exit... : %s at line number %d\n", value, count);
		else if (ret > 0)
		{
			content.data = keyword;
			content.size = strlen(keyword) + 1;

			db->put (db, &key, &content, 0);
		}
		else
		{
			fprintf (stderr, "DB Handling ERROR...\n");
			return 1;
		}
	}
	db->close(db);
	fclose(fp);
	
	return 0;
}
		
