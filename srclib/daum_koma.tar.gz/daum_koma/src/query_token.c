#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "query_token.h"

/* ======================================================================
 * ���� �ڵ� Ÿ�� ����
 * ====================================================================== */

#define	T_EN	1  		/* English		*/
#define	T_DG	2  		/* Digit		*/
#define	T_SC	3  		/* Special Character	*/
#define	T_CK	4  		/* Control key		*/
#define	T_BL	5  		/* Blank		*/
#define	T_KO	6  		/* Korean Code		*/
#define	T_HJ	7  		/* Hanja  Code		*/
#define	T_JH	8  		/* Japanse Code ����ī��*/
#define	T_JK	9  		/* Japanse Code ��Ÿ����*/
#define	T_U1	10  		/* Unknown(1 byte)	*/
#define	T_U2	11  		/* Unknown(2 byte)	*/
#define	T_BF	12  		/* Special Character alike blank (. , " etc) */
#define	T_NL	13		/* null*/

/* ======================================================================
 * �ѱ�/����/�Ͼ� 2����Ʈ �ڵ� ����
 *
 *    ------------------------------------------------------------------
 *     ����   ù��° ���ڹ���       �ι�° ���� ����    ���̺����� �̸�  
 *     �ѱ�   176(B0) - 200(C8)     161(A1) - 254(FE)        T_KO        
 *     ����   202(CA) - 253(FD)     161(A1) - 254(FE)        T_HJ        
 *     �Ͼ�   170(AA) - ����ī��    161(A1) - 243(F3)        T_JP        
 *            171(AB) - ����ī��    161(A1) - 246(F6)                   
 *    ------------------------------------------------------------------
 *
 * ====================================================================== */


/* ======================================================================
 * Hexadecimal - Character
 *
 *    ---------------------------------------------------------------
 *   | 00 NUL| 01 SOH| 02 STX| 03 ETX| 04 EOT| 05 ENQ| 06 ACK| 07 BEL|
 *   | 08 BS | 09 HT | 0A NL | 0B VT | 0C NP | 0D CR | 0E SO | 0F SI |
 *   | 10 DLE| 11 DC1| 12 DC2| 13 DC3| 14 DC4| 15 NAK| 16 SYN| 17 ETB|
 *   | 18 CAN| 19 EM | 1A SUB| 1B ESC| 1C FS | 1D GS | 1E RS | 1F US |
 *   | 20 SP | 21  ! | 22  " | 23  # | 24  $ | 25  % | 26  & | 27  ' |
 *   | 28  ( | 29  ) | 2A  * | 2B  + | 2C  , | 2D  - | 2E  . | 2F  / |
 *   | 30  0 | 31  1 | 32  2 | 33  3 | 34  4 | 35  5 | 36  6 | 37  7 |
 *   | 38  8 | 39  9 | 3A  : | 3B  ; | 3C  < | 3D  = | 3E  > | 3F  ? |
 *   | 40  @ | 41  A | 42  B | 43  C | 44  D | 45  E | 46  F | 47  G |
 *   | 48  H | 49  I | 4A  J | 4B  K | 4C  L | 4D  M | 4E  N | 4F  O |
 *   | 50  P | 51  Q | 52  R | 53  S | 54  T | 55  U | 56  V | 57  W |
 *   | 58  X | 59  Y | 5A  Z | 5B  [ | 5C  \ | 5D  ] | 5E  ^ | 5F  _ |
 *   | 60  ` | 61  a | 62  b | 63  c | 64  d | 65  e | 66  f | 67  g |
 *   | 68  h | 69  i | 6A  j | 6B  k | 6C  l | 6D  m | 6E  n | 6F  o |
 *   | 70  p | 71  q | 72  r | 73  s | 74  t | 75  u | 76  v | 77  w |
 *   | 78  x | 79  y | 7A  z | 7B  { | 7C  | | 7D  } | 7E  ~ | 7F DEL|
 *    ---------------------------------------------------------------
 *   | 80    | 81    | 82    | 83    | 84    | 85    | 86    | 87    |
 *   | 88    | 89    | 8A    | 8B    | 8C    | 8D    | 8E    | 8F    | 
 *   | 90    | 91    | 92    | 93    | 94    | 95    | 96    | 97    |
 *   | 98    | 99    | 9A    | 9B    | 9C    | 9D    | 9E    | 9F    |
 *   | A0    | A1    | A2    | A3    | A4 KO | A5    | A6    | A7    |
 *   | A8    | A9    | AA JH | AB JK | AC    | AD    | AE    | AF    |
 *   | B0 KO | B1 KO | B2 KO | B3 KO | B4 KO | B5 KO | B6 KO | B7 KO |
 *   | B8 KO | B9 KO | BA KO | BB KO | BC KO | BD KO | BE KO | BF KO |
 *   | C0 KO | C1 KO | C2 KO | C3 KO | C4 KO | C5 KO | C6 KO | C7 KO |
 *   | C8 KO | C9    | CA HJ | CB HJ | CC HJ | CD HJ | CE HJ | CF HJ |
 *   | D0 HJ | D1 HJ | D2 HJ | D3 HJ | D4 HJ | D5 HJ | D6 HJ | D7 HJ |
 *   | D8 HJ | D9 HJ | DA HJ | DB HJ | DC HJ | DD HJ | DE HJ | DF HJ |
 *   | E0 HJ | E1 HJ | E2 HJ | E3 HJ | E4 HJ | E5 HJ | E6 HJ | E7 HJ |
 *   | E8 HJ | E9 HJ | EA HJ | EB HJ | EC HJ | ED HJ | EE HJ | EF HJ |
 *   | F0 HJ | F1 HJ | F2 HJ | F3 HJ | F4 HJ | F5 HJ | F6 HJ | F7 HJ |
 *   | F8 HJ | F9 HJ | FA HJ | FB HJ | FC HJ | FD HJ | FE    | FF    |
 *    ---------------------------------------------------------------
 *
 * ====================================================================== */


/* ======================================================================
 * ASCII �ڵ� �� �ѱ�/����/�Ͼ� ù��° ���ڸ� ���� ���̺�
 *					modified by CHOYH
 *					 - blank, ��������, �ѱ��ڼ�
 * ====================================================================== */
static int cType1[] = {
       T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,
       T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,
       T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,
       T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,   T_BL,
       T_BL,   T_BF,   T_BF,   T_SC,   T_SC,   T_SC,   T_SC,   T_BF,
       T_SC,   T_SC,   T_SC,   T_SC,   T_BF,   T_SC,   T_BF,   T_SC,
       T_DG,   T_DG,   T_DG,   T_DG,   T_DG,   T_DG,   T_DG,   T_DG,
       T_DG,   T_DG,   T_SC,   T_SC,   T_SC,   T_SC,   T_SC,   T_SC,
       T_SC,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,
       T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,
       T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,
       T_EN,   T_EN,   T_EN,   T_SC,   T_SC,   T_SC,   T_SC,   T_SC,
       T_SC,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,
       T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,
       T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,   T_EN,
       T_EN,   T_EN,   T_EN,   T_SC,   T_SC,   T_SC,   T_SC,   T_CK,

       T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,
       T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,
       T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,
       T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,   T_U1,
       T_U1,   T_U2,   T_U2,   T_U2,   T_KO,   T_U2,   T_U2,   T_U2,
       T_U2,   T_U2,   T_JH,   T_JK,   T_U2,   T_U1,   T_U1,   T_U1,
       T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,
       T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,
       T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,   T_KO,
       T_KO,   T_U1,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,
       T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_HJ,   T_U1,   T_U1 
};

void HANL_PrintTokenType(int    TokenType)
{
	switch(TokenType)
	{
		case 0 :            printf("TOKEN_NULL\n");         break;
		case 1 :            printf("TOKEN_KOREAN\n");       break;
		case 2 :            printf("TOKEN_KOR_HANJA\n");    break;
		case 3 :            printf("TOKEN_KOR_JAPAN_H\n");  break;
		case 4 :            printf("TOKEN_KOR_JAPAN_K\n");  break;
		case 5 :            printf("TOKEN_ENGLISH\n");  break;
		case 6 :            printf("TOKEN_ENGLISH2\n"); break;
		case 7 :            printf("TOKEN_DIGIT\n");    break;
		case 8 :            printf("TOKEN_DIGIT2\n");   break;
		case 9 :            printf("TOKEN_MIX_KOR_DGT\n");  break;
		case 10 :           printf("TOKEN_MIX_KOR_ENG\n");  break;
		case 11 :           printf("TOKEN_MIX_ENG_DGT\n");  break;
		case 12 :           printf("TOKEN_MIX_ENG_KOR\n");  break;
		case 13 :           printf("TOKEN_MIX_DGT_KOR\n");  break;
		case 14 :           printf("TOKEN_MIX_DGT_ENG\n");  break;
		case 15 :           printf("TOKEN_SPECIAL\n");  break;
		case 16 :           printf("TOKEN_CONTROL\n");  break;
		case 17 :           printf("TOKEN_BLANK\n");    break;
		case 18 :           printf("TOKEN_UNKNOWN1\n"); break;
		case 19 :           printf("TOKEN_UNKNOWN2\n"); break;
		case 20 :           printf("TOKEN_MIX_UK_KOR\n");   break;
		case 21 :           printf("TOKEN_FUNC_BLANK\n");   break;
	}
}



/* =============================================================
 * Function:
 *	Get_Token_Korean
 *
 * Description:
 *	�ѱ� �ڵ�� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� �ѱ� �ڵ��� �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_KOREAN: ��� ���ڰ� �ѱ��� ��ū
 *	TOKEN_MIX_KOR_DGT: �ѱ۰� ���ڰ� ȥ�յ� ��ū
 * ============================================================= */
static int Get_Token_Korean(char **Text, char *Word)
{
    char *p = (*Text);
    char *q = Word;
    int  TokenType = TOKEN_KOREAN;
    int  CharType;
	int	dgcount = 0;
	int	encount = 0;
	int	num_st = 0;
	int	size = strlen(p);

	if(strncmp(p,"��",2) == 0)	num_st = 1;

	for(;;)
	{
		if (!*p) 			break; /* End of Text */
		if (q - Word >= MAXTOKENLEN - 1) 			break; /* buffer full */

		CharType = cType1[(unsigned char)(*p)];
		if((dgcount == 1 || encount == 1) && size < 4)
		{
			if(*p != '\0')
			{
				p--;
				q--;
				*q = '\0';
				TokenType = TOKEN_KOREAN;
			}
			goto done;
		}

		switch (CharType)
		{
			case T_KO:
				*q++ = *p++; /* ù��° ����Ʈ */
				//if((*p == '\0') || !(0x80 & *p)) // �d �� ��� �ι�° ����Ʈ�� 'd'�� ���⼭ ���������� ������ �߻�(Ȯ�� �ѱ��� ó������ ����)
				if((*p == '\0')) 
					goto done; /* �ι�° ����Ʈ ����. stop */
				*q++ = *p++; /* �ι�° ����Ʈ */
				break;

			case T_DG:
				if(dgcount == 1 && num_st == 0)
				{
					q--;
					p--;
					goto done;
				}
				*q++ = *p++;
				TokenType = TOKEN_MIX_KOR_DGT; /* �ѱ۰� ���ڰ� ȥ�յ� ��ū */
				dgcount++;
				break;
			case T_EN:
				*q++ = *p++;
				TokenType = TOKEN_MIX_KOR_ENG;/* �ѱ۰� ��� ȥ�յ� ��ū */
				encount++;
				if(size > 4)
				{
					q--;
					p--;
					goto done;
				}
				break;
			default:
				goto done;
		}
	}

done:
	*q = '\0';
	*Text = p;

	return(TokenType);
}

/* =============================================================
 * Function:
 *	Get_Token_Kor_Hanja
 *
 * Description:
 *	���� �ڵ�� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� ���� �ڵ��� �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_KOR_HANJA : ��� ���ڰ� ������ ��ū
 * ============================================================= */
static int Get_Token_Kor_Hanja(char **Text, char *Word)
{
	char *p = (*Text);
	char *q = Word;
	int  TokenType = TOKEN_KOR_HANJA;
	int  CharType;

	for(;;)
	{
		if(!*p) 
			break; /* End of Text */

		if(q - Word >= MAXTOKENLEN - 1)
			break; /* buffer full */

		CharType = cType1[(unsigned char)(*p)];

		switch (CharType)
		{
			case T_HJ:
				*q++ = *p++; /* ù��° ����Ʈ */

				if((*p == '\0') || !(0x80 & *p))
					goto done; /* �ι�° ����Ʈ ����. stop */

				*q++ = *p++; /* �ι�° ����Ʈ */
				break;

			default:
				goto done;
		}
	}

done:
	*q = '\0';
	*Text = p;

	return(TokenType);
}

/* =============================================================
 * Function:
 *	Get_Token_Kor_Japan_H
 *
 * Description:
 *	�Ϻ��� �ڵ�� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� �Ϻ��� �ڵ��� �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_KOR_JAPAN_H - ��� ���ڰ� �Ϻ��� �ڵ��� ��ū
 * ============================================================= */
static int Get_Token_Kor_Japan_H(char **Text, char *Word)
{
	char *p = (*Text);
	char *q = Word;
	int  TokenType = TOKEN_KOR_JAPAN_H;
	int  CharType;

	for(;;)
    {
	if(!*p) 
		break; /* End of Text */
	
	if(q - Word >= MAXTOKENLEN - 1)
		break; /* buffer full */

	CharType = cType1[(unsigned char)(*p)];

	switch (CharType)
	{
	    case T_JH:
		*q++ = *p++; /* ù��° ����Ʈ */

		if((*p == '\0') || !(0x80 & *p))
			goto done; /* �ι�° ����Ʈ ����. stop */

		*q++ = *p++; /* �ι�° ����Ʈ */
		break;

	    default:
		goto done;
	}
    }

done:
    *q = '\0';
    *Text = p;

    return(TokenType);
}

/* =============================================================
 * Function:
 *	Get_Token_Kor_Japan_K
 *
 * Description:
 *	�Ϻ��� �ڵ�� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� �Ϻ��� �ڵ��� �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_KOR_JAPAN_K - ��� ���ڰ� �Ϻ��� �ڵ��� ��ū
 * ============================================================= */
static int Get_Token_Kor_Japan_K(char **Text, char *Word)
{
    char *p = (*Text);
    char *q = Word;
    int  TokenType = TOKEN_KOR_JAPAN_K;
    int  CharType;

    for(;;)
	{
		if(!*p) 
			break; /* End of Text */

		if(q - Word >= MAXTOKENLEN - 1)
			break; /* buffer full */

		CharType = cType1[(unsigned char)(*p)];

		switch (CharType)
		{
			case T_JK:
				*q++ = *p++; /* ù��° ����Ʈ */

				if((*p == '\0') || !(0x80 & *p))
					goto done; /* �ι�° ����Ʈ ����. stop */

				*q++ = *p++; /* �ι�° ����Ʈ */
				break;

			default:
				goto done;
		}
	}

done:
	*q = '\0';
	*Text = p;

	return(TokenType);
}


/* =============================================================
 * Function:
 *	Get_Token_Token_English
 *
 * Description:
 *	���� ���ĺ����� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� ���� ���ĺ��� �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_ENGLISH - ��� ���ڰ� ������ ��ū
 *	TOKEN_ENGLISH2 - '.'�� �߰��� ���Ե� ���� ��ū
 *	TOKEN_MIX_ENG_DGT - ����� ���ڰ� ȥ�յ� ��ū
 * ============================================================= */
static int Get_Token_English(char **Text, char *Word)
{
	char	*p = (*Text);
	char	*q = Word;
	int	encount = 0;
	int	kocount = 0;
	int	dgcount = 0;
	int	CharType = 0;
	int	TokenType = TOKEN_ENGLISH;
	int	OldTokenType = 0;
	int	size = strlen(p);

	for(;;)
	{
		if (!*p)			break; /* End of Text */
		if (q - Word >= MAXTOKENLEN - 1) 	break; /* buffer full */

		CharType = cType1[(unsigned char)(*p)];

		if((kocount == 1 || dgcount == 1) && size < 4)
		{
			if(*p != '\0')
			{
				if(kocount)
				{
					p = p - 2;	
					q = q - 2;
				}
				else
				{
					p--;		
					q--;
				}
				*q = '\0';
				TokenType = OldTokenType;
			}
			goto done;
		}
		switch (CharType)
		{
			case T_EN:
				*q++ = *p++;
				encount++;
				break;

			case T_DG:
				if(*p == '=')//xy=23
				{
					*q++ = *p++;
					break;
				}
				if(size > 4)
				{
					*q++ = *p++;
					CharType = cType1[(unsigned char)(*p)];
					if(CharType ==  TOKEN_KOREAN || CharType == T_EN)
					{
						goto done;
					}
					else
					{
						q--;
						p--;
						goto done;
					}
				}
				*q++ = *p++;
				TokenType = TOKEN_MIX_ENG_DGT; /* ����� ���ڰ� ȥ�յ� ��ū */
				dgcount++;
				OldTokenType = TokenType;
				TokenType = TOKEN_MIX_ENG_DGT;
				break;

			case T_KO:
				if(size > 4 && encount != 1)	goto done;
				*q++ = *p++; /* ù��° ����Ʈ */
				if((*p == '\0') || !(0x80 & *p))
					goto done; /* �ι�° ����Ʈ ����. stop */
				*q++ = *p++; /* �ι�° ����Ʈ */
				kocount++;
				OldTokenType = TokenType;
				TokenType = TOKEN_MIX_ENG_KOR;
				break;

			case T_SC: /* '.'�� ��ū �߰��� ��Ÿ���� �͸��� ��� */
				if (*p == '&' || *p == '=' || *p == '-')//kt&g, xy=ab
				{
					*q++ = *p++;
					break;
				}
				if (*p != '.')
					goto done;

				if (*(p+1) == '\0')
					goto done;

				CharType = cType1[(unsigned char)(*(p+1))]; /* �̾����� ������ Ÿ������ */

				if ((CharType != T_EN) && (CharType != T_DG) && (CharType != TOKEN_KOREAN))
					goto done; /* ����� ���ڸ� ��� */

				*q++ = *p++;
				TokenType = TOKEN_ENGLISH2;
				break;

			default:
				goto done;
		}
	}

done:
	*q = '\0';
	*Text = p;

	return(TokenType);

}

/* =============================================================
 * Function:
 *	Get_Token_Token_Digit
 *
 * Description:
 *	���ڷ� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� ������ �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_MIX_ENG_DGT - ���ڿ� ��� ȥ�յ� ��ū
 *	TOKEN_MIX_KOR_DGT - ���ڿ� �ѱ��� ȥ�յ� ��ū
 * ============================================================= */
static int Get_Token_Digit(char **Text, char *Word)
{
	char	*p = (*Text);
	char	*q = Word;
	int		CharType;
	int		encount = 0;
	int		kocount = 0;
	int		TokenType = TOKEN_DIGIT;
	int		size = strlen(p);

	for(;;)
	{
		if (!*p) 
			break; /* End of Text */

		if (q - Word >= MAXTOKENLEN - 1 ) break; /* buffer full */

		CharType = cType1[(unsigned char)(*p)];

		if((encount == 1 || kocount == 1) && size < 4)
		{
			if(*p != '\0')
			{
				if(kocount)
				{
					p = p - 2;
					q = q - 2;
				}
				else
				{
					p--;
					q--;
				}
				*q = '\0';
			}
			goto done;

		}
		switch (CharType)
		{
			case T_DG:
				*q++ = *p++;
				break;

			case T_EN: /* ���ڿ� ��� ȥ�� */
				if(size > 4)
				{
					*q++ = *p++;
					CharType = cType1[(unsigned char)(*p)];
					if(CharType != TOKEN_KOREAN)
					{
						p--;
						q--;
					}					
					//���� �ѱ��� �ٽ� ���� 3D����
					goto done;
				}
				*q++ = *p++;
				TokenType = TOKEN_MIX_ENG_DGT;
				encount++;
				break;

			case T_KO: /* ���ڿ� �ѱ��� ȥ�� */
				if ((TokenType != TOKEN_DIGIT) &&(TokenType != TOKEN_DIGIT2) &&(TokenType != TOKEN_MIX_KOR_DGT))
					goto done;
				*q++ = *p++; /* ù��° ����Ʈ */
				if ((*p == '\0') || !(0x80 & *p))
					goto done; /* �ι�° ����Ʈ ����. stop */
				*q++ = *p++; /* �ι�° ����Ʈ */
				TokenType = TOKEN_MIX_KOR_DGT;
				kocount++;
				break;

			case T_SC: /* '.'�� ':'�� ���� ��ū �߰��� ��Ÿ���� ���� ��� */
			case T_BF:

				if ((TokenType != TOKEN_DIGIT) && (TokenType != TOKEN_DIGIT2) && (TokenType != TOKEN_MIX_KOR_DGT)) //������ TOKEN_MIX_KOR_DGT �� 1��8,000��
																													//���� comma�� ����ϱ� ����
					goto done;

				if ((*p != '.') && (*p != ':') && (*p != ','))  
					goto done;

				if (*(p+1) == '\0')
					goto done;

				CharType = cType1[(unsigned char)(*(p+1))]; /* �̾����� ������ Ÿ������ */

				if (CharType != T_DG)
					goto done; /* ���ڸ��� ��� */

				*q++ = *p++;
				TokenType = TOKEN_DIGIT2;
				break;

			default:
				goto done;
		}
	}

done:
	*q = '\0';
	*Text = p;

	return(TokenType);
}

/* =============================================================
 * Function:
 *	Get_Token_Token_Spcecial
 *
 * Description:
 *	, " ��� ���� special character�� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� special character�� �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_SPECIAL - ��� ���ڰ� special character
 * ============================================================= */
static int Get_Token_Special(char **Text, char *Word)
{
	char *p = (*Text);
	char *q = Word;
	int  TokenType = TOKEN_SPECIAL;
	int  CharType;

	for(;;)
	{
		if (!*p)
			break; /* End of Text */

		if (q - Word >= MAXTOKENLEN - 1)
			break; /* buffer full */

		CharType = cType1[(unsigned char)(*p)];

		switch (CharType)
		{
			case T_SC:
				*q++ = *p++;
				break;

			default:
				goto done;
		}
	}

done:
	*q = '\0';
	*Text = p;

    return(TokenType);
}

/* =============================================================
 * Function:
 *	Get_Token_Blank_Functuator
 *
 * Description:
 *	! . ' " ��� ���� special character�� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� special character�� �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_FUNC_BLANK - ��� ���ڰ� special character
 * ============================================================= */
static int Get_Token_Func_Blank(char **Text, char *Word)
{
    char *p = (*Text);
    char *q = Word;
    int  TokenType = TOKEN_FUNC_BLANK;
    int  CharType;

    for(;;)
    {
	if(!*p)
		break; /* End of Text */
	
	if(q - Word >= MAXTOKENLEN - 1)
		break; /* buffer full */

	CharType = cType1[(unsigned char)(*p)];

	switch (CharType)
	{
	    case T_BF:
		*q++ = *p++;
		break;

	    default:
		goto done;
	}
    }

done:
    *q = '\0';
    *Text = p;

    return(TokenType);
}

/* =============================================================
 * Function:
 *	Get_Token_Token_Control
 *
 * Description:
 *	���� ���ڷ� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� ���� ������ �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_CONTROL - ��� ���ڰ� ���� ������ ��ū
 * ============================================================= */
static int Get_Token_Control(char **Text, char *Word)
{
    char *p = (*Text);
    char *q = Word;
    int  TokenType = TOKEN_CONTROL;
    int  CharType;

    for(;;)
    {
	if(!*p)
		break; /* End of Text */
	
	if(q - Word >= MAXTOKENLEN - 1)
		break; /* buffer full */

	CharType = cType1[(unsigned char)(*p)];

	switch (CharType)
	{
	    case T_CK:
		*q++ = *p++;
		break;

	    default:
		goto done;
	}
    }

done:
    *q = '\0';
    *Text = p;

    return(TokenType);
}

/* =============================================================
 * Function:
 *	Get_Token_Token_Blank
 *
 * Description:
 *	���� ����(' ', '\t', '\n')�� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� ���� ������ �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_BLANK - ��� ���ڰ� ���� ������ ��ū
 * ============================================================= */
static int Get_Token_Blank(char **Text, char *Word)
{
    char *p = (*Text);
    char *q = Word;
    int  TokenType = TOKEN_BLANK;
    int  CharType;

	for(;;)
	{

		if(!*p) 
			break; /* End of Text */
		if(q - Word >= MAXTOKENLEN - 1)
			break; /* buffer full */

		CharType = cType1[(unsigned char)(*p)];

		switch (CharType)
		{
			case T_BL:
				*q++ = *p++;
				break;

			default:
				goto done;
		}
	}

done:
	*q = '\0';
	*Text = p;

	return(TokenType);

}

/* =============================================================
 * Function:
 *	Get_Token_Token_Unknown1
 *
 * Description:
 *	1-byte Unknown Chararacter�� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� 1-byte Unknown Character �ڵ��� �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_UNKNOWN1 - ��� ���ڰ� 1-byte Unknown Character�� ��ū
 * ============================================================= */
static int Get_Token_Unknown1(char **Text, char *Word)
{
	char *p = (*Text);
	char *q = Word;
	int  TokenType = TOKEN_UNKNOWN1;
	int  CharType;

	for(;;)
	{
		if(!*p)
			break; /* End of Text */

		if(q - Word >= MAXTOKENLEN - 1)
			break; /* buffer full */

		CharType = cType1[(unsigned char)(*p)];

		switch (CharType)
		{
			case T_U1:
				*q++ = *p++;
				break;

			default:
				goto done;
		}
	}

done:
	*q = '\0';
	*Text = p;

	return(TokenType);

}

/* =============================================================
 * Function:
 *	Get_Token_Token_Unknown2
 *
 * Description:
 *	2-byte Unknown Chararacter�� �����ϴ� ��ū �б�
 *	Text�� ù��° ����Ʈ�� 2-byte Unknown Character �ڵ��� �� ȣ��ȴ�.
 *
 * Returns:
 *	TOKEN_UNKNOWN2 - ��� ���ڰ� 2-byte Unknown Character�� ��ū
 * ============================================================= */
static int Get_Token_Unknown2(char **Text, char *Word)
{
	char *p = (*Text);
	char *q = Word;
	int  TokenType = TOKEN_UNKNOWN2;
	int  CharType;

	for(;;)
	{
		if(!*p)
			break; /* End of Text */

		if(q - Word >= MAXTOKENLEN - 1) 
			break; /* buffer full */

		CharType = cType1[(unsigned char)(*p)];

		switch (CharType)
		{
			case T_U2:
				*q++ = *p++; /* ù��° ����Ʈ */
				if((*p == '\0') || !(0x80 & *p))
					goto done; /* �ι�° ����Ʈ ����. stop */

				*q++ = *p++; /* �ι�° ����Ʈ */
				break;
			default:
				goto done;
		}
	}

done:
	*q = '\0';
	*Text = p;

	return(TokenType);

}

/* =============================================================
 * ��ū �б� �Լ� ���̺�
 * ============================================================= */
typedef int (*TOKPROC)(char **, char *);
static TOKPROC	TokProc[] = 
{
	NULL,
	Get_Token_English,
	Get_Token_Digit,
	Get_Token_Special,
	Get_Token_Control,
	Get_Token_Blank,
	Get_Token_Korean,
	Get_Token_Kor_Hanja,
	Get_Token_Kor_Japan_H,
	Get_Token_Kor_Japan_K,
	Get_Token_Unknown1,
	Get_Token_Unknown2,
	Get_Token_Func_Blank
};

/* =============================================================
 * Function:
 *	KSC5601_GetTextToken
 *
 * Description:
 *	Text�� ù��° ��ū �б�
 *
 * Returns:
 *	TOKEN_NULL
 *	TOKEN_KOREAN
 *	TOKEN_HANJA
 *	TOKEN_JAPAN
 *	TOKEN_ENGLISH
 *	TOKEN_ENGLISH2
 *	TOKEN_DIGIT
 *	TOKEN_DIGIT2
 *	TOKEN_MIX_ENG_DGT
 *	TOKEN_MIX_DGT
 *	TOKEN_SPECIAL
 *	TOKEN_CONTROL
 *	TOKEN_BLANK
 *	TOKEN_UNKNOWN1
 *	TOKEN_UNKNOWN2
 *  TOKEN_FUNC_BLANK   
 * ============================================================= */

int KSC5601_GetTextToken(char **Text, char *Word)
{
	int		CharType;
	int		TokenType;

	*Word = '\0';
	for(;;) 
	{
		if (**Text == '\0') 
			return(TOKEN_NULL); /* End of Text */

		CharType =  cType1[(unsigned char)**Text];

		if ((CharType >= T_EN) && (CharType <= T_BF)) /* ��ū �Լ� ���̺��� �����Ͽ� �ش� �Լ� ȣ�� */
		{

			TokenType = (TokProc[CharType])(Text, Word);
			return(TokenType);
		}
		else  /* invalid CharType! discard this character */
		{
			++*Text;
		}
	}
}

// XXX: duplicated
#if 0
void HANL_PrintTokenType(int	TokenType)
{
	switch(TokenType)
	{
		case 0 :			printf("TOKEN_NULL\n");			break;
		case 1 :			printf("TOKEN_KOREAN\n");		break;
		case 2 : 			printf("TOKEN_KOR_HANJA\n");	break;
		case 3 :			printf("TOKEN_KOR_JAPAN_H\n");	break;
		case 4 :			printf("TOKEN_KOR_JAPAN_K\n");	break;
		case 5 :			printf("TOKEN_ENGLISH\n");	break;
		case 6 :			printf("TOKEN_ENGLISH2\n");	break;
		case 7 :			printf("TOKEN_DIGIT\n");	break;
		case 8 :			printf("TOKEN_DIGIT2\n");	break;
		case 9 :			printf("TOKEN_MIX_KOR_DGT\n");	break;
		case 10 :			printf("TOKEN_MIX_KOR_ENG\n");	break;
		case 11 :			printf("TOKEN_MIX_ENG_DGT\n");	break;
		case 12 :			printf("TOKEN_MIX_ENG_KOR\n");	break;
		case 13 :			printf("TOKEN_MIX_DGTOKEN_KOREANR\n");	break;
		case 14 :			printf("TOKEN_MIX_DGT_ENG\n");	break;
		case 15 :			printf("TOKEN_SPECIAL\n");	break;
		case 16 :			printf("TOKEN_CONTROL\n");	break;
		case 17 :			printf("TOKEN_BLANK\n");	break;
		case 18 :			printf("TOKEN_UNKNOWN1\n");	break;
		case 19 :			printf("TOKEN_UNKNOWN2\n");	break;
		case 20 :			printf("TOKEN_MIX_UK_KOR\n");	break;
		case 21 :			printf("TOKEN_FUNC_BLANK\n");	break;
	}
}
#endif

int	main()
{
	int		TokenType = 0;
	char	buffer[1024];
	char	word[1024];
	char	*bp;
	printf("%s","input string : ");

	scanf("%s",buffer);
	bp = buffer;

	for(;;)
	{
		if ((TokenType = KSC5601_GetTextToken (&bp, word))  == TOKEN_NULL)	return 0;
		printf("%d--%s\n",TokenType,word);
		HANL_PrintTokenType(TokenType);
	}


}
