#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "moran_tagdef.h"

#define ERROR	0
#define SUCC	1
#define	FAIL	-1
#define MAX	200

int HANL_ks2kimmo(unsigned char *src,unsigned char *des);

int	main(int	argc, char * argv[])
{
	int		tags = 0;
	int		lnum;
	int		rnum;
	int		i=0;
	int		size = 0;
	int		ret = 0;
	int		count = 0;
	int		iSkipCount = 0;
	char	line[1024];
	char	word[100];
	char	ltag[100];
	char	rtag[100];
	char	temp[1024];
	char	kimmoword[100];
	FILE	*fp;

	fp = fopen(argv[1],"w");
	while(fgets(line,1024,stdin) != NULL)
	{
		if(line[0] == '#')
		{
			iSkipCount++;
			continue;
		}
		count++;

		size = strlen(line);
		if(line[size - 1] == '\n')	line[size - 1] = '\0';
	
		ret = sscanf(line,"%s %s %s",word, ltag,rtag);
	
		if(ret != 3) 
		{ 
			fprintf(stderr,">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
			fprintf(stderr,"*****	�Ķ������ ������ ���� ����(%d)\n",ret);
			fprintf(stderr,"*****	SRC     (%s)\n",argv[0]);
			fprintf(stderr,"*****	FILE    (%s)\n",argv[1]);
			fprintf(stderr,"*****	LINE    (%d)\n",count);
			fprintf(stderr,"*****	string  (%s)\n",line);
			fprintf(stderr,">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n\n");
			continue;
		}

		if(HANL_ks2kimmo(word,kimmoword) == ERROR)
		{
			fprintf(stderr,"*****	CODE ERROR AT %d LINE!!!	*****\n",count+iSkipCount);
			fprintf(stderr,"%d:[%s] -> [%s] ",count+iSkipCount,word,kimmoword); 
		}
	
		lnum = HANL_find_lnum(ltag);
		if(lnum == FAIL)
		{
			fprintf(stderr,"*****	%s <- LEFT  TAG ERROR : %s	*****\n",word,ltag);
			warn("*****	%s <- LEFT TAG ERROR : %s	*****\n",word,rtag);
			continue;
		}
	
		rnum = HANL_find_rnum(rtag);
		if(rnum == FAIL)
		{
			fprintf(stderr,"*****	%s <- RIGHT TAG ERROR : %s	*****\n",word,rtag);
			warn("*****	%s <- RIGHT TAG ERROR : %s	*****\n",word,rtag);
			continue;
		}


		printf("%s \t %d \t %d\n",kimmoword,lnum,rnum);
		HANL_kimmo2ks(kimmoword,temp);

		if(temp[0] == ' ')
		{
			fprintf(stderr,">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
			fprintf(stderr,"*****	ĳ���� ��ȯ�� ������ �ֽ��ϴ�(%s)\n",temp);
			fprintf(stderr,"*****	SRC     (%s)\n",argv[0]);
			fprintf(stderr,"*****	FILE    (%s)\n",argv[1]);
			fprintf(stderr,"*****	LINE    (%d)\n",count);
			fprintf(stderr,"*****	string  (%s)\n",line);
			fprintf(stderr,">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n\n");
		}
		else
		{
			fprintf(fp,"%s \t%d\t%d\n",temp,lnum,rnum);
		}
		
	}
#ifdef	DEBUG
	info("[%s]	TOTAL      COUNT : %d\n","ks2km4dic",count+iSkipCount);
	info("[%s]	SKIP       COUNT : %d\n","ks2km4dic",iSkipCount);
	info("[%s]	PROCESSING COUNT : %d\n","ks2km4dic",(count));
#endif
	fclose(fp);
}

int     HANL_find_lnum(char	*tag)
{
	int    i;

	for(i = 0; i < LEFT_TAG_CNT; i++)		if(!strcmp(tag,L_Tag_Set[i])) return(i);
	return FAIL;
}

int     HANL_find_rnum(char	*tag)
{
	int    i;

	for(i = 0; i < RIGHT_TAG_CNT; i++)	if(!strcmp(tag,R_Tag_Set[i])) return(i);
	return FAIL;
}

