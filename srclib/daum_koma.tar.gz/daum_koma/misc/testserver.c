#include "auto_config.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "apr_network_io.h"
#include "apr_errno.h"
#include "apr_general.h"
#include "apr_lib.h"

#include "dha.h"

#define RECVBUF_LEN			(1024 * 1024) /*1MB*/
#define HANL_RUNENV_DIR		"../RunEnv"

int main (int argc, char *argv[]) {
	apr_pool_t *p;

	apr_status_t rv;
	apr_sockaddr_t *to;
	apr_sockaddr_t *from;
	apr_socket_t *sock = NULL;
	apr_size_t len;
	void *dha;

	char recvbuf[RECVBUF_LEN];
	char result[RECVBUF_LEN];
	const char *addr;
	int port;

	if (argc != 3) {
		fprintf(stderr, "usage: %s addr port\n", argv[0]);
		exit(1);
	}
	addr = argv[1];
	port = atoi(argv[2]);

	apr_initialize();
	apr_pool_create(&p, NULL);


	dha = dha_initialize(HANL_RUNENV_DIR, HANL_RUNENV_DIR "/CONFIG.HANL");

	rv = apr_socket_create(&sock, APR_INET, SOCK_DGRAM, 0, p);
	if (rv != APR_SUCCESS) {
		fprintf(stderr, "cannot create socket\n");
		exit(1);
	}

	rv = apr_sockaddr_info_get(&to, addr, APR_UNSPEC, port, 0, p);
	if (rv != APR_SUCCESS) {
		fprintf(stderr, "cannot get info on to\n");
		exit(1);
	}

	rv = apr_socket_opt_set(sock, APR_SO_REUSEADDR, 1);
	if (rv != APR_SUCCESS) {
		fprintf(stderr, "fail on socket_opt_set\n");
		exit(1);
	}

	rv = apr_socket_bind(sock, to);
	if (rv != APR_SUCCESS) {
		fprintf(stderr, "cannot bind\n");
		exit(1);
	}

	while (1) {
		len = RECVBUF_LEN;
		rv = apr_socket_recvfrom(from, sock, 0, recvbuf, &len);
		if (rv != APR_SUCCESS) {
			fprintf(stderr, "server: fail on recvfrom\n");
			exit(1);
		}
		else {
			fprintf(stderr, "success on recvfrom: [%s:%d]\n", recvbuf, len);
		}
		recvbuf[len-1] = '\0';

		dha_analyze(dha, NULL, recvbuf, RECVBUF_LEN, result);
		if (result[0] == '\0') {
			strncpy(result, recvbuf, RECVBUF_LEN);
			result[RECVBUF_LEN-1] = '\0';
		}
		printf("server: result = %s[%d]\n", result, strlen(result));

		len = strlen(result)+1;
		rv = apr_socket_sendto(sock, from, 0, result, &len);
		if (rv != APR_SUCCESS) {
			fprintf(stderr, "server: fail sendto\n");
			exit(1);
		}
	}

	apr_socket_close(sock);
	dha_finalize(dha);
	return 0;
}
