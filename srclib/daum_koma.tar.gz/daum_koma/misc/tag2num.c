#include "moran_tagdef.h"
#include <string.h>


int main(int argc, char * argv[])
{
	int		i = 0;
	int		lnum = 0;
	int		rnum = 0;
	char	ltag[1024];
	char	rtag[1024];
	if(argv[1] != NULL)		
	{
		strcpy(ltag,argv[1]);

		for(i = 0; i < LEFT_TAG_CNT; i++)
		{
			if(strcmp(ltag,L_Tag_Set[i]) == 0)
			{
				lnum = i;
				break;
			}
		}
	}

	if(argv[2] != NULL)
	{
		strcpy(rtag,argv[2]);
		for(i = 0; i < RIGHT_TAG_CNT; i++)
		{
			if(strcmp(rtag,R_Tag_Set[i]) == 0)
			{
				rnum = i;
				break;
			}
		}
	}

	printf("LTAG:%d\tRTAG:%d\n",lnum,rnum);
}
