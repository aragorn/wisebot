#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include "tss.h"
#include "tsslib.h"
#include "logger.h"

#include "dha.h"

#define DEFAULT_PORT "10000"
#define DEFAULT_PATH "nlp_socket"
#define DEFAULT_MIN_THREADS 5

extern ssize_t tcp_reads(int onefd, char *buf, size_t len, unsigned int sec, unsigned int mili);
int READ(int socket, void *temp, int total_size);
int WRITE(int socket, void *temp, int total_size);

void *dha;

void    *nlp_init(char *progname, int *argc, char *argv[], int *len)
{
	char    hanl_port[1024];
	char    hanl_sockpath[1024];
	int     hanl_mainthread = 1;

	// XXX
	dha = dha_initialize(DIC_PATH);
	return NULL;
}
int nlp_final()
{
	// XXX
	dha_finalize(dha);
	return 0;
}

int nlp_idle(THREAD_SOCKET_APP_THREAD_PARAMETER *param){return 1;}

int nlp_thread_initialize(THREAD_SOCKET_APP_THREAD_PARAMETER *param)
{
	// XXX
//	param->thread_param = dha;
//	param->thread_param_len = sizeof(FINAL_INFO);
	return 1;
}

Error_Condition(int socket,char * result,  char * msg)
{
	int size = 0;
	printf("%s\n",msg);
	snprintf(result, sizeof(result), "{ }");

	size = strlen(result) + 1;
	WRITE(socket, result, size);
	printf("write data(%s)(%d)\n",result, size);

}
int nlp_thread_main(THREAD_SOCKET_APP_THREAD_PARAMETER *param)
{
	int     ret = 0;
	int     size = 0;
	char    opt[16];
	char    buf_size[256];
	char    buffer[8192];
	char    result[8192];
	int     read_size = 0;


	tcp_readbyte(param->fd, opt, 4);
	size = strlen(opt);
	if(0 > size || size > 4)
	{
		Error_Condition(param->fd,result, "Invalid input opt size");
		return 0;
	}
	opt[4] = '\0';

	tcp_readbyte_nonblock(param->fd, buffer,255,0,1000);
	size = strlen(buffer);
	if(buffer[0] == '\0' || size > 255)
	{
		Error_Condition(param->fd,result, "Invalid input buffer size");
		return 0;
	}

	if(buffer[size - 1] == '\n') buffer[size - 1] = '\0';
	printf("read(%s)\n",buffer);

	// XXX
	dha_analyze(dha, NULL, buffer, 4095, result);
//	dha_analyze(param->thread_param,NULL, buffer,4095,result);

	size = strlen(result) + 1;
	if(1 >= size || size > 4095)
	{
		Error_Condition(param->fd,result, "Invalid result size");
		return 0;
	}

	WRITE(param->fd, result, size);
	printf("write(%s)\n",result);
	return 0;
}

int nlp_thread_finalize(THREAD_SOCKET_APP_THREAD_PARAMETER *param)
{
//	if(param->thread_param)   free(param->thread_param);
	return 1;
}

int WRITE(int socket, void *temp, int total_size)
{
	int ret_size = 0;
	int write_size = 0;

	if(total_size <= 0)        return 0;

	while(total_size > 0)
	{
		ret_size = write(socket, temp, total_size);
		if(ret_size == 0)
		{
			printf("ERROR :: peer write closed\n");
			fflush(stdout);
			return -1;
		}
		else if(ret_size < 0)
		{
			printf("ERROR :: return size -1\n");
			fflush(stdout);
			return -1;
		}
		else
		{
			total_size -= ret_size;
			temp += ret_size;
			write_size += ret_size;
		}
	}

	return write_size;
}


int READ(int socket, void *temp, int total_size)
{
	int ret_size = 0;
	int read_size = 0;

	if(total_size <= 0)        return 0;

	while(total_size > 0)
	{
		ret_size = read(socket,temp, total_size);
		if(ret_size == 0)   break;
		if(ret_size < 0)
		{
			printf("ERROR :: return size -1\n");
			fflush(stdout);
			return -1;
		}
		else
		{
			total_size -= ret_size;
			temp += ret_size;
			read_size += ret_size;
		}
	}

	return read_size;
}

/* struct for tss1 .. ***  upgraded by easygo 2001. 3. 19 *********/
/**/
THREAD_SOCKET_APP_STRUCT    thread_socket_app =
{
	NULL,
	DEFAULT_PORT, //p_port,
	1024,
	NULL,
	1,  //if daemon mode: 1, else 0
	0,  // this field is added. second of update period
	&nlp_init,
	&nlp_final,
	NULL,   //&nlp_idle,
	&nlp_thread_initialize,
	&nlp_thread_main,
	&nlp_thread_finalize
};
/**/
