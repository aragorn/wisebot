#include <string.h>
#include <stdlib.h>
#include <stdio.h>


int	main(int	argc, char	*argv[])
{
	FILE	*fpo;
	FILE	*fpi;
	int		size = 0;
	char	buffer[1024];
	char	result[1024];
	char	tag[1024];
	char	tag_y[1024];
	char	tag_n[1024];
	char	tag_l[1024];

	if(argc != 4)
	{
		printf("%s <dictionary> <input file> <tag>\n",argv[0]);
		exit(1);
	}
	fpo = fopen(argv[1],"a");
	fpi = fopen(argv[2],"r");

	if(fpo == NULL || fpi == NULL)
	{
		if(fpo == NULL)	printf("[%s]input file null\n",argv[1]);
		else			printf("[%s]input file null\n",argv[2]);
	}
	strcpy(tag,argv[3]);
	strcpy(tag_y,argv[3]);
	strcpy(tag_n,argv[3]);
	strcpy(tag_l,argv[3]);
	strcat(tag_y,"_y");
	strcat(tag_n,"_n");
	strcat(tag_l,"_l");
	while(fgets(buffer,1024,fpi) != NULL)
	{
		size = strlen(buffer);
		if(buffer[size - 1] == '\n')	buffer[size - 1] = '\0';
		if(HANL_ks2kimmo(buffer,result) == 0)	continue;
		size = strlen(result);
		if(HANL_is_jongsung(result[size-1]))
		{
			if((char)(result[size-1]- 128) == (char)'L')
			{
				fprintf(fpo,"%s %s %s\n",buffer,tag,tag_l);
			}
			else
			{
				fprintf(fpo,"%s %s %s\n",buffer,tag,tag_y);
			}
		}
		else
		{
			fprintf(fpo,"%s %s %s\n",buffer,tag,tag_n);
		}
	}
	fclose(fpo);
	fclose(fpi);
	return 0;

}
