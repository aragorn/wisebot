#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int	main(int	argc, char	*argv[])
{ 
	char  line[2048], word[1024],ascword[2048], ksword[1024],temp[1024];
	int   tags, lnum, rnum, i=0;
	int   count = 0;
	unsigned char *cp;
	FILE	*fp;
	FILE	*fw;

	fp = fopen(argv[1],"r");
	fw = fopen(argv[2],"w");
	while(fgets(line,1024,fp) != NULL) 
	{
		count++;
		if(sscanf(line,"%s %d %d",ascword, &lnum, &rnum) != 3) 
		{
			fprintf(stderr,"ERROR at Line %d\n",count);
			continue;
		}
		HANL_kimmo2ks(ascword,temp);
		fprintf(fw,"%s\t%d\t%d\n",temp,lnum, rnum);

	}
	fclose(fp);
	fclose(fw);
}
