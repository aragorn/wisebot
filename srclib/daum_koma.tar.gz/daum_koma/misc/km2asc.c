#include <stdio.h>
#include <ctype.h>
#include <string.h>

int	KAI_print_km2asc(char * kimmoword)
{
	unsigned char		*cp;

	cp = (unsigned char *)kimmoword;

	while(*cp) 
	{
		if(*cp > 128) 
			printf("%c",(*cp)-128);
		else
			printf("/%c",*cp);

		cp++;
	}
	printf("\t ");
}

int	main(int	argc, char * argv[])
{
	char  line[2048], word[1024],kimmoword[2048], ksword[1024],temp[1024];
	int   tags, lnum, rnum, i=0;
	int   count = 1;
	unsigned char *cp;
	FILE	*fp;
	fp = fopen(argv[1],"w");

	while(fgets(line,2048,stdin) != NULL)
	{
		if(sscanf(line,"%s %d %d",kimmoword, &lnum, &rnum) != 3) 
		{
			fprintf(stderr,"[%d]Invalid input(%s)\n",count,line);
			break;
		}

		KAI_print_km2asc(kimmoword);
		printf("%d\t %d\n", lnum, rnum);
		HANL_kimmo2ks(kimmoword,temp);
		fprintf(fp,"%s\t%d\t%d\n",temp,lnum, rnum);

		count++;
	}
	fclose(fp);
}
