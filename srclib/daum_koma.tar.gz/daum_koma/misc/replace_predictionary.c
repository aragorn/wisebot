#include "replace_predictionary.h"

static TN tnl[LEFT_TAG_CNT];
static TN tnr[RIGHT_TAG_CNT];

static void Replace_predic(char * fn);
static void Replace_aliasdic(char * fn);

void 	*compare(const void * a, const void * b)
{
	int		ret = 0;
	char	temp1;
	char	temp2;
	const TN *x = (const TN*)a;
	const TN *y = (const TN*)b;
	return (void*)(strcmp(x->TAG,y->TAG));
	
}

int main(int argv, char * argc[])
{

	int 	i = 0;
	int 	j = 0;
	int 	size = 0;
	char	*bp;
	char	*token;
	char	buffer[1024];
	FILE	*fpl = NULL;
	FILE	*fpr = NULL;

	if(argv != 5)
	{
		printf("%s LEFT.TAG.NAME RIGHT.TAG.NAME predic_path, alias_path\n",argc[0]);
		exit(1);
	}

	fpl = fopen(argc[1],"r");
	if(fpl == NULL)
	{
		printf("file open error(%s)\n",argc[1]);
		exit(1);
	}
	while(fgets(buffer,1024,fpl) != NULL)
	{
		size = strlen(buffer);
		if(buffer[size - 1] == '\n')	buffer[size - 1] = '\0';
		token = (char*)strtok_r(buffer,"\t",&bp);
		if(token != NULL)
		{
			strcpy(tnl[i].TAG,token);
			token = (char*)strtok_r(NULL,"\t",&bp);
			tnl[i].tagnum = atoi(token);
#ifdef	DEBUG
			printf("%s\t%d\n",tnl[i].TAG,tnl[i].tagnum);
#endif
			i++;
			if(i > LEFT_TAG_CNT)
			{
				printf("%s\t%d\t(MAX:%d)(buf:%s)overflow tnl struct\n",__FUNCTION__,__LINE__,LEFT_TAG_CNT,buffer);
			}
		}
	}
	printf("i = %d\n",i);
	fclose(fpl);
	qsort(tnl,i,sizeof(tnl[0]),compare);

	fpr = fopen(argc[2],"r");
	if(fpr == NULL)
	{
		printf("file open error()\n",argc[2]);
		exit(1);
	}


	while(fgets(buffer,1024,fpr) != NULL)
	{
		size = strlen(buffer);
		if(buffer[size - 1] == '\n')	buffer[size - 1] = '\0';
		token = (char*)strtok_r(buffer,"\t",&bp);
		if(token != NULL)
		{
			strcpy(tnr[j].TAG,token);
			token = (char*)strtok_r(NULL,"\t",&bp);
			tnr[j].tagnum = atoi(token);
#ifdef	DEBUG
			printf("%s\t%d\n",tnr[j].TAG,tnr[j].tagnum);
#endif
			j++;
			if(j > RIGHT_TAG_CNT)
			{
				printf("%s\t%d\t(MAX:%d)(buf:%s)overflow tnl struct\n",__FUNCTION__,__LINE__,RIGHT_TAG_CNT,buffer);
			}

		}
	}
	printf("j = %d\n",j);
	fclose(fpr);
	qsort(tnr,j,sizeof(tnr[0]),compare);

#ifdef	DEBUG
	printf("-----------------------------\n");
	for(i = 0; i < LEFT_TAG_CNT; i++)
	{
		printf("%s\t%d\n",tnl[i].TAG,tnl[i].tagnum);
	}
	for(i = 0; i < RIGHT_TAG_CNT; i++)
	{
		printf("%s\t%d\n",tnr[i].TAG,tnr[i].tagnum);
	}

#endif
	Replace_aliasdic(argc[3]);
	Replace_predic(argc[4]);
	return 0;

}

static void *BinarySearch(void * arr, int arrsize, void * data, int *ivalue) 
{ 
	int     max = 0; 
	int     min = 0; 
	int     cur = 0; 
	int     ret = 0; 
	int     closecondition = 0; 
	char    *token; 
	char    temp[1024]; 
	char    value[1024]; 
	char    keyword[1024]; 
	char    tdata[1024]; 

	TN * void_data = (TN*)arr;
	max = arrsize - 1; 

	strcpy(tdata, (char*)data); 
	for(;;)
	{ 
		if(min >= max)  closecondition = 1; 
		cur = (min + max) / 2; 
		strcpy(keyword, (char*)((TN*)void_data+cur)->TAG); 

		*ivalue = (int)((TN*)void_data+cur)->tagnum; 

		ret = strcmp(keyword, tdata); 

		if( ret == 0 ) 
		{ 
			return (void*)*ivalue; 
		} 
		else if( ret > 0 ) 
		{ 
			max = cur - 1; 
		} 
		else if( ret < 0 ) 
		{ 
			min = cur + 1; 
		} 
		if(closecondition)  break; 


	} 
	return NULL; 
} 

//ncn/6.25/ncn_n
static void sepTag(char *str, SRESULT *sr)
{
	int	idx = 0;
	int	slash = 0;
	char	temp[1024];

	int	iret = 0;
	
	
	while(*str != '\0')
	{
		if(*str == '/')
		{
			temp[idx] = '\0';
			switch(slash)
			{
				case 0 :
					strcpy(sr->ltag.TAG,temp);
					iret = (int)BinarySearch(tnl,LEFT_TAG_CNT,sr->ltag.TAG,&iret);
					if(iret > 0)					sr->ltag.tagnum = iret;
					break;
				case 1 :
					strcpy(sr->keyword,temp);
					break;
			}
			idx = 0;
			slash++;
		}
		else	
		{
			temp[idx++] = *str;
		}
		str++;
		
	}

	temp[idx] = '\0';
	strcpy(sr->rtag.TAG,temp);
	iret = (int)BinarySearch(tnr,RIGHT_TAG_CNT,sr->rtag.TAG,&iret);
	if(iret > 0)					sr->rtag.tagnum = iret;

}

static void Replace_predic(char * fn)
{
	int		valid = 1;
	int		linecount = 0;
	int		skipcount = 0;
	int		iret = 0;
	int		size = 0;
	char	*p = NULL;
	char	*q = NULL;
	char	*bp = NULL;
	char	*ip = NULL;
	char	*ret = NULL;
	char	*token = NULL;
	char	*wtoken = NULL;
	char	buffer[1024];
	char	word[1024];
	char	temp[1024];
	char	keyword[1024];
	char	tag[1024];
	char	filename[1024];
	FILE	*fp = NULL;
	FILE	*fw = NULL;

	SRESULT	sr;
	fp = fopen(fn,"r");
	if(fp == NULL)
	{
		printf("file open error(%s)\n",fn);
		exit(1);
	}

	strcpy(filename,fn);
	strcat(filename,".ret");
	fw = fopen(filename,"w");

	while(fgets(buffer,1024,fp) != NULL)
	{
		linecount++;
		p = keyword;	
		q = tag;
		size = strlen(buffer);
		if(buffer[size - 1] == '\n')	buffer[size - 1] = '\0';
#ifdef	DEBUG
		if(buffer[0] == '#')	
		{
			skipcount++;
			printf("-----	[%04d]��м� ���� : %s\n",skipcount, buffer);
			continue;
		}	
		printf("[%04d]��м� ���� : %s\n",linecount, buffer);
		if(buffer[0] == '#')	continue;
		strcpy(temp,buffer);
#endif
		token = (char*)strstr(buffer,"\t");
		if(token != NULL)
		{
			*(token++) = '\0';
			fprintf(fw,"%s\t",buffer);
		
			if(token == NULL)
			{
				printf("*****	[PARSING ERROR]	(%s)�� �����ڸ� Ȯ���ϼ���	*****\n",buffer);
				continue;
			}

			strcpy(word,token);

			wtoken = (char*)strtok_r(word," ",&bp);
			for(;;)
			{
				if(wtoken == NULL)
				{
					break;
				}
				else
				{
					sepTag(wtoken,&sr);
					fprintf(fw,"%d/%s/%d ",sr.ltag.tagnum,sr.keyword,sr.rtag.tagnum);
					wtoken++;
					wtoken = (char*)strtok_r(NULL," ",&bp);
				}
			}
			
			memset(&sr,0,sizeof(SRESULT));

		}
		fprintf(fw,"\n");
	}
	printf("\n------------------------------------------------\n");
	printf("	- Pre-Dictionary Build info\n");
	printf("	- TOTAL      COUNT : %d\n",skipcount+linecount);
	printf("	- SKIP       COUNT : %d\n",skipcount);
	printf("	- PROCESSING COUNT : %d\n",linecount);
	printf("-------------------------------------------------\n\n");

	fclose(fp);
	fclose(fw);
}

static void Replace_aliasdic(char * fn)
{
	int		valid = 1;
	int		linecount = 0;
	int		skipcount = 0;
	int		iret = 0;
	int		size = 0;
	FILE	*fp;
	FILE	*fw;
	char	*p;
	char	*q;
	char	*ret;
	char	*token;
	char	buffer[1024];
	char	temp[1024];
	char	keyword[1024];
	char	tag[1024];
	char	filename[1024];

	fp = fopen(fn,"r");
	if(fp == NULL)
	{
		printf("file open error(%s)\n",fn);
		exit(1);
	}

	strcpy(filename,fn);
	strcat(filename,".ret");
	fw = fopen(filename,"w");

	while(fgets(buffer,1024,fp) != NULL)
	{
		linecount++;
		p = keyword;	
		q = tag;
		size = strlen(buffer);
		if(buffer[size - 1] == '\n')	buffer[size - 1] = '\0';
#ifdef	DEBUG
		if(buffer[0] == '#')	
		{
			skipcount++;
			printf("-----	[%04d]���� ���� : %s\n",skipcount, buffer);
			continue;
		}	
		printf("[%04d]���� ���� : %s\n",linecount, buffer);
		if(buffer[0] == '#')	continue;
		strcpy(temp,buffer);
#endif
		token = (char*)strstr(buffer,"\t");
		if(token != NULL)
		{
			token[0] = '\0';
			fprintf(fw,"%s\t",buffer);
			token++;
			for(;;)
			{
				if(token == '\0' || token == NULL)	
				{
					printf("*****	[PARSING ERROR]	(%s)�� �����ڸ� Ȯ���ϼ���.	*****\n",buffer);
					continue;
				}

				if(*token == '/')
				{
					*p = '\0';
					token++;
					for(;;)
					{
						if(token == NULL || *token == ' ' || *token == '\0')
						{
							if(*token == ' ' && valid == 0)
							{
								printf("*****	[SYNTAX ERROR]%d:(%s)\tRIGHT.TAG NAME�� '/'�� �������ϴ�.	*****\n",linecount,temp);
								memset(keyword,0,1024);
								memset(tag, 0, 1024);
							}
							break;
						}
						valid = 1;
						*(q++) = *(token++);
					}
					*q = '\0';
					iret = (int)BinarySearch(tnr, RIGHT_TAG_CNT, tag,&iret) ;
					if(iret >= 0 && keyword[0] != '\0')
					{
						fprintf(fw,"%s/%d ",keyword, iret);
						memset(keyword,0,1024);
						memset(tag, 0, 1024);
					}
					else
					{
						fprintf(stderr,"*****	[ALIAS ERROR] (%s) buffer(%s) : Tag(%s) Can't find	***** \n",buffer,tag);
						memset(keyword,0,1024);
						memset(tag, 0, 1024);
						continue;
					}
					q = tag;
					if(token[0] == '\0')	break;
					p = keyword;	
				}
				else
				{
					if(*token != ' ')
					{
						*p = *token;
						p++;
					}
					else
					{
						if(tag[0] == '\0')	valid = 0;
					}
					token++;
				}
			}
		}
		fprintf(fw,"\n");
	}
	printf("\n------------------------------------------------\n");
	printf("	- Alias-Dictionary Build info\n");
	printf("	- TOTAL      COUNT : %d\n",skipcount+linecount);
	printf("	- SKIP       COUNT : %d\n",skipcount);
	printf("	- PROCESSING COUNT : %d\n",linecount);
	printf("-------------------------------------------------\n\n");
	fclose(fp);
	fclose(fw);
}
