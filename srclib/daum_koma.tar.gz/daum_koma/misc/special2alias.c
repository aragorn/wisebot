#include	<stdio.h>

int main()
{ 
	char	line[1024], kwd[1024], ltag[1024], rtag[1024], *cp;

	while(fgets(line, 1024, stdin)) 
	{
		if(sscanf(line, "%s %s %s", kwd, ltag, rtag) != 3) 
		{
			fprintf(stderr,"*****	[PARSING ERROR] return value of sscanf is not valid[%s.c]	*****\n",line,"special");
			break;
		}
		cp =(char*) strstr(line, (char*)"\t");
		if(cp == NULL)
		{
			int	size = 0;
			size = strlen(line);
			if(line[size - 1] == '\n')	line[size - 1] = '\0';
			fprintf(stderr,"*****	[PARSING ERROR] (%s) Not exist tab delimeter[%s.c]	*****\n",line,"special");
			continue;
		}
		cp++;
		printf("%s\t%s", kwd, cp);
	}
	return 0;
}
