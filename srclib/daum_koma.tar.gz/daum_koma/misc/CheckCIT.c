
#include "moran_tagdef.h"
#include "moran_grammar.h"

int	main(int	argc,	char	*argv[])
{
	int	left = 0;
	int	right = 0;

	if(argc != 3)
	{
		printf("Usage : %s <right tag> <left tag>\n",argv[0]);
		exit(1);
	}

	right = atoi(argv[1]);
	left = atoi(argv[2]);

	printf("CIT = %d\n",CIT[right][left]);


}
