#include "apr_network_io.h"
#include "apr_errno.h"
#include "apr_general.h"
#include "apr_lib.h"

int main (int argc, char *argv[]) {
	apr_pool_t *p;

	apr_status_t rv;
	apr_socket_t *sock = NULL;
	apr_size_t len;
	apr_sockaddr_t *to;
	const char *addr = "10.10.30.14";
	char recvbuf[4096];

	apr_initialize();
	apr_pool_create(&p, NULL);

	rv = apr_socket_create(&sock, APR_INET, SOCK_DGRAM, 0, p);
	if (rv != APR_SUCCESS) {
		fprintf(stderr, "cannot create socket\n");
		exit(1);
	}

	rv = apr_sockaddr_info_get(&to, addr, APR_UNSPEC, 7772, 0, p);
	if (rv != APR_SUCCESS) {
		fprintf(stderr, "cannot get info on to\n");
		exit(1);
	}

	rv = apr_socket_opt_set(sock, APR_SO_REUSEADDR, 1);
	if (rv != APR_SUCCESS) {
		fprintf(stderr, "fail on socket_opt_set\n");
		exit(1);
	}

	len = strlen(argv[1]) + 1;
	rv = apr_socket_sendto(sock, to, 0, argv[1], &len);
	if (rv != APR_SUCCESS) {
		fprintf(stderr, "fail sendto\n");
		exit(1);
	}

	len = 4096;
	rv = apr_socket_recvfrom(to, sock, 0, recvbuf, &len);
	if (rv != APR_SUCCESS) {
		fprintf(stderr, "client: fail on recvfrom\n");
		exit(1);
	}
	printf("client: recieved %s\n", recvbuf);

	apr_socket_close(sock);
	return 0;
}
