#include <string.h>
#include <stdlib.h>
#include <stdio.h>



int		main(int	argc, char	 *argv[])
{


	FILE	*fp;
	FILE	*fw;
	int		i = 0;
	int		ret = 0;
	int		loop = 0;
	char	*token;
	char	buffer[1024];
	char	keyword[1024];
	char	word[256];
	char	ltag[256];
	char	rtag[256];
	char	imsy[256];
	char	temp[10][256];

	fp = fopen(argv[1],"r");
	fw = fopen(argv[2],"w");

	while(fgets(buffer,1024,fp) != NULL)
	{

		ret = sscanf(buffer,"%s\t%s%s%s%s%s%s%s%s%s%s",keyword,temp[0],temp[1],temp[2],temp[3],temp[4],temp[5],temp[6],temp[7],temp[8],temp[9]);
		loop = ret-1;
		fprintf(fw,"%s\t",keyword);
		for(i = 0; i < loop; i++)
		{
			strcpy(imsy,temp[i]);
			token = strtok(temp[i],"/");
			if(strcmp(imsy,token) == 0)
			{
				fprintf(fw,"/%s ",temp[i]);
			}
			else
			{
				strcpy(word,token);
				token = strtok(NULL,"/");
				if(token != NULL)
				{
					strcpy(ltag,token);
				}
				fprintf(fw,"%s/%s",ltag,word);
			}
		}
		fprintf(fw,"\n");

	}

	fclose(fp);
	fclose(fw);
}
