#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define	MAX	11172
#define	KEY_SIZE	41
#define	LEN 128


int	compare(const void*a, const void*b)
{
	return strcmp((char*)a,(char*)b);
}
int	icompare(const void*a, const void*b)
{
	return (int*)a - (int*)b;
}

int main()
{
	FILE	*fp;
	FILE	*fw = fopen("hantable.c","w");

	char	buffer[LEN];
	char	field1[LEN];
	char	field2[LEN];
	char	field3[LEN];
	char	field4[LEN];
	char	field5[LEN];
	char	field6[LEN];
	char	field7[LEN];
	char	field8[LEN];
	char	field9[LEN];
	char	field10[LEN];
	char	field11[LEN];
	char	field12[LEN];
	char	table1[MAX][LEN];
	char	table2[MAX][LEN];
	int		itbl1[LEN];
	int		itbl2[LEN];
	unsigned	char	tbl2[LEN][LEN];
	int		numer[] = {3,4,5,6,7,10,11,12,13,14,15,18,19,20,21,22,23,26,27,28,29};
	int		idx = 0;
	int		i = 0;
	int		size1 = 0;
	int		size2 = 0;
	int		temp=0;

//	fprintf(fw,"#ifndef\t__HANTABLE__H__\n");
//	fprintf(fw,"#define\t__HANTABLE__H__\n");
//	fprintf(fw,"#define\tHANGUL_MARK\t128\n");
//	fprintf(fw,"#define\tKEY_SIZE\t%d\n\n\n",KEY_SIZE);
//	fprintf(fw,"#define\tKSC_SIZE\t11172\n\n\n");

	strcpy(buffer,"������������������������������������");
	size1 = strlen(buffer);


	for(i = 0; i < size1; i += 2)
	{
			itbl1[idx] += 33281;//0x8201	
			temp = (1024) * (2 + idx);
			itbl1[idx] += temp;
	
			temp = 0;
			tbl2[idx][0] = buffer[i];
			tbl2[idx][1] = buffer[i+1];
			temp = tbl2[idx][0];
			temp *= 256;		//0x0100
			temp += tbl2[idx][1];
			itbl2[idx] = temp;
			idx++;
	}
	strcpy(buffer,"�Ǥ������¤äĤŤǤȤɤʤˤ̤ϤΤϤФѤҤ�");
	size2 = strlen(buffer);

	for(i = 0; i < size2; i++)
	{
		itbl1[idx] += 41985;	//0xAKEY_SIZE1
		itbl1[idx] += numer[i];
	
		tbl2[idx][1] = buffer[i+size1];
		tbl2[idx][0] = buffer[i+1+size1];
		temp = tbl2[idx][0];
		temp *= 256;			//0x011
		temp += tbl2[idx][1];
		itbl2[idx] = temp;


		idx++;
	}

	for(i = 0; i < KEY_SIZE; i++)
	{
		if(itbl1[i] >= 4096 && itbl2[i] >= 4096)
		{
			sprintf(table1[i],"0x%x, 0x%x,",itbl1[i],itbl2[i]);
			sprintf(table2[i],"0x%x, 0x%x,",itbl2[i],itbl1[i]);
		}
		else
		{
			if(itbl1[i] < 4096)
			{
				if(itbl1[i] >= 256)
				{
					sprintf(table1[i],"0x0%x, 0x%x,",itbl1[i],itbl2[i]);
					sprintf(table2[i],"0x%x, 0x0%x,",itbl2[i],itbl1[i]);
				}
				else
				{
					sprintf(table1[i],"0x00%x, 0x%x,",itbl1[i],itbl2[i]);
					sprintf(table2[i],"0x%x, 0x00%x,",itbl2[i],itbl1[i]);
				}
			}
			else
			{
				if(itbl2[i] >= 256)
				{
					sprintf(table1[i],"0x%x, 0x0%x,",itbl1[i],itbl2[i]);
					sprintf(table2[i],"0x0%x, 0x%x,",itbl2[i],itbl1[i]);
				}
				else
				{
					sprintf(table1[i],"0x%x, 0x00%x,",itbl1[i],itbl2[i]);
					sprintf(table2[i],"0x00%x, 0x%x,",itbl2[i],itbl1[i]);
				}
			}
		}
	}
	sprintf(table1[KEY_SIZE-1],"0xa1a4, 0xa1a4,");
	sprintf(table2[KEY_SIZE-1],"0xa1a4, 0xa1a4,");

	qsort(table1,KEY_SIZE,sizeof(char)*LEN,compare);
	qsort(table2,KEY_SIZE,sizeof(char)*LEN,compare);

	fprintf(fw,"int JASOW2C[KEY_SIZE][2] = {\n");

	for(i = 0; i < KEY_SIZE ; i++)
	{
		fprintf(fw,"/*%2d*/\t%s\n",i,table2[i]);
	}
	fprintf(fw,"};\n\n\n");
	fprintf(fw,"int JASOC2W[KEY_SIZE][2] = {\n");
	for(i = 0; i < KEY_SIZE ; i++)
	{
		fprintf(fw,"/*%2d*/\t%s\n",i,table1[i]);
	}
	fprintf(fw,"};\n\n\n");

	fp = fopen("hancode.h","r");
	if(fp == NULL)
	{
		printf("file open error(%s)\n","hancode.h");
	}
	idx = 0;
	while(fgets(buffer,LEN,fp) != NULL)
	{
		sscanf(buffer,"%s %s %s %s %s %s %s %s %s %s %s %s", field1,field2,field3,field4,field5,field6,field7,field8,field9,field10,field11,field12);
		if(buffer[0] == '/')
		{
			sprintf(table1[idx],"%s, %s,",field5,field7);
			sprintf(table2[idx],"%s, %s,",field7,field5);
			idx++;
		}
	}
	qsort(table1,MAX,sizeof(char)*LEN,compare);
	qsort(table2,MAX,sizeof(char)*LEN,compare);


	fprintf(fw,"//Converte Wangsung to Johap code\n");
	for(i = 0; i < MAX; i++)
	{
		if(i == 0)	fprintf(fw,"int\tEXW2C[KSC_SIZE][2] = {\n");
		fprintf(fw,"/* %05d */\t\t%s\n",i,table1[i]);
	}
	fprintf(fw,"};\n\n//Converte Johap to Wansung code\n");
	for(i = 0; i < MAX; i++)
	{
		if(i == 0)	fprintf(fw,"int\tEXC2W[KSC_SIZE][2] = {\n");
		fprintf(fw,"/* %05d */\t\t%s\n",i,table2[i]);
	}
	fprintf(fw,"};\n");
	fprintf(fw,"#endif\n");
	fclose(fp);
	fclose(fw);

	return 0;
}
