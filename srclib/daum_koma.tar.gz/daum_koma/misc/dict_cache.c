#include <stdio.h>
#include "dict_cache.h"

#define HIT_SCORE		(1)
#define MISS_PENALTY	(-1)

struct _dict_cache_t {
	dict_cache_slot_t *slots;

	int nblock;
	int nslot;
	int size;

	// private
	void *ptr;
};

static void miss(dict_cache_slot_t *slot, int nslot, int minus);
static dict_cache_slot_t *hit(dict_cache_slot_t *slot, int plus);
static unsigned int hash(unsigned char *key, int len, int prime);

// nblock: should be prime!
dict_cache_t *dict_cache_create(int size, int nblock, int nslot)
{
	int i;
	dict_cache_t *cache;

	cache = (dict_cache_t*)malloc(sizeof(dict_cache_t));
	if (cache == NULL) { return NULL; }

	cache->slots = (dict_cache_slot_t *)malloc(nblock *
									sizeof(dict_cache_slot_t) * nslot);
	if (cache->slots == NULL) { return NULL; }

	cache->ptr = malloc(nblock * nslot * size);

	for (i=0; i<nblock * nslot; i++) {
		cache->slots[i].occupied = 0;
		cache->slots[i].data = cache->ptr + i * size;
	}

	cache->nblock = nblock;
	cache->nslot = nslot;
	cache->size = size;

	return cache;
}

void dict_cache_destroy(dict_cache_t *this)
{
	free(this->slots);
	free(this->ptr);
	free(this);
}

// only two interfaces!!!
dict_cache_slot_t *dict_cache_lookup(dict_cache_t *this, char *key, int keylen)
{
	int idx, i, offset = 0;

	idx = hash(key, keylen, this->nblock);
	for (i=0; i<this->nslot; i++) {
		offset = idx * this->nslot + i;

		// check if occupied
		if (!this->slots[offset].occupied) continue;

		// compare key
		if (!strncmp(this->slots[offset].key,
				key,
				STRING_KEY_SIZE))
			break;
	}

	// if not found
	if (i == this->nslot) {
		miss(&(this->slots[idx * this->nslot]), this->nslot, 2);
		return NULL;
	}

	// if found
	return hit(&(this->slots[offset]), keylen);
}

int dict_cache_advice(dict_cache_t *this, char *key, int keylen, void *data, int datasize)
{
	int idx, i, offset, minidx, minscore;
	idx = hash(key, keylen, this->nblock);
	offset = idx * this->nslot;

	if (datasize > this->size) return -1;

	// find unoccupied slot
	for (i=0; i<this->nslot; i++, offset++) {
		if (!this->slots[offset].occupied) break;
	}

	// if found
	if (i != this->nslot) {
		goto fillslot;
	}

	// if no found
	offset = idx * this->nslot;
	minscore = 0x7fffffff;

	// find the slot of minimum score
	for (i=0; i<this->nslot; i++, offset++) {
		if (this->slots[offset].score < minscore) {
			minidx = offset;
			minscore = this->slots[offset + i].score;
		}
	}
	offset = minidx;

	// take the slot
fillslot:
	strncpy(this->slots[offset].key, key, STRING_KEY_SIZE);
	memcpy(this->slots[offset].data, data, datasize);
	this->slots[offset].size = datasize;
	this->slots[offset].score = keylen;
	this->slots[offset].occupied = 1;

	return 1;
}

static unsigned int hash(unsigned char *key, int len, int prime)
{
	unsigned int hash, i;
	for (hash=len, i=0; i<len; ++i)
		hash = (hash<<4)^(hash>>28)^key[i];
	return (hash % prime);
}

static dict_cache_slot_t *hit(dict_cache_slot_t *slot, int plus)
{
	slot->score += plus;
	return slot;
}

static void miss(dict_cache_slot_t *slot, int nslot, int minus)
{
	int i;
	for (i=0; i<nslot; i++) {
		slot[i].score -= minus;
		if (slot[i].score < 0) slot[i].score = 0;
	}
}
