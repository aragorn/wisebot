#include <stdio.h>
#include "dict_cache.h"

#define DATASIZE  		128
char data[] = "data";

#define NBLOCK			127
#define NSLOT			16

int main () {
	int len, miss = 0, hit = 0;
	char buffer[1024];

	dict_cache_t *cache;
	dict_cache_slot_t *slot;
	
	cache = dict_cache_create(DATASIZE, NBLOCK, NSLOT);
	if (cache == NULL) {
		fprintf(stderr, "cannot create cache!\n");
		exit(1);
	}

	/* test cache */
	while (fgets(buffer, 1024, stdin) != NULL) {
		len = strlen(buffer);
		if (buffer[len-1] == '\n' || buffer[len-1] == '\r') buffer[--len] = '\0';
		if (len >= 127) buffer[127] = '\0';

		slot = dict_cache_lookup(cache, buffer, len);

		/* if miss */
		if (slot == NULL) {
			dict_cache_advice(cache, /*key*/ buffer, /*keylen*/ len, 
									 /*data*/ buffer, /*datasize*/ DATASIZE);
			miss++;
			printf("%s\n", buffer);
		}
		else {
			hit++;
			printf("%s\n", (char*)slot->data);
		}
	}

	printf("result: hit[%d], miss[%d]\n", hit, miss);
	return 0;
}
