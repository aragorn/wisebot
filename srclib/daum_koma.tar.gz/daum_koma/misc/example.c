#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "dha.h"

#define	MAX_LEN 				1024
#define	MAX_OUTPUT				4096
#define DIC_PATH 				"../RunEnv"
#define CONF_PATH 				DIC_PATH "/CONFIG.HANL"

int	main (int argc, char *argv[])
{
	int		count = 0, size = 0;
	char	buffer[MAX_LEN];
	char	result[MAX_OUTPUT];
	void 	*dha;
	FILE	*fp = stdin;

	// 1) initialize module
	dha =  dha_initialize(DIC_PATH, CONF_PATH);
	assert(dha != NULL);

	while(fgets(buffer, MAX_LEN, fp) != NULL)
	{
		// 2) analyze!!!
		// CAUTION: input string must be finished with null
		dha_analyze(dha, NULL, buffer, MAX_OUTPUT, result);

		if (result[0] == '\0')
			printf(">> �������\n");
		else
			printf(">> %s\n", result);

		result[0] = '\0';
		count++;
	}

	// 3) finalize module
	dha_finalize(dha);

	return 0;
}
