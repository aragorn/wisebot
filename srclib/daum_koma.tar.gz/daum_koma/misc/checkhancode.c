#include 	<stdio.h>
#include 	<string.h>
#include	<malloc.h>
#include 	<ctype.h>
#include	<unistd.h>
#include	<sys/stat.h>
#include	<fcntl.h>
#include  	"moran.h"
#include	"moran_tagdef.h"
#include	"moran_grammar.h"

#define HANGUL_MARK     128
#define HM(c) ( (c) | HANGUL_MARK )
int	main(int argc, char * argv[])
{
	int		i = 0;
	int		size = 0;
	char	inputstring[1024];
	char	resultstring[1024];
	char	outputstring[1024];

	while(fgets(inputstring,1024,stdin) != NULL) 
	{
		size = strlen(inputstring);
		if(inputstring[size - 1] = '\n')	inputstring[size - 1] = '\0';
		if(HANL_ks2kimmo(inputstring, resultstring) == 0)	return(NO);

		if(HANL_kimmo2ks(resultstring, outputstring) == 0) return (NO);



		if(strcmp(inputstring,outputstring) != 0)
		{
			printf("in  : %s\t", inputstring);
			printf("zoo : %s\t", resultstring);
			printf("out : %s\n", outputstring);
		}

	}
	return 0;
}




