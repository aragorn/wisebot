#include <string.h>
#include <stdio.h>


int main()
{
	char 	buffer[1024];
	char 	*token;
	while(fgets(buffer,1024,stdin) != NULL)
	{
		token = strstr(buffer,":");
		token += 1;
		fprintf(stdout,"%s",token);
	}
}
