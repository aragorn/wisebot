#!/bin/bash
(nohup ./testserver $1 $2 > /dev/null &)
