#!/bin/sh
# source code compile

HANL=/data3/ssh/HANL
# main program

if [ $# -ne 3 ]
then
	echo "--[Is Not Enouth Argument]"
	echo "$0 <dictionary> <input file> <tag>"
else
	echo " counting"
	wc -l $1
	sed -e 's/ 	/	/g' $1 > temp
	$HANL/bin/DecisionTag temp $2 $3
	echo " sorting"
	sort -u temp > $1
	echo " counting"
	wc -l $1
	echo " remove temporary file"
	rm -f temp
fi


