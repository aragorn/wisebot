#!/bin/sh
# source code compile

HANL=/data2/nominam/HANL
# main program

grep "$1	$2" $HANL/GrmEnv/Grammar.moran 
