#!/bin/bash 
chmod 755 Get_example_dic_entry.sh
chmod 755 Grammar_Check.sh
chmod 755 Num2Tag.sh
chmod 755 ROOTBACKUP.sh
chmod 755 Search_Dictionary.sh
chmod 755 Tag2Num.sh
chmod 755 UnusedTagCheck.sh
chmod 755 hanltest.sh
chmod 755 makedic.sh
chmod 755 mkd.sh
chmod 755 upload_nindex_backup2.sh
chmod 755 AddDictionary.sh
./mkd.sh
