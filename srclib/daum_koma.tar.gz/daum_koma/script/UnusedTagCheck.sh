#!/bin/sh

HANL=/data2/nominam/HANL
# main program


echo "--------------------Unused Left Tag List--------------------"
cut -f1 $HANL/bin/LEFT.TAG.NAME > input.tag
cat input.tag | while read line 
do 
	count=`grep "$line" $HANL/srcdict/* | wc -l`
	if [ $count -eq 0 ]
	then
		echo $line;
	fi
done 

rm -f input.tag
