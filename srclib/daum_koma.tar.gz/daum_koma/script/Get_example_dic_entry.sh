#!/bin/sh
# source code compile

HANL=/data2/nominam/HANL
# main program

cat $HANL/GrmEnv/TagSet | while read line 
do
	echo "_________________________________________"
	echo "------------------$line------------------"
grep "$line" $HANL/srcdict/* | $HANL/bin/GetTagSet | awk '{print $1}'
done
