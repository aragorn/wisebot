#!/bin/bash

echo '*** Step1: pos tagging... ***'
../src/hanlindex < $1 > /tmp/.result.0

echo '*** Step2: extract a result line... ***'
sed -n -e '/^>>/p' /tmp/.result.0 > /tmp/.result.1

echo '*** Step3: formation... ***'
sed -e 's/>> //' /tmp/.result.1 > /tmp/.result.2
sed -e 's/  / /g' /tmp/.result.2 > $2

echo '*** Step5: remove temporary files... ***'
#rm -f /tmp/.$1.result.[012]
