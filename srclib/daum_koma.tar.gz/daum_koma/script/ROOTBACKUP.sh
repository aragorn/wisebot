#!/bin/sh


DATE=`date +%y%m%d`

FILENAME=$DATE.HANL.src.tgz

echo $FILENAME
tar -zcvf $FILENAME /data3/jchern/HANL/src/* /data3/jchern/HANL/script/* /data3/jchern/HANL/src/HANL_API/*
mv $FILENAME ../
ncftpput -u daumsoft -p ekdmathvmxm 211.32.117.92 /data3/daumsoft/HANL /data3/jchern/$FILENAME

