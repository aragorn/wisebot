#!/bin/sh

ncftpput -u daumsoft -p ekdmathvmxm 211.115.77.67 /data3/daumsoft/HANL_DEAMON/lib /data3/jchern/HANL/src/$1
ncftpput -u daumsoft -p ekdmathvmxm 211.115.77.67 /data3/daumsoft/HANL_DEAMON/DICT/ /data3/jchern/HANL/RunEnv/CONFIG.HANL
ncftpput -u daumsoft -p ekdmathvmxm 211.115.77.67 /data3/daumsoft/HANL_DEAMON/ /data3/jchern/HANL/src/moran.h
