#!/bin/sh
# $Id: make-dist.sh,v 1.1 2006/04/24 02:16:03 nominam Exp $

distdir=dha
subdirs="RunEnv lib include misc"

## if dist is not defined, all the files and directories of 'subdirs' are insert to package
dist="RunEnv/Dict.skm RunEnv/Freq.skm RunEnv/KOR.DIC RunEnv/Space.dic RunEnv/Stop.ks RunEnv/Stop.skm RunEnv/User.ks RunEnv/User.skm RunEnv/alias.trie RunEnv/pre.trie include/dha.h lib/*.so lib/*.so.* lib/*.a misc/example.c misc/example.makefile"

## if you want to remove some file or directory from whole directory of package
# nodist="Makefile.in Makefile.am Makefile CVS"

## below codes need not modify

if [ ! -d src]; then
echo "you must run this script in root directory of project"
exit 1
fi

if [ -d "$distdir" ]; then
rm -rf "$distdir"
fi
mkdir "$distdir"

set -x
for subdir in $subdirs; do
mkdir "$distdir"/"$subdir"
done

dist=${dist:-null_value}
if [ "$dist" = "null_value" ]; then
for subdir in $subdirs; do
cp -rf "$subdir" "$distdir"/"$subdir"
done
else
for name in $dist; do
cp -rf "$name" "$distdir"/"$name"
done
fi

nodist=${nodist:-null_value}
if [ "$nodist" != "null_value" ]; then
for name in $nodist; do
rm -rf "$distdir"/"$name"
done
fi

if [ -f "$distdir".tar.gz ]; then
rm -rf "$distdir".tar.gz
fi

tar chof - "$distdir" | GZIP=--best gzip -c > "$distdir".tar.gz
rm -rf "$distdir"
