#!/bin/sh

ncftpput -u daumsoft -p ekdmathvmxm 211.115.77.67 //data3/daumsoft/HANL_DEAMON/DICT /data3/jchern/HANL/RunEnv/*

