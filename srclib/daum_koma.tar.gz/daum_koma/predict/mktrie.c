/**********************************************************************

	TRIE INDEX BUILDER

				Designed & Implemented by
					Cho, Young Hwan
					choyh@choyh.com
					1997. 4. 4
					2005. 5. 24

	Input : Any File, new line to TAB is keyword, data is until end of line
     	Output : TRIE Index File for the Data File
		
**********************************************************************/
#include	<stdio.h>
#include	<malloc.h>
#include        <fcntl.h>
#include        <sys/stat.h>

struct  node_type 
{
	char    Code;
	char	Str[30];
	int     Data_Start;
	int	Key_Start;
	int     index;
	struct  node_type	*ynext,*xnext;
} ;

typedef struct  node_type       Node_Type;

int	     		TAGTYPE = 0;
Node_Type       	*ROOT_NODE=NULL;
static Node_Type       *Index_List[1000000];
static int		Index_Seek[1000000];
int	     		NODE_NUM = 1;
int	     		NODE_SIZE = 1;
int	     		word_cnt = 1;
static  char   *Data_File;
static  char   *Data_File_Back;
static  long   Data_File_Size;
static  char   *Index_File;
static  long   Index_File_Size;

#define         EMPTY                   0
#define         XNEXT                   1
#define         YNEXT                   2
#define         COMPLETE                3
#define         MIDLE                   4

#define		End_of_Keyword_Mark			"\t"
#define		End_of_Record_Mark			"\n"
#define		COMMENT_MARK				'#'

main(ac,ag)
	int     ac;
	char    *ag[];
{ int	i;
	if(ac < 3) {
		fprintf(stderr,"���� :$%s �Է�ȭ�ϸ� ���ȭ�ϸ�\n",ag[0]);
		exit(0);
	}
	if(!strcmp(ag[1],ag[2]))
	{ 
		fprintf(stderr,"�Է�ȭ�ϰ� ���ȭ�ϸ��� ���� �� �����ϴ�.\n");
		exit(-1);
	}
	read_and_inmemory_trie_build(ag[1]);
	optimize_inmemory_trie(ROOT_NODE);
	numbering_inmemory_trie_nodes(ROOT_NODE,0);
	download_inmemory_trie_to_file(ag[2]);
}

int read_and_inmemory_trie_build(fn)
	char    *fn;
{ FILE  *fp,*fopen();
	char	record[10240];
	char	*data_start_position, *record_start_position, *record_end_position;
	int	rec_cnt=0;
	long	position, where, record_start, record_end, data_start;
	int   fd,what_first;
	struct stat   stbuf;
	int	new_data_start;
	int	first = 1;
	char	*data_only;
	int	i;


	/* upload Data File */
	/* after building Index File, The data file will be dumped at the rear of index file */
	if(stat(fn,&stbuf) == -1) {
		fprintf(stderr,"Data File [%s] ERROR!!!\n",fn);
		return(-1);
	}
	Data_File = (char *)malloc(stbuf.st_size+1);
	Data_File_Back = (char *)malloc(stbuf.st_size+1);
	Data_File_Size = (unsigned long)(stbuf.st_size+1);
	fd = open(fn,O_RDONLY);
	read(fd,Data_File,stbuf.st_size);
	strcpy(Data_File_Back,Data_File);
	close(fd);

	where = 0;	/* start of Data File, the data's fseek position */
	record_start_position = Data_File;
	data_only = Data_File_Back;
	while(1) {
		rec_cnt++;
		if(*record_start_position == COMMENT_MARK) {
			while(*record_start_position != '\n') record_start_position++;
			while(*record_start_position == '\n') record_start_position++;
		}

		data_start_position = (char*)strstr(record_start_position, End_of_Keyword_Mark);
		if(data_start_position == NULL) break;
		*data_start_position = '\0';
		data_start_position += strlen(End_of_Keyword_Mark);
		record_end_position = (char*)strstr(data_start_position, End_of_Record_Mark);
		if(record_end_position == NULL) break;
		*record_end_position = '\0';
		record_end_position += strlen(End_of_Record_Mark);
		record_start = (record_start_position - Data_File);
		data_start = (data_start_position - Data_File);
		strcpy(record,record_start_position);

	   new_data_start = data_only - Data_File_Back;
	   if(first)
	   {
		*data_only = '\0';
		data_only++;
		new_data_start = 1;
		first = 0;
	   }
	   strcpy(data_only,Data_File+data_start);
	   data_only += strlen(Data_File+data_start);
	   *data_only = '\0';
	   data_only++;

#ifdef	DEBUG
	   printf("new_data_start : %d\n",new_data_start);
#endif
	   if(insert_inmemory_trie(record, 0, new_data_start) != 0) break;
	   record_start_position = record_end_position;
	   while(*record_start_position == '\n') record_start_position++;
	}
	printf("DATA FILE SIZE = %d -> %d\n", Data_File_Size, (data_only - Data_File));
	Data_File_Size = (data_only - Data_File);
//	printf("DATA FILE = ");
//	for(i=0;i<Data_File_Size;i++) 
//	   if(Data_File[i] == '\0') printf("|"); else printf("%c", Data_File[i]);
//	printf("\n");
	return(0);
}

download_inmemory_trie_to_file(char    *fn)
{
	FILE  *fp,*fopen();
	int   	i,j;
	Node_Type     *cp;
	int		base,firsts=0,first_size=0;
	int		first_add[256];
	char		*data_only;
	unsigned char        size,add1,add2,add3,add4;
	unsigned long        yadd, dadd;
	int	data_start;

	fp = fopen(fn,"w");
	if(fp == NULL)
	{
		fprintf(stderr,"FILE WRITE ERROR [%s]\n",fn);
		exit(0);
	}
	for(i=0;i<256;i++) first_add[i] = 0;
	base = 256*4;

	for(cp=ROOT_NODE;cp != NULL;cp=cp->ynext) 		first_add[(unsigned char)cp->Str[0]] = Index_Seek[cp->index] + base;

	for(i=0;i<256;i++) if(first_add[i] != 0) printf("[%x] -> %d\n", i, first_add[i]);

	for(i=0;i<256;i++) 
	{
		yadd = first_add[i];
		add1 = (yadd & 0x00ff000000)>>24;
		add2 = (yadd & 0x0000ff0000)>>16;
		add3 = (yadd & 0x0000ff00)>>8;
		add4 =  yadd & 0x000000ff;
		fprintf(fp,"%c%c%c%c",add1,add2,add3,add4);
	}

	/****
	  data_only = Data_File;
	  for(i=1;i<NODE_NUM;i++) 
	  {
	  int	new_data_start;

	  new_data_start = data_only - Data_File;
	  cp = Index_List[i];
	  strcpy(data_only,Data_File+cp->Data_Start);
	  data_only += strlen(Data_File+cp->Data_Start);
	 *data_only = '\0';
	 data_only++;
	 cp->Data_Start = new_data_start;
	 }
	 ****/

	data_start = 256 * 4;
	for(i=1;i<NODE_NUM;i++) data_start += strlen(Index_List[i]->Str) + 9;

	for(i=1;i<NODE_NUM;i++) 
	{

		cp = Index_List[i];
		add1 = add2 = add3 = add4 = 0;
		if(cp->xnext != NULL) add1 = 0x80; else add1 = 0x00;
		if(cp->ynext != NULL) yadd = Index_Seek[cp->ynext->index] + base;
		else             yadd = 0;
		add1 = add1 | (yadd & 0x001f000000)>>24;
		add2 = (yadd & 0x0000ff0000)>>16;
		add3 = (yadd & 0x0000ff00)>>8;
		add4 =  yadd & 0x000000ff;
		fprintf(fp,"%c%c%c%c",add1,add2,add3,add4);

		if(cp->Data_Start != 0) dadd = data_start + cp->Data_Start;
		else		   dadd = 0;
		add1 = (dadd & 0x00ff000000)>>24;
		add2 = (dadd & 0x0000ff0000)>>16;
		add3 = (dadd & 0x0000ff00)>>8;
		add4 =  dadd & 0x000000ff;
		fprintf(fp,"%c%c%c%c",add1,add2,add3,add4);

		fprintf(fp,"%s%c",cp->Str,0);

		/**********
		  printf("\n");
		  printf("STRING  = [%s]\n", cp->Str);
		  if(cp->Data_Start != 0) printf("DATA    = [%s]\n", Data_File+cp->Data_Start);
		  else			   printf("DATA    = [NULL]\n");
		  printf("STRLEN  = [%d]\n", strlen(cp->Str));
		  printf("KStart  = [%d]\n", cp->Key_Start);
		  printf("DStart  = [%d]\n", cp->Data_Start);
		  if(cp->xnext != NULL) printf("XNEXT = YES\n");
		  else 		 printf("XNEXT = NO\n");
		  if(cp->ynext != NULL) printf("YNEXT = [%x]\n", Index_Seek[cp->ynext->index]+base);
		  else 		 printf("YNEXT = NULL\n");
		 ************/
	}

	for(i=0;i<Data_File_Size; i++) fprintf(fp,"%c", Data_File[i]);

	fclose(fp);
}

optimize_inmemory_trie(node)
	Node_Type       *node;
{ char	*ptr;

	if(node == NULL) return;
	ptr = node->Str;
	*ptr = node->Code;
	ptr++;
	while(1) {
	  if(node->xnext == NULL) break;
	  if(node->xnext->ynext != NULL) break;
	  if(node->Data_Start != 0) break;
	  *ptr = node->xnext->Code;
	  ptr++;
	  node->Data_Start = node->xnext->Data_Start;
	  node->Key_Start = node->xnext->Key_Start;
	  node->xnext = node->xnext->xnext;
	}
	*ptr = '\0';
        if(node->xnext != NULL) optimize_inmemory_trie(node->xnext);
	if(node->ynext != NULL) optimize_inmemory_trie(node->ynext);
}

numbering_inmemory_trie_nodes(node,depth)
int		depth;
Node_Type       *node;
{ int i;

        if(node == NULL) return;
        Index_List[NODE_NUM] = node;
	Index_Seek[NODE_NUM+1] = Index_Seek[NODE_NUM] + strlen(node->Str) + 9; /* 4 + 4 + 1 */
        node->index = NODE_NUM++;
#ifdef DEBUG
        printf("->[%s|%d]",node->Str,node->Data_Start);
#endif
        if(node->xnext != NULL) numbering_inmemory_trie_nodes(node->xnext,depth+1);
        if(node->ynext != NULL) {
#ifdef DEBUG
                printf("\n");
                for(i=0;i<depth;i++) printf("->{ # }");
#endif
                numbering_inmemory_trie_nodes(node->ynext,depth);
        }
}

print_tree(node,depth)
int		depth;
Node_Type       *node;
{ int i;

        if(node == NULL) return;
        printf("->[%c|%d]",node->Code,node->Data_Start);
        if(node->xnext != NULL) print_tree(node->xnext,depth+1);
        if(node->ynext != NULL) {
                printf("\n");
                for(i=0;i<depth;i++) printf("->{ # }");
                print_tree(node->ynext,depth);
        }
}

insert_inmemory_trie(key, key_start, data_start)
int     key_start, data_start;
char    *key;
{ Node_Type     *new,*cp,*get_node(),*match_trie();
  int	   posi=0,str_len,i,status;
  char	   rest[1024],*s;

// printf("INSERT[%s,(%d,%d)]\n", key, key_start, data_start);

	cp = match_trie(key,rest,&status);
	str_len = strlen(rest);
	s = &rest[0];
	if(str_len >= 1) {
		new = get_node();
		new->Code = *s; s++;
		if(cp == NULL) 
		{
			new->ynext = ROOT_NODE;
			ROOT_NODE = new;
		}
		else 
		{
			if(status == XNEXT)
				cp->xnext = new;
			if(status == YNEXT) 
			{
				new->ynext = cp->ynext;
				cp->ynext  = new;
			}
			if(status == MIDLE) 
			{
				new->ynext = cp->xnext;
				cp->xnext  = new;
			}
		}
		cp = new;
	}
	for(i=1;i<str_len;i++) {
		new = get_node();
		new->Code = *s; s++;
		cp->xnext = new;
		cp = new;
	}
	cp->Data_Start = data_start;
	cp->Key_Start  = key_start;
	return(0);
}

Node_Type       *match_trie(key,rest,status)
	char    *key,*rest;
	int     *status;
{ Node_Type     *cp,*cp_1;
	char 		newc,oldc, *s;
	int	   	midle_chance=1;

	cp   = ROOT_NODE;
	cp_1 = NULL;
	*status = YNEXT;
	s = key;
	if(cp == NULL) { strcpy(rest,s);
		*status = EMPTY;
		return(NULL); }
		while(1) {
			if(*s == '\0')
			{ strcpy(rest,"");
				*status = COMPLETE;
				return(cp_1);
			}
			if(cp->Code == *s)  {
				s++;
				if(*s == '\0')  {
					strcpy(rest,"");
					*status = COMPLETE;
					return(cp);
				}
				cp_1 = cp;
				cp = cp->xnext;
				if(cp == NULL) {
					strcpy(rest,s);
					*status = XNEXT;
					return(cp_1);
				}
				midle_chance=1;
				continue;
			}

			if((midle_chance == 1) && (*s < cp->Code)) {
				strcpy(rest,s);
				*status = MIDLE;
				return(cp_1);
			}

			if(cp->ynext == NULL) {
				strcpy(rest,s);
				*status = YNEXT;
				return(cp);
			}

			if((cp->ynext != NULL) && (*s < cp->ynext->Code)) {
				strcpy(rest,s);
				*status = YNEXT;
				return(cp);
			}
			cp_1 = cp;
			cp   = cp->ynext;
			midle_chance=0;
		}
}

Node_Type       *get_node()
{ Node_Type     *new;

	NODE_SIZE++;
	new = (Node_Type *)malloc(sizeof(Node_Type));
	if(new == NULL) {
	  fprintf(stderr," NO MORE SPACE !!! EXIT\n");
	  exit(0);
	}
	new->Code = 0;
	new->Data_Start  = 0;
	new->Key_Start  = 0;
	new->xnext = new->ynext = NULL;
	return(new);
}

