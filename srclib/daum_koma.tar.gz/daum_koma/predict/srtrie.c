#include        <stdio.h>
#include        <string.h>
#include        <malloc.h>
#include        <ctype.h>
#include        <unistd.h>
#include        <sys/stat.h>
#include        <fcntl.h>

/* ������ ��°�� ������ ������ open_sdict���� ȭ��ũ�� ��ŭ ��� */
static  unsigned char   *Ext_Trie;     /* �ý��� ���� ���Ǻκ� */
static  unsigned long   Ext_Trie_Size;
int 	USE_TRIE=0;

/* �ý��� ������ ù���ڸ� �����ϱ� ���� ����Ÿ ���� ����                */
static unsigned long TRIE_FIRST_CHAR_ADDR[256];

main(int argv, char  * argc[])
{
	char	keyword[1024], record[1024];

	//open_trie("pre.trie");
	open_trie(argc[1]);

	while(1) 
	{
		printf("WORD : ");
		if(scanf("%s", keyword) != 1) break;
		search_trie(keyword, record);
		printf("RECORD = [%s]\n", record);
	}
}

int     search_trie(char *keyword, char	*result)
{
	unsigned char *prt, key[1024],found[1024];
	int   size,i,length=0;
	unsigned int pointer;
	unsigned long address, ynext, get_node();

	if(USE_TRIE == 0) 
		return(0);

	*result = '\0';
	prt = keyword;
	size = strlen(keyword);
	address = TRIE_FIRST_CHAR_ADDR[*prt];

	if(address == 0) 
		return(0);

	while(1) 
	{
		address = get_node(address, key, &pointer, &ynext);
#ifdef	DEBUG
		printf("POINTER:%d\n",address);
#endif

		for(i = 0; key[i]!='\0'; i++)
		{
			if(*prt != key[i]) 
				break;

			prt++;
			length++;
		}	

		if(i == 0) 
		{
			if(ynext!=0)    address = ynext;
			else      	break;

			continue;
		}

		if(key[i] != '\0') break;

		if(pointer != 0) 
		{
			char	tmp[1024];

			strncpy(tmp, keyword, length);
			tmp[length] = '\0';
			sprintf(result, "%s %s", tmp, Ext_Trie+pointer);
		}

		if(pointer != 0 && *prt == '\0') 
		{
			sprintf(result, "%s %s", keyword, Ext_Trie+pointer);
		}

		if(*prt == '\0') break;

		if(address == 0) break;
	}
	return(1);
}

unsigned long   get_node(unsigned long address,unsigned char *index,unsigned int *pointer,unsigned long *ynext)
{
	int   size;
	unsigned long next_address;
	unsigned char *node_start;
	unsigned int  a,b;
	int   i;

	*ynext = 0; 
	*pointer = 0;

	if(address >= Ext_Trie_Size)
		return(0);

	node_start = Ext_Trie + address;

	*ynext =  (((*(node_start+0))&0x7f) << 24);
	*ynext += (((*(node_start+1))&0xff) << 16);
	*ynext += (((*(node_start+2))&0xff) << 8);
	*ynext += ( (*(node_start+3))&0xff);

	*pointer =  (((*(node_start+4))&0x7f) << 24);
	*pointer += (((*(node_start+5))&0xff) << 16);
	*pointer += (((*(node_start+6))&0xff) << 8);
	*pointer += ( (*(node_start+7))&0xff);
	strcpy(index,node_start+8);

	if(0x80 & *node_start)
		next_address = address + strlen(index) + 9;
	else
		next_address = 0;

	return(next_address);
}

int open_trie(char *fn)
{
	FILE  *fp,*fopen();
	unsigned int  i,j,tags,firsts,first_size;
	unsigned char add1,add2,add3,add4, info1,info2,info3,info4,info5;
	struct stat   stbuf;
	int	fd,what_first;

	if(stat(fn,&stbuf) == -1) 
	{
		USE_TRIE = 0;
		return(-1);
	}

	Ext_Trie = (unsigned char *)malloc(stbuf.st_size+1);
	Ext_Trie_Size = (unsigned long)(stbuf.st_size+1);
	fd = open(fn,O_RDONLY);
	read(fd,Ext_Trie,stbuf.st_size);
	close(fd);

	if((fp = fopen(fn,"r"))== NULL) 
	{
		USE_TRIE = 0;
		return(-1);
	}

	for(i = 0; i < 256; i++) 
	{
		add1 = (unsigned int)fgetc(fp);        /* �� ���ڷ� �����ϴ� ����� �ּ�-1 */
		add2 = (unsigned int)fgetc(fp);        /* �� ���ڷ� �����ϴ� ����� �ּ�-2 */
		add3 = (unsigned int)fgetc(fp);        /* �� ���ڷ� �����ϴ� ����� �ּ�-3 */
		add4 = (unsigned int)fgetc(fp);        /* �� ���ڷ� �����ϴ� ����� �ּ�-4 */
		TRIE_FIRST_CHAR_ADDR[i] = (unsigned long)(((add1&0x00ff)<<24)|((add2&0x00ff)<<16)|((add3&0x00ff)<<8)|(add4&0x00ff));
	}
	fclose(fp);

	for(i = 0; i < 256; i++)
	{
		if(TRIE_FIRST_CHAR_ADDR[i] != 0)
		{
			printf("[%x](%d) -> %d\n", i,i, TRIE_FIRST_CHAR_ADDR[i]);
		}
	}

	USE_TRIE = 1;
	return(0);
}
