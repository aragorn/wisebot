/**********************************************************************
	TRIE INDEX BUILDER

				Designed & Implemented by
					Cho, Young Hwan
					choyh@choyh.com
					1997. 4. 4
					2005. 5. 24
				Modified by 
					Kim, Eung Gyun
					jchern@daumcorp.com
					2005. 8. 24

	Input : Any File, new line to TAB is keyword, data is until end of line
     	Output : TRIE Index File for the Data File
**********************************************************************/
#include	"trie.h"

int main(int argc, char * argv[])
{
	read_and_insert(argv[1]);
	optimize(ROOT);
	numbering(ROOT, 0);
	writing(argv[2]);
	return 0;
}

int insert(char * key, int data_start)
{
	   NODE    *nnode;
	   NODE    *cnode;
	   NODE	*make_node();
	   NODE	*match_trie();

	   int	i = 0;
	   int	status;
	   int	rest_size = 0;
	   char	*pRest;
	   char	rest[1024];

	   cnode = match_trie(key, rest, &status);
	   rest_size = strlen(rest);
	   pRest = &rest[0];

	   if(rest_size >= 1)
	   {
		   nnode = make_node();
		   nnode->code = *pRest;
		   pRest++;


		   switch(status)
		   {
			   case EMPTY :
				   nnode->ynext = NULL;
				   ROOT = nnode;
				   break;
			   case XNEXT :
				   cnode->xnext  = nnode;
				   break;
			   case YNEXT :
				   nnode->ynext = cnode->ynext;
				   cnode->ynext = nnode;
				   break;
			   case MIDDLE :
				   nnode->ynext = cnode->xnext;
				   cnode->xnext = nnode;
				   break;

		   }
		   cnode = nnode;
	   }
	   for(i = 1; i < rest_size; i++)
	   {
		   nnode = make_node();
		   nnode->code = *pRest;
		   pRest++;
		   cnode->xnext = nnode;
		   cnode = nnode;

	   }
	   cnode->Data_Start = data_start;
	   return 0;


}
NODE	*match_trie(char * key,char * rest, int *status)
{
	NODE	*cnode;
	NODE	*tnode;
	char	*sp;
	int	middle = 1;


	cnode = ROOT;
	tnode = NULL;
	sp = key;
	*status = YNEXT;

	if(cnode == NULL)
	{
		strcpy(rest, key);
		*status = EMPTY;
		return NULL;
	}

	while(RUN)
	{
		if(*sp == '\0')
		{
			rest[0] = '\0';
			*status = COMPLETE;
			return tnode;
		}

		if(cnode->code == *sp)
		{
			sp++;
			if(*sp == '\0')
			{
				rest[0] = '\0';
				*status = COMPLETE;
				return cnode;
			}
			else
			{
				tnode = cnode;
				cnode = cnode->xnext;

				if(cnode == NULL)
				{
					strcpy(rest,sp);
					*status = XNEXT;
					return tnode;
				}
				else
				{
					middle = 1;
					continue;
				}
			}
		}
		if(middle  == 1 && (*sp < cnode->code))
		{
			strcpy(rest,sp);
			*status = MIDDLE;
			return tnode;
		}

		if(cnode->ynext == NULL)
		{
			strcpy(rest,sp);
			*status = YNEXT;
			return cnode;
		}

		if((cnode->ynext != NULL) && (*sp < cnode->ynext->code))
		{
			strcpy(rest,sp);
			*status = YNEXT;
			return cnode;
		}
		tnode = cnode;
		cnode = cnode->ynext;
		middle = 0;
	}

}

NODE	*make_node()
{
	NODE * node;

	node = (NODE*)malloc(sizeof(NODE));
	if(node == NULL)
	{
		fprintf(stderr," NO MORE SPACE !!! EXIT\n");
		exit(0);
	}
	node->code = 0;
	node->index = 0;
	node->Data_Start = 0;
	node->xnext = node->ynext = NULL;
	return node;
}


int	read_and_insert(char * fn)
{
	int     i = 0;
	int     j = 0;
	int		fd = 0;
	int     kidx = 0;
	int     vidx = 0;
	int     didx = 0;
	int     key_data = 1;
	int		what_first = 0;
	int		new_data_start = 0;
	char    key[1024];
	char    value[1024];
	FILE	*fp;
	struct stat   stbuf;


	if(stat(fn,&stbuf) == -1)
	{
		fprintf(stderr,"Data File [%s] ERROR!!!\n",fn);
		return -1;
	}

	Data_File = (char *)malloc(stbuf.st_size+1);
	Data_File_Size = (unsigned long)(stbuf.st_size+1);
	fd = open(fn,O_RDONLY);
	read(fd,Data_File,stbuf.st_size);
	close(fd);

	while(1)
	{
		for(i = 0; i < Data_File_Size; i++)
		{
			if(Data_File[i] == '\t')
			{
				key[kidx++] = '\0';
				key_data = 0;
				continue;
			}
			if(Data_File[i] == '\n')
			{
				value[vidx++] = '\0';
				if(didx == 0)
				{
					didx = 1;
					Data_File[0] = '\0';
				}
				new_data_start = didx;
				for(j = 0; j < vidx; j++)
				{
					Data_File[didx++] = value[j];
				}
				Data_File[didx++] = '\0';

				if(key[0] == '\0')      return (0);
				if(insert(key, new_data_start) != 0)
				{
					break;
				}

				key_data = 1;
				kidx = 0;
				vidx = 0;
				continue;
			}
			if(key_data == 1)
				key[kidx++] = Data_File[i];
			else    
				value[vidx++] = Data_File[i];
		}
		break;
	}
	return 0;

}
int	optimize(NODE * node)
{
	char	*ptr;
	if(node == NULL)		return -1;

	ptr = node->Str;
	*ptr = node->code;
	ptr++;

	while(1)
	{
		if(node->xnext != NULL && node->xnext->ynext == NULL && node->Data_Start == 0)
		{
			*ptr = node->xnext->code;
			ptr++;
			node->Data_Start = node->xnext->Data_Start;
			node->xnext = node->xnext->xnext;//A->B->C�� A->C ��
		}
		else
		{
			break;
		}
	}
	*ptr = '\0';

	if(node->xnext != NULL)
		optimize(node->xnext);
	if(node->ynext != NULL)
		optimize(node->ynext);


}

int	numbering(NODE *node,int depth)
{
	int i = 0;

	if(node == NULL)		return -1;

	Index_List[NODE_NUM] = node;
	Index_Seek[NODE_NUM+1] = Index_Seek[NODE_NUM] + strlen(node->Str) + NODE_SIZE;
	node->index = NODE_NUM;

	NODE_NUM++;

	if(node->xnext != NULL)
	{
		numbering(node->xnext,depth+1);
	}

	if(node->ynext != NULL)
	{
		numbering(node->ynext,depth);
	}



}
int	writing(char * fn)
{
	FILE 	*fp;
	int	i;
	int	j;
	int	data_start;
	int	base,firsts=0,first_size=0;
	int	first_add[FIRST_NODE_COUNT];
	char	*data_only;
	unsigned char        size, add1, add2, add3, add4, add5;
	unsigned long        yadd, dadd;
	NODE     *cp;

	fp = fopen(fn,"w");

	if(fp == NULL)
	{  
		fprintf(stderr,"FILE WRITE ERROR [%s]\n",fn);
		exit(0);
	}

	for(i = 0; i < FIRST_NODE_COUNT; i++)		first_add[i] = 0;
	

	base = FIRST_NODE_COUNT*4;

	for (cp=ROOT;cp != NULL;cp=cp->ynext)		first_add[(unsigned char)cp->Str[0]] = Index_Seek[cp->index] + base;

	for (i = 0;i < FIRST_NODE_COUNT; i++) 
	{
		yadd = first_add[i];
		add1 = (yadd & 0x00ff000000)>>24;
		add2 = (yadd & 0x0000ff0000)>>16;
		add3 = (yadd & 0x0000ff00)>>8;
		add4 =  yadd & 0x000000ff;
		fprintf(fp,"%c%c%c%c",add1,add2,add3,add4);
	}

	data_start = FIRST_NODE_COUNT * 4;
	
	for (i = 1 ; i < NODE_NUM; i++) 		data_start += strlen(Index_List[i]->Str) + NODE_SIZE;

	for (i = 1; i < NODE_NUM; i++) 
	{

		cp = Index_List[i];
		add1 = add2 = add3 = add4 = add5 = 0;
		
		if (cp->xnext != NULL)		add1 = 0x80;
		else						add1 = 0x00;

		if (cp->ynext != NULL)		yadd = Index_Seek[cp->ynext->index] + base;
		else      					yadd = 0;
		
		add1 = add1 | (yadd & 0x7f00000000)>>32;
		add2 = (yadd & 0x00ff000000)>>24;
		add3 = (yadd & 0x0000ff0000)>>16;
		add4 = (yadd & 0x000000ff00)>>8;
		add5 =  yadd & 0x00000000ff;
		fprintf(fp,"%c%c%c%c%c",add1,add2,add3,add4, add5);

		if (cp->Data_Start != 0) 	dadd = data_start + cp->Data_Start;
		else    					dadd = 0;

		add1 = (dadd & 0x00ff000000)>>24;
		add2 = (dadd & 0x0000ff0000)>>16;
		add3 = (dadd & 0x0000ff00)>>8;
		add4 =  dadd & 0x000000ff;
		fprintf(fp,"%c%c%c%c",add1,add2,add3,add4);
		fprintf(fp,"%s%c",cp->Str,0);

	}

	for (i=0;i<Data_File_Size; i++)
	{
		fprintf(fp,"%c", Data_File[i]);
	}

	fclose(fp);


}
