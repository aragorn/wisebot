#include        <stdio.h>
#include        <string.h>
#include        <malloc.h>
#include        <ctype.h>
#include        <unistd.h>
#include        <sys/stat.h>
#include        <fcntl.h>

/* ������ ��°�� ������ ������ open_sdict���� ȭ��ũ�� ��ŭ ��� */
static  unsigned char   *Ext_Trie;     /* �ý��� ���� ���Ǻκ� */
static  unsigned long   Ext_Trie_Size;
int 	USE_TRIE=0;

/* �ý��� ������ ù���ڸ� �����ϱ� ���� ����Ÿ ���� ����                */
static unsigned long TRIE_FIRST_CHAR_ADDR[256];

main()
{
	char	keyword[1024], record[1024];

	//open_trie("pre.trie");
	open_trie("re");
	
	while(1) 
	{
		printf("WORD : ");
		if(scanf("%s", keyword) != 1) break;
		search_trie(keyword, record);
		printf("RECORD = [%s]\n", record);
	}
}

int     search_trie(char *keyword, char	*result)
{
	unsigned char *prt, key[1024],found[1024];
	int   size,i,length=0;
	unsigned int pointer;
	unsigned long address, ynext, get_node();
	
        if(USE_TRIE == 0) 
		return(0);
	
	*result = '\0';
        prt = keyword;
        size = strlen(keyword);
        address = TRIE_FIRST_CHAR_ADDR[*prt];

        if(address == 0) 
		return(0);

        while(1) 
	{
		address = get_node(address, key, &pointer, &ynext);
#ifdef	DEBUG
		printf("pointer:%d\n",address);
#endif

		for(i = 0; key[i]!='\0'; i++)
		{
			if(*prt != key[i]) 
				break;

			prt++;
			length++;
		}	

		if(i == 0) 
		{
			if(ynext!=0)    address = ynext;
			else      	break;

			continue;
		}

		if(key[i] != '\0') break;

		if(pointer != 0) 
		{
			char	tmp[1024];

			strncpy(tmp, keyword, length);
			tmp[length] = '\0';
			sprintf(result, "%s %s", tmp, Ext_Trie+pointer);
		}

		if(pointer != 0 && *prt == '\0') 
		{
			sprintf(result, "%s %s", keyword, Ext_Trie+pointer);
		}

		if(*prt == '\0') break;

		if(address == 0) break;
	}
	return(1);
}

unsigned long   get_node(unsigned long address,unsigned char *index,unsigned int *pointer,unsigned long *ynext)
{
	int   size;
	unsigned long next_address;
	unsigned char *node_start;
	unsigned int  a,b;
	char	temp[16];
	int	itemp;
	int   i;

	*ynext = 0; 
	*pointer = 0;

	if(address >= Ext_Trie_Size)
		return(0);

	node_start = Ext_Trie + address;


	strncpy(temp,&node_start[1],5);
	temp[4] = '\0';
	itemp = atoi(temp);
	memcpy(ynext,&itemp, 4);
	strncpy(temp,&node_start[5],4);
	temp[5] = '\0';
	itemp = atoi(temp);
	memcpy(pointer,&itemp,4);

	strcpy(index,node_start+9);

	if(*node_start == 'Y')
		next_address = address + strlen(index) + 10;
	else
		next_address = 0;

	return(next_address);
}

int open_trie(char *fn)
{
	FILE  *fp,*fopen();
	unsigned int  i,j,tags,firsts,first_size;
	unsigned char add1,add2,add3,add4, info1,info2,info3,info4,info5;
	struct stat   stbuf;
	int	fd,what_first;
	char	temp[8];

	if(stat(fn,&stbuf) == -1) 
	{
		USE_TRIE = 0;
		return(-1);
	}

	Ext_Trie = (unsigned char *)malloc(stbuf.st_size+1);
	Ext_Trie_Size = (unsigned long)(stbuf.st_size+1);
	fd = open(fn,O_RDONLY);
	read(fd,Ext_Trie,stbuf.st_size);
	close(fd);

	if((fp = fopen(fn,"r"))== NULL) 
	{
		USE_TRIE = 0;
		return(-1);
	}
	for(i = 0; i < 256; i++) 
	{
		temp[0] = fgetc(fp);temp[1] = fgetc(fp);temp[2] = fgetc(fp);temp[3] = fgetc(fp);temp[4] = '\0';
		TRIE_FIRST_CHAR_ADDR[i] =atoi(temp);
	}
	fclose(fp);

	for(i = 0; i < 256; i++)
	{
		if(TRIE_FIRST_CHAR_ADDR[i] != 0)
		{
			printf("[%x](%d) -> %d\n", i,i, TRIE_FIRST_CHAR_ADDR[i]);
		}
	}

	USE_TRIE = 1;
	return(0);
}
