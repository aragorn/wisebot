#ifndef __TRIE_H__
#define __TRIE_H__
#define     MAXSIZE 	1000000
#define     EMPTY       0
#define     XNEXT       1
#define     YNEXT       2
#define     COMPLETE    3
#define     MIDDLE      4
#define     FIRST_NODE_COUNT    256
#define     RUN         1
#ifdef      SIZE_32
#define     NODE_SIZE       10 /*xnext + ynext + null */
#else
#define     NODE_SIZE       9 /*xnext + ynext + null */
#endif

typedef struct NODE_
{
	int		index;
	int		Data_Start;
	char    code;
	char    Str[32];
	struct  NODE_   *xnext;
	struct  NODE_   *ynext;
}NODE;

NODE    *ROOT =  NULL;
int     USE_TRIE=0;
int TAGTYPE = 0;
int word_cnt = 1;
int NODE_NUM = 1;
static  NODE    *Index_List[MAXSIZE];
static  int Index_Seek[MAXSIZE];

/* ������ ��°�� ������ ������ open_sdict���� ȭ��ũ�� ��ŭ ��� */
static  unsigned char   *Ext_Trie;     /* �ý��� ���� ���Ǻκ� */
static  unsigned long   Ext_Trie_Size;
static  char    *Data_File;
static  long    Data_File_Size;
static  char    *Index_File;
static  long    Index_File_Size;
#endif

