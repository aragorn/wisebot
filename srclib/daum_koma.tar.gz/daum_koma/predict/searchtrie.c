/**********************************************************************
  TRIE INDEX BUILDER

  Designed & Implemented by
  Cho, Young Hwan
  choyh@choyh.com
  1997. 4. 4
  2005. 5. 24
  Modified by 
  Kim, Eung Gyun
  jchern@daumcorp.com
  2005. 8. 24

Input : Any File, new line to TAB is keyword, data is until end of line
Output : TRIE Index File for the Data File
 **********************************************************************/
#include 	<stdlib.h>
#include    <unistd.h>
#include 	<string.h>
#include    <stdio.h>
#include    <malloc.h>
#include    <fcntl.h>
#include    <sys/stat.h>
#include 	"trie.h"


/* �ý��� ������ ù���ڸ� �����ϱ� ���� ����Ÿ ���� ����                */
static unsigned long TRIE_FIRST_CHAR_ADDR[FIRST_NODE_COUNT];



int     search_trie(char *keyword, char	*result)
{
	int	i;
	int	size;
	int	length=0;
	char	tmp[1024];
	unsigned char	*prt;
	unsigned char	key[1024];
	unsigned int pointer;
	unsigned long address, ynext, get_node();

	if(USE_TRIE == 0) 
		return(0);

	*result = '\0';
	prt = keyword;
	size = strlen(keyword);

	address = TRIE_FIRST_CHAR_ADDR[*prt];//���� �ּ� ���

	if (address == 0)
		return(0);

	for(;;)
	{
		address = get_node(address, key, &pointer, &ynext);

		for(i = 0; key[i]!='\0'; i++)
		{
			if(*prt != key[i]) 		
				break;

			prt++;
			length++;
		}	

		if(i == 0) 
		{
			if(ynext!=0) 	
				address = ynext;
			else	
				break;

			continue;
		}

		if(key[i] != '\0')
		{
			strncpy(tmp, keyword, length);
			tmp[length] = '\0';
			sprintf(result, "�κи�ġ:%s\t%s", tmp, Ext_Trie+pointer);
			break;
		}

		if(pointer != 0) 
		{
			strncpy(tmp, keyword, length);
			tmp[length] = '\0';
			sprintf(result, "������ġ:%s\t%s", tmp, Ext_Trie+pointer);
		}

		if(pointer != 0 && *prt == '\0')
			sprintf(result, "������ġ:%s\t%s", keyword, Ext_Trie+pointer);

		if(*prt == '\0' || address == 0)		
			break;
	}
	return(1);
}

unsigned long   get_node(unsigned long address,unsigned char *key,unsigned int *pointer,unsigned long *ynext)
{
	unsigned long next_address;
	unsigned char *node_start;

	*ynext = 0;
	*pointer = 0;

	if (address >= Ext_Trie_Size)		return(0);

	node_start = Ext_Trie + address;


	*ynext += (((*(node_start+0))&0x1f) << 24);
	*ynext += (((*(node_start+1))&0xff) << 16); 
	*ynext += (((*(node_start+2))&0xff) << 8 );
	*ynext += ( (*(node_start+3))&0xff);
	*pointer =  (((*(node_start+4))&0xff) << 24);
	*pointer += (((*(node_start+5))&0xff) << 16);
	*pointer += (((*(node_start+6))&0xff) << 8);
	*pointer += ( (*(node_start+7))&0xff);

	strcpy(key,node_start+8);


	if (0x80 & *node_start)
		next_address = address + strlen(key) + NODE_SIZE;
	else	
		next_address = 0;

	return(next_address);
}

int open_trie(char *fn)
{
	FILE  *fp,*fopen();
	unsigned int  i;
	unsigned char add1,add2,add3,add4;
	struct stat   stbuf;
	int	fd;

	if(stat(fn,&stbuf) == -1) 
	{
		USE_TRIE = 0;
		return(-1);
	}

	Ext_Trie = (unsigned char *)malloc(stbuf.st_size+1);
	Ext_Trie_Size = (unsigned long)(stbuf.st_size+1);
	fd = open(fn,O_RDONLY);
	read(fd,Ext_Trie,stbuf.st_size);
	close(fd);

	if((fp = fopen(fn,"r"))== NULL) 
	{
		USE_TRIE = 0;
		return(-1);
	}
	for(i = 0; i < FIRST_NODE_COUNT; i++) 
	{
		add1 = (unsigned int)fgetc(fp);/*�ױ��ڷν����ϴ� ������ּ�-1*/
		add2 = (unsigned int)fgetc(fp);/*�ױ��ڷν����ϴ� ������ּ�-2*/
		add3 = (unsigned int)fgetc(fp);/*�ױ��ڷν����ϴ� ������ּ�-3*/
		add4 = (unsigned int)fgetc(fp);/*�ױ��ڷν����ϴ� ������ּ�-4*/
		TRIE_FIRST_CHAR_ADDR[i] = (unsigned long)(((add1&0x00ff)<<24)|((add2&0x00ff)<<16)|((add3&0x00ff)<<8)|(add4&0x00ff));
	}
	fclose(fp);
#ifdef	DEBUG
	for(i = 0; i < FIRST_NODE_COUNT; i++)
	{
		if(TRIE_FIRST_CHAR_ADDR[i] != 0)
		{
			printf("[%x](%d) -> %d\n", i,i, TRIE_FIRST_CHAR_ADDR[i]);
		}
	}
#endif	
	USE_TRIE = 1;
	return(0);
}

int	main(int argc, char * argv[])
{
	char	keyword[1024];
	char	record[1024];

	if(argc != 2)
	{
		printf("%s Ʈ����ȭ�ϸ�\n", argv[0]);
		return 0;
	}
	open_trie(argv[1]);

	for(;;)
	{
		printf("WORD : ");
		if(scanf("%s", keyword) != 1)			break;
		search_trie(keyword, record);
		printf("RECORD = [%s]\n", record);
	}
	return 0;
}
