/**********************************************************************

  TRIE INDEX BUILDER

  Designed & Implemented by
  Cho, Young Hwan
  choyh@choyh.com
  1997. 4. 4
  2005. 5. 24

Input : Any File, new line to TAB is keyword, data is until end of line
Output : TRIE Index File for the Data File

 **********************************************************************/
#include	<stdio.h>
#include	<malloc.h>
#include        <fcntl.h>
#include        <sys/stat.h>
#define		MAXSIZE	1000000
typedef struct  node_type 
{
	char    Code;
	char	Str[30];
	int     Data_Start;
	int	Key_Start;
	int     index;
	struct  node_type	*ynext;
	struct	node_type	*xnext;
}Node_Type;

//typedef struct  node_type       Node_Type;

int	     		TAGTYPE = 0;
Node_Type       	*ROOT_NODE=NULL;
static Node_Type       *Index_List[MAXSIZE];
static int		Index_Seek[MAXSIZE];
int	     		NODE_NUM = 1;
int	     		NODE_SIZE = 1;
int	     		word_cnt = 1;
static  char   *Data_File;
static  long   Data_File_Size;
static  char   *Index_File;
static  long   Index_File_Size;

#define         EMPTY                   0
#define         XNEXT                   1
#define         YNEXT                   2
#define         COMPLETE                3
#define         MIDLE                   4

#define		End_of_Keyword_Mark			"\t"
#define		End_of_Record_Mark			"\n"
#define		COMMENT_MARK				'#'

int main(int ac, char *ag[])
{
	int i;

	if(ac < 3) 
	{
		fprintf(stderr,"���� :$%s �Է�ȭ�ϸ� ���ȭ�ϸ�\n",ag[0]);
		exit(0);
	}

	if(!strcmp(ag[1],ag[2]))
	{ 
		fprintf(stderr,"�Է�ȭ�ϰ� ���ȭ�ϸ��� ���� �� �����ϴ�.\n");
		exit(-1);
	}
	read_and_inmemory_trie_build(ag[1]);
	optimize_inmemory_trie(ROOT_NODE);
	numbering_inmemory_trie_nodes(ROOT_NODE,0);
	download_inmemory_trie_to_file(ag[2]);
}

/* {(Key,Data)} -> Key, Data Start index �� inmemory TRIE�� �����ϴµ�,
 * Data �鸸 ���� �տ������� ü���������� Data_File�� ����� */

int read_and_inmemory_trie_build(char *fn)
{
	FILE  *fp,*fopen();
	struct stat   stbuf;
	int	i;
	int	j;
	int   fd,what_first;
	char	key[1024];
	char	value[1024];
	int	kidx = 0;
	int	vidx = 0;
	int	didx = 0;
	int	key_data = 1;int	new_data_start;


	/* upload Data File */
	/* after building Index File, The data file will be dumped at the rear of index file */
	if(stat(fn,&stbuf) == -1) 
	{
		fprintf(stderr,"Data File [%s] ERROR!!!\n",fn);
		return(-1);
	}
	Data_File = (char *)malloc(stbuf.st_size+1);
	Data_File_Size = (unsigned long)(stbuf.st_size+1);
	fd = open(fn,O_RDONLY);
	read(fd,Data_File,stbuf.st_size);
	close(fd);

	while(1)
	{
		for(i = 0; i < Data_File_Size; i++)
		{
			if(Data_File[i] == '\t')
			{	
				key[kidx++] = '\0';
				key_data = 0;
				continue;
			}
			if(Data_File[i] == '\n')
			{
				value[vidx++] = '\0';
				printf("%s:%s\n",key,value);
				if(didx == 0)
				{
					didx = 1;
					Data_File[0] = '\0';
				}
				new_data_start = didx;
				for(j = 0; j < vidx; j++)
				{
					Data_File[didx++] = value[j];
				}
				Data_File[didx++] = '\0';
			
				if(key[0] == '\0')	return (0);
				if(insert_inmemory_trie(key, 0, new_data_start) != 0)
				{
					break;
				}

				key_data = 1;				
				kidx = 0;
				vidx = 0;
				continue;
			}
			if(key_data == 1)	key[kidx++] = Data_File[i];
			else			value[vidx++] = Data_File[i];
		}
	}
	return(0);
}

download_inmemory_trie_to_file(char    *fn)
{
	int   	i = 0;
	int	j = 0;
	int	base = 0;
	int	firsts = 0;
	int	first_size = 0;
	int	first_add[256];
	int	data_start;
	char	*data_only;
	Node_Type     *cp;
	unsigned char        size, add1, add2, add3, add4;
	unsigned long        yadd, dadd;
	FILE  *fp,*fopen();

	fp = fopen(fn,"w");

	if(fp == NULL)
	{
		fprintf(stderr,"FILE WRITE ERROR [%s]\n",fn);
		exit(0);
	}

	for(i = 0; i < 256; i++)
		first_add[i] = 0;

	base = 256*4;

	for(cp = ROOT_NODE; cp != NULL; cp = cp->ynext)		
		first_add[(unsigned char)cp->Str[0]] = Index_Seek[cp->index] + base;
#ifdef	DEBUG
	for(i = 0; i < 256; i++)if(first_add[i] != 0) 
		printf("[%x] -> %d\n", i, first_add[i]);
#endif

	for(i = 0; i < 256; i++) 
	{
		fprintf(fp,"%04d",first_add[i]);
	}
	data_start = 256 * 4;// ������ ���ڿ��� ������ �� + first_add�� ����(256*4 == 1024)

	for(i = 1; i < NODE_NUM; i++)
	{
		data_start += strlen(Index_List[i]->Str) + 10;	
	}


	for(i = 1; i < NODE_NUM; i++) 
	{
		cp = Index_List[i];

		if(cp->xnext == NULL)
		{
			fprintf(fp,"N");
		}
		else 
		{
			fprintf(fp,"Y");
		}

		if(cp->ynext == NULL)
			yadd = 0;
		else
			yadd = Index_Seek[cp->ynext->index] + base;


		fprintf(fp,"(%04d)",yadd);
		if(cp->Data_Start == 0)
		{
			dadd = 0;
		}
		else
		{
			dadd = data_start + cp->Data_Start;
		}

		fprintf(fp,"[%04d]",dadd);
		fprintf(fp,"{%s%c}",cp->Str,0);

	}
	for(i = 0; i < Data_File_Size; i++)
	{
		fprintf(fp,"%c", Data_File[i]);
	}
	fclose(fp);
}

optimize_inmemory_trie(Node_Type *node)
{
	char	*ptr;

	if(node == NULL)
	{
		return;
	}

	ptr = node->Str;
	*ptr = node->Code;
	ptr++;

	while(1) 
	{
		if(node->xnext == NULL) 
			break;

		if(node->xnext->ynext != NULL) 
			break;

		if(node->Data_Start != 0) 
			break;

		*ptr = node->xnext->Code;
		ptr++;
		node->Data_Start = node->xnext->Data_Start;
		node->Key_Start = node->xnext->Key_Start;
		node->xnext = node->xnext->xnext;
	}

	*ptr = '\0';
	if(node->xnext != NULL)
		optimize_inmemory_trie(node->xnext);


	if(node->ynext != NULL)
		optimize_inmemory_trie(node->ynext);
}

numbering_inmemory_trie_nodes(Node_Type    *node,int depth)
{
	int i;
	if(node == NULL)
	{
		return;
	}
	Index_List[NODE_NUM] = node;
	Index_Seek[NODE_NUM+1] = Index_Seek[NODE_NUM] + strlen(node->Str) + 10; /* 4 + 5 + 1 */ 	/*xnext+ynext+NULL*/
	node->index = NODE_NUM;
	NODE_NUM++;
#ifdef DEBUG
	printf("->[%s|%d]",node->Str,node->Data_Start);
#endif
	if(node->xnext != NULL)
	{
		numbering_inmemory_trie_nodes(node->xnext,depth+1);
	}

	if(node->ynext != NULL) 
	{
#ifdef DEBUG
		printf("\n");
		for(i=0;i<depth;i++) printf("->{ # }");
#endif
		numbering_inmemory_trie_nodes(node->ynext,depth);
	}

}

print_tree(int	depth, Node_Type *node)
{
	int i;

	if(node == NULL) return;
	printf("->[%c|%d]",node->Code,node->Data_Start);
	if(node->xnext != NULL)
	{
		print_tree((int)node->xnext,(Node_Type*)depth+1);
	}
	if(node->ynext != NULL) 
	{
		printf("\n");
		for(i=0;i<depth;i++) printf("->{ # }");
		print_tree((int)node->ynext,(Node_Type*)depth);
	}
}

insert_inmemory_trie(char * key, int     key_start, int	data_start)
{
	Node_Type	*new;
	Node_Type	*cp;
	Node_Type	*get_node();
	Node_Type	*match_trie();
	int	i;
	int	posi=0;
	int	str_len;
	int	status;
	char	rest[1024];
	char	*sp;

	printf("INSERT[%s,(%d,%d)]\n", key, key_start, data_start);

	cp = match_trie(key,rest,&status);
	str_len = strlen(rest);
	sp = &rest[0];

	if(str_len >= 1)
	{
		new = get_node();
		new->Code = *sp;
		sp++;


		switch(status)
		{
			case EMPTY :			 
				new->ynext = ROOT_NODE;	//0
				ROOT_NODE = new;
				break;
			case XNEXT :			
				cp->xnext = new;	//1
				break;
			case YNEXT :			
				new->ynext = cp->ynext;	//2
				cp->ynext  = new;	
				break;
			case MIDLE :			
				new->ynext = cp->xnext;	//4
				cp->xnext  = new;	
				break;
		}
		cp = new;
	}

	for(i = 1; i < str_len; i++) 
	{
		new = get_node();
		new->Code = *sp;
		sp++;
		cp->xnext = new;
		cp = new;
	}
	cp->Data_Start = data_start;
	cp->Key_Start  = key_start;
	return(0);
}

Node_Type       *match_trie(char *key,char *rest, int *status)
{
	char		*sp;
	char 		newc;
	char		oldc;
	Node_Type	*cp;
	Node_Type	*cp_1;
	int	   	midle_chance=1;

	cp   = ROOT_NODE;
	cp_1 = NULL;
	*status = YNEXT;
	sp = key;

	if(cp == NULL)
	{
		strcpy(rest,sp);
		*status = EMPTY;
		return(NULL); 
	}

	while(1) 
	{
		if(*sp == '\0')
		{
			strcpy(rest,"");
			*status = COMPLETE;
			return(cp_1);
		}

		if(cp->Code == *sp)  
		{
			sp++;
			if(*sp == '\0')  
			{
				strcpy(rest,"");
				*status = COMPLETE;
				return(cp);
			}
			else
			{
				cp_1 = cp;
				cp = cp->xnext;

				if(cp == NULL) 
				{
					strcpy(rest,sp);
					*status = XNEXT;
					return(cp_1);
				}
				else
				{
					midle_chance=1;
					continue;
				}
			}
		}

		if((midle_chance == 1) && (*sp < cp->Code)) 
		{
			strcpy(rest,sp);
			*status = MIDLE;
			return(cp_1);
		}

		if(cp->ynext == NULL) 
		{
			strcpy(rest,sp);
			*status = YNEXT;
			return(cp);
		}

		if((cp->ynext != NULL) && (*sp < cp->ynext->Code)) 
		{
			strcpy(rest,sp);
			*status = YNEXT;
			return(cp);
		}
		cp_1 = cp;
		cp   = cp->ynext;
		midle_chance=0;
	}//while(1)
}

Node_Type       *get_node()
{
	Node_Type     *new;

	NODE_SIZE++;
	new = (Node_Type *)malloc(sizeof(Node_Type));
	if(new == NULL) 
	{
		fprintf(stderr," NO MORE SPACE !!! EXIT\n");
		exit(0);
	}
	new->Code = 0;
	new->Data_Start  = 0;
	new->Key_Start  = 0;
	new->xnext = new->ynext = NULL;
	return(new);
}
