#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "trie.h"


int	main(int	argc, char	*argv[])
{

	FILE	*fp;
	int	size = 0;
	char	buffer[1024];
	char	string[1024];
	char	maxstring[1024];
	char	*token;
	int	max = MAXSTRINGSIZE;

	if(argc != 2)
	{
		printf("Usage : %s inputfile\n",argv[0]);
		exit(1);
	}	
	fp = fopen(argv[1],"r");

	while(fgets(buffer,1024,fp) != NULL)
	{
		size = strlen(buffer);
		if(buffer[size - 1] == '\n')	buffer[size - 1] = '\0';
		token = strtok(buffer," \t");
		if(token != NULL)
		{
			strcpy(string,token);
		}
		else
		{
			strcpy(string,buffer);
		}

		size = strlen(string);
		if(max < size)
		{
			max = size;
			strcpy(maxstring,string);
		}
	}	

if(max == MAXSTRINGSIZE)
{
	printf("���Ϻ������ ��밡��\n");
}
else
{
	printf("������ ���� ���\n");
	printf("MAX STRING SIZE = %d(%s)\n",max,maxstring);
}
	fclose(fp);
	return 0;
}
